import {
  DeliveryRecord,
  RouteInfo,
  VehicleInfo,
  DriverInfo,
  RegionalMetric,
  AnomalyRecord,
  AlertRecord,
  AiInsight,
  DataQualityReport,
  DataSourceItem,
  CostBreakdownItem,
  DelayParetoItem,
  DeliveryFunnelStage,
  ForecastPoint
} from '../types';

export const INITIAL_REGIONS: RegionalMetric[] = [
  {
    region: 'Tamil Nadu',
    hubCity: 'Chennai & Coimbatore',
    totalDeliveries: 9420,
    revenue: 3862000,
    totalCost: 3120000,
    delayRate: 7.8,
    onTimeRate: 92.2,
    customerComplaints: 84,
    avgDeliveryTimeHours: 4.1,
    activeVehicles: 72,
    activeRoutes: 6,
    costPerDelivery: 331,
    growthRate: 11.4
  },
  {
    region: 'Karnataka',
    hubCity: 'Bengaluru & Hubballi',
    totalDeliveries: 7850,
    revenue: 3340000,
    totalCost: 2780000,
    delayRate: 8.4,
    onTimeRate: 91.6,
    customerComplaints: 76,
    avgDeliveryTimeHours: 4.3,
    activeVehicles: 58,
    activeRoutes: 5,
    costPerDelivery: 354,
    growthRate: 8.9
  },
  {
    region: 'Kerala',
    hubCity: 'Kochi & Thiruvananthapuram',
    totalDeliveries: 3910,
    revenue: 1680000,
    totalCost: 1350000,
    delayRate: 5.6,
    onTimeRate: 94.4,
    customerComplaints: 32,
    avgDeliveryTimeHours: 3.8,
    activeVehicles: 28,
    activeRoutes: 3,
    costPerDelivery: 345,
    growthRate: 6.2
  },
  {
    region: 'Andhra Pradesh & Telangana',
    hubCity: 'Hyderabad & Visakhapatnam',
    totalDeliveries: 3640,
    revenue: 1590000,
    totalCost: 1170000,
    delayRate: 6.9,
    onTimeRate: 93.1,
    customerComplaints: 56,
    avgDeliveryTimeHours: 4.4,
    activeVehicles: 28,
    activeRoutes: 4,
    costPerDelivery: 321,
    growthRate: 7.5
  }
];

export const INITIAL_ROUTES: RouteInfo[] = [
  {
    id: 'rt-tn-042',
    code: 'TN-042',
    name: 'Chennai Central ➔ Coimbatore Gateway',
    origin: 'Chennai Hub',
    destination: 'Coimbatore Hub',
    region: 'Tamil Nadu',
    distanceKm: 504,
    expectedDurationMins: 480, // 8h
    avgActualDurationMins: 568, // 9h 28m
    totalShipments: 4210,
    delayRate: 18.4,
    avgFuelCost: 12420,
    costPerDelivery: 382,
    status: 'NEEDS_ATTENTION',
    primaryDelayCause: 'Traffic Congestion',
    coordinates: {
      origin: [13.0827, 80.2707],
      destination: [11.0168, 76.9558],
      waypoints: [[12.9249, 79.1351], [11.6643, 78.1460]]
    }
  },
  {
    id: 'rt-ka-012',
    code: 'KA-012',
    name: 'Bengaluru Electronic City ➔ Mysuru Ring',
    origin: 'Bengaluru South',
    destination: 'Mysuru City',
    region: 'Karnataka',
    distanceKm: 146,
    expectedDurationMins: 190,
    avgActualDurationMins: 202,
    totalShipments: 3890,
    delayRate: 5.2,
    avgFuelCost: 3180,
    costPerDelivery: 295,
    status: 'EFFICIENT',
    primaryDelayCause: 'Loading / Dock Delay',
    coordinates: {
      origin: [12.9716, 77.5946],
      destination: [12.2958, 76.6394],
      waypoints: [[12.7214, 77.2799], [12.4224, 76.8833]]
    }
  },
  {
    id: 'rt-tn-018',
    code: 'TN-018',
    name: 'Chennai Ambattur ➔ Madurai Logistics Park',
    origin: 'Chennai Ambattur',
    destination: 'Madurai Hub',
    region: 'Tamil Nadu',
    distanceKm: 462,
    expectedDurationMins: 450,
    avgActualDurationMins: 470,
    totalShipments: 2890,
    delayRate: 6.8,
    avgFuelCost: 10850,
    costPerDelivery: 328,
    status: 'OPTIMAL',
    primaryDelayCause: 'Documentation / Toll Check',
    coordinates: {
      origin: [13.1143, 80.1548],
      destination: [9.9252, 78.1198],
      waypoints: [[11.9416, 79.8083], [10.7905, 78.7047]]
    }
  },
  {
    id: 'rt-kl-007',
    code: 'KL-007',
    name: 'Kochi Port Hub ➔ Kozhikode City',
    origin: 'Kochi Port',
    destination: 'Kozhikode Gateway',
    region: 'Kerala',
    distanceKm: 181,
    expectedDurationMins: 290,
    avgActualDurationMins: 304,
    totalShipments: 2150,
    delayRate: 6.1,
    avgFuelCost: 4520,
    costPerDelivery: 340,
    status: 'OPTIMAL',
    primaryDelayCause: 'Severe Weather',
    coordinates: {
      origin: [9.9312, 76.2673],
      destination: [11.2588, 75.7804],
      waypoints: [[10.5276, 76.2144]]
    }
  },
  {
    id: 'rt-ap-019',
    code: 'AP-019',
    name: 'Vijayawada Central ➔ Visakhapatnam Port',
    origin: 'Vijayawada Hub',
    destination: 'Visakhapatnam Dock',
    region: 'Andhra Pradesh & Telangana',
    distanceKm: 348,
    expectedDurationMins: 360,
    avgActualDurationMins: 412,
    totalShipments: 1980,
    delayRate: 14.1,
    avgFuelCost: 8940,
    costPerDelivery: 362,
    status: 'NEEDS_ATTENTION',
    primaryDelayCause: 'Warehouse Dispatch Delay',
    coordinates: {
      origin: [16.5062, 80.6480],
      destination: [17.6868, 83.2185],
      waypoints: [[16.9891, 82.2475]]
    }
  },
  {
    id: 'rt-ka-033',
    code: 'KA-033',
    name: 'Bengaluru Whitefield ➔ Hubballi Industrial',
    origin: 'Bengaluru North',
    destination: 'Hubballi Hub',
    region: 'Karnataka',
    distanceKm: 412,
    expectedDurationMins: 420,
    avgActualDurationMins: 435,
    totalShipments: 2420,
    delayRate: 7.1,
    avgFuelCost: 9680,
    costPerDelivery: 335,
    status: 'OPTIMAL',
    primaryDelayCause: 'Traffic Congestion',
    coordinates: {
      origin: [12.9698, 77.7500],
      destination: [15.3647, 75.1240],
      waypoints: [[13.3409, 77.1010], [14.4644, 75.9218]]
    }
  }
];

export const INITIAL_DRIVERS: DriverInfo[] = [
  {
    id: 'drv-01',
    name: 'Rajesh Kumar',
    employeeCode: 'DRV-TN-104',
    region: 'Tamil Nadu',
    assignedVehicleId: 'veh-01',
    totalDeliveries: 1240,
    onTimeRate: 95.2,
    avgDeliveryDurationMins: 215,
    totalDistanceKm: 18400,
    complaintsReceived: 4,
    delayRate: 4.8,
    operationalPerformanceScore: 94,
    safetyRating: 4.9,
    status: 'ON_DUTY',
    phone: '+91 98410 12345'
  },
  {
    id: 'drv-02',
    name: 'Suresh Babu',
    employeeCode: 'DRV-TN-109',
    region: 'Tamil Nadu',
    assignedVehicleId: 'veh-02',
    totalDeliveries: 1110,
    onTimeRate: 88.4,
    avgDeliveryDurationMins: 248,
    totalDistanceKm: 16800,
    complaintsReceived: 14,
    delayRate: 11.6,
    operationalPerformanceScore: 81,
    safetyRating: 4.4,
    status: 'ON_DUTY',
    phone: '+91 98410 54321'
  },
  {
    id: 'drv-03',
    name: 'Anand Murthy',
    employeeCode: 'DRV-KA-201',
    region: 'Karnataka',
    assignedVehicleId: 'veh-03',
    totalDeliveries: 1380,
    onTimeRate: 96.8,
    avgDeliveryDurationMins: 195,
    totalDistanceKm: 21200,
    complaintsReceived: 2,
    delayRate: 3.2,
    operationalPerformanceScore: 97,
    safetyRating: 5.0,
    status: 'ON_DUTY',
    phone: '+91 98801 88990'
  },
  {
    id: 'drv-04',
    name: 'Manoj Pillai',
    employeeCode: 'DRV-KL-304',
    region: 'Kerala',
    assignedVehicleId: 'veh-04',
    totalDeliveries: 920,
    onTimeRate: 93.9,
    avgDeliveryDurationMins: 220,
    totalDistanceKm: 14100,
    complaintsReceived: 5,
    delayRate: 6.1,
    operationalPerformanceScore: 91,
    safetyRating: 4.8,
    status: 'ON_DUTY',
    phone: '+91 94471 33445'
  },
  {
    id: 'drv-05',
    name: 'Venkata Reddy',
    employeeCode: 'DRV-AP-408',
    region: 'Andhra Pradesh & Telangana',
    assignedVehicleId: 'veh-05',
    totalDeliveries: 1040,
    onTimeRate: 91.2,
    avgDeliveryDurationMins: 232,
    totalDistanceKm: 17200,
    complaintsReceived: 8,
    delayRate: 8.8,
    operationalPerformanceScore: 86,
    safetyRating: 4.6,
    status: 'ON_BREAK',
    phone: '+91 94901 66778'
  },
  {
    id: 'drv-06',
    name: 'Karthik Raman',
    employeeCode: 'DRV-TN-115',
    region: 'Tamil Nadu',
    assignedVehicleId: 'veh-06',
    totalDeliveries: 1290,
    onTimeRate: 94.7,
    avgDeliveryDurationMins: 205,
    totalDistanceKm: 19500,
    complaintsReceived: 3,
    delayRate: 5.3,
    operationalPerformanceScore: 93,
    safetyRating: 4.9,
    status: 'ON_DUTY',
    phone: '+91 98402 77881'
  }
];

export const INITIAL_VEHICLES: VehicleInfo[] = [
  {
    id: 'veh-01',
    plateNumber: 'TN 09 BX 4289',
    type: 'Medium Truck (MCV)',
    assignedDriverId: 'drv-01',
    assignedDriverName: 'Rajesh Kumar',
    region: 'Tamil Nadu',
    currentStatus: 'ACTIVE',
    fuelType: 'Diesel',
    fuelEfficiencyKmPerUnit: 6.4,
    totalDistanceKm: 48200,
    activeOperatingHours: 176,
    availableOperatingHours: 200,
    utilizationRate: 88.0,
    fuelConsumptionUnits: 7530,
    deliveriesCompleted: 1240,
    lastMaintenanceDate: '2026-07-28',
    nextServiceDueKm: 50000,
    healthScore: 92
  },
  {
    id: 'veh-02',
    plateNumber: 'TN 10 CK 8912',
    type: 'Heavy Hauler (HCV)',
    assignedDriverId: 'drv-02',
    assignedDriverName: 'Suresh Babu',
    region: 'Tamil Nadu',
    currentStatus: 'ACTIVE',
    fuelType: 'Diesel',
    fuelEfficiencyKmPerUnit: 4.1,
    totalDistanceKm: 76400,
    activeOperatingHours: 142,
    availableOperatingHours: 200,
    utilizationRate: 71.0,
    fuelConsumptionUnits: 18630,
    deliveriesCompleted: 1110,
    lastMaintenanceDate: '2026-06-15',
    nextServiceDueKm: 80000,
    healthScore: 78
  },
  {
    id: 'veh-03',
    plateNumber: 'KA 03 MK 2011',
    type: 'Electric Van (EV)',
    assignedDriverId: 'drv-03',
    assignedDriverName: 'Anand Murthy',
    region: 'Karnataka',
    currentStatus: 'ACTIVE',
    fuelType: 'EV',
    fuelEfficiencyKmPerUnit: 4.8, // km/kWh
    totalDistanceKm: 31200,
    activeOperatingHours: 188,
    availableOperatingHours: 200,
    utilizationRate: 94.0,
    fuelConsumptionUnits: 6500,
    deliveriesCompleted: 1380,
    lastMaintenanceDate: '2026-08-02',
    nextServiceDueKm: 35000,
    healthScore: 96
  },
  {
    id: 'veh-04',
    plateNumber: 'KL 07 DH 5543',
    type: 'Refrigerated Truck',
    assignedDriverId: 'drv-04',
    assignedDriverName: 'Manoj Pillai',
    region: 'Kerala',
    currentStatus: 'ACTIVE',
    fuelType: 'Diesel',
    fuelEfficiencyKmPerUnit: 5.2,
    totalDistanceKm: 42100,
    activeOperatingHours: 164,
    availableOperatingHours: 200,
    utilizationRate: 82.0,
    fuelConsumptionUnits: 8090,
    deliveriesCompleted: 920,
    lastMaintenanceDate: '2026-07-20',
    nextServiceDueKm: 45000,
    healthScore: 89
  },
  {
    id: 'veh-05',
    plateNumber: 'AP 16 TZ 7120',
    type: 'Light Commercial (LCV)',
    assignedDriverId: 'drv-05',
    assignedDriverName: 'Venkata Reddy',
    region: 'Andhra Pradesh & Telangana',
    currentStatus: 'ACTIVE',
    fuelType: 'CNG',
    fuelEfficiencyKmPerUnit: 9.8,
    totalDistanceKm: 39800,
    activeOperatingHours: 156,
    availableOperatingHours: 200,
    utilizationRate: 78.0,
    fuelConsumptionUnits: 4060,
    deliveriesCompleted: 1040,
    lastMaintenanceDate: '2026-07-10',
    nextServiceDueKm: 42000,
    healthScore: 85
  },
  {
    id: 'veh-06',
    plateNumber: 'TN 04 ER 9031',
    type: 'Electric Van (EV)',
    assignedDriverId: 'drv-06',
    assignedDriverName: 'Karthik Raman',
    region: 'Tamil Nadu',
    currentStatus: 'ACTIVE',
    fuelType: 'EV',
    fuelEfficiencyKmPerUnit: 4.9,
    totalDistanceKm: 28400,
    activeOperatingHours: 184,
    availableOperatingHours: 200,
    utilizationRate: 92.0,
    fuelConsumptionUnits: 5800,
    deliveriesCompleted: 1290,
    lastMaintenanceDate: '2026-08-05',
    nextServiceDueKm: 30000,
    healthScore: 98
  },
  {
    id: 'veh-07',
    plateNumber: 'KA 05 LM 3319',
    type: 'Heavy Hauler (HCV)',
    assignedDriverId: '',
    assignedDriverName: 'Unassigned (Reserve)',
    region: 'Karnataka',
    currentStatus: 'IDLE',
    fuelType: 'Diesel',
    fuelEfficiencyKmPerUnit: 4.0,
    totalDistanceKm: 89000,
    activeOperatingHours: 42,
    availableOperatingHours: 200,
    utilizationRate: 21.0,
    fuelConsumptionUnits: 22250,
    deliveriesCompleted: 240,
    lastMaintenanceDate: '2026-05-18',
    nextServiceDueKm: 90000,
    healthScore: 68
  },
  {
    id: 'veh-08',
    plateNumber: 'TN 22 PQ 1104',
    type: 'Medium Truck (MCV)',
    assignedDriverId: '',
    assignedDriverName: 'Depot Mechanic Crew',
    region: 'Tamil Nadu',
    currentStatus: 'MAINTENANCE',
    fuelType: 'Diesel',
    fuelEfficiencyKmPerUnit: 5.8,
    totalDistanceKm: 62400,
    activeOperatingHours: 0,
    availableOperatingHours: 200,
    utilizationRate: 0.0,
    fuelConsumptionUnits: 10750,
    deliveriesCompleted: 0,
    lastMaintenanceDate: '2026-08-16',
    nextServiceDueKm: 65000,
    healthScore: 45
  }
];

export const INITIAL_DELIVERIES: DeliveryRecord[] = [
  {
    id: 'del-1001',
    trackingNumber: 'SF-2026-98124',
    customerName: 'Reliance Retail Distribution Hub',
    originCity: 'Chennai',
    destinationCity: 'Coimbatore',
    region: 'Tamil Nadu',
    routeId: 'rt-tn-042',
    vehicleId: 'veh-01',
    driverId: 'drv-01',
    status: 'DELIVERED',
    orderTimestamp: '2026-08-16T08:30:00Z',
    dispatchTimestamp: '2026-08-16T10:15:00Z',
    expectedDelivery: '2026-08-16T18:15:00Z',
    actualDelivery: '2026-08-16T18:05:00Z',
    delayMinutes: 0,
    packageWeightKg: 420,
    packageType: 'Standard',
    deliveryCost: 1450,
    fuelCost: 680,
    distanceKm: 504,
    customerRating: 5,
    complaintLogged: false,
    lat: 11.0168,
    lng: 76.9558
  },
  {
    id: 'del-1002',
    trackingNumber: 'SF-2026-98125',
    customerName: 'Apollo Pharmacy Central Cold Store',
    originCity: 'Kochi Port',
    destinationCity: 'Kozhikode',
    region: 'Kerala',
    routeId: 'rt-kl-007',
    vehicleId: 'veh-04',
    driverId: 'drv-04',
    status: 'DELIVERED',
    orderTimestamp: '2026-08-16T09:00:00Z',
    dispatchTimestamp: '2026-08-16T09:45:00Z',
    expectedDelivery: '2026-08-16T14:35:00Z',
    actualDelivery: '2026-08-16T14:20:00Z',
    delayMinutes: 0,
    packageWeightKg: 180,
    packageType: 'Cold Chain',
    deliveryCost: 2100,
    fuelCost: 790,
    distanceKm: 181,
    customerRating: 5,
    complaintLogged: false,
    lat: 11.2588,
    lng: 75.7804
  },
  {
    id: 'del-1003',
    trackingNumber: 'SF-2026-98126',
    customerName: 'Titan Industrial Assemblies',
    originCity: 'Bengaluru South',
    destinationCity: 'Mysuru',
    region: 'Karnataka',
    routeId: 'rt-ka-012',
    vehicleId: 'veh-03',
    driverId: 'drv-03',
    status: 'IN_TRANSIT',
    orderTimestamp: '2026-08-17T06:00:00Z',
    dispatchTimestamp: '2026-08-17T07:15:00Z',
    expectedDelivery: '2026-08-17T10:25:00Z',
    delayMinutes: 0,
    packageWeightKg: 85,
    packageType: 'Express',
    deliveryCost: 890,
    fuelCost: 220,
    distanceKm: 146,
    complaintLogged: false,
    lat: 12.5645,
    lng: 77.0123
  },
  {
    id: 'del-1004',
    trackingNumber: 'SF-2026-98127',
    customerName: 'Croma Megastore Electronics',
    originCity: 'Chennai',
    destinationCity: 'Coimbatore',
    region: 'Tamil Nadu',
    routeId: 'rt-tn-042',
    vehicleId: 'veh-02',
    driverId: 'drv-02',
    status: 'DELAYED',
    orderTimestamp: '2026-08-16T14:00:00Z',
    dispatchTimestamp: '2026-08-16T16:30:00Z',
    expectedDelivery: '2026-08-17T00:30:00Z',
    actualDelivery: '2026-08-17T02:45:00Z',
    delayMinutes: 135,
    delayReason: 'Traffic Congestion',
    packageWeightKg: 840,
    packageType: 'Heavy Cargo',
    deliveryCost: 3200,
    fuelCost: 1650,
    distanceKm: 504,
    customerRating: 2,
    complaintLogged: true,
    complaintReason: 'Delivery exceeded guaranteed express window by 2.25 hours',
    lat: 11.1200,
    lng: 77.0500
  },
  {
    id: 'del-1005',
    trackingNumber: 'SF-2026-98128',
    customerName: 'Dr. Reddy Pharma Hub',
    originCity: 'Vijayawada',
    destinationCity: 'Visakhapatnam',
    region: 'Andhra Pradesh & Telangana',
    routeId: 'rt-ap-019',
    vehicleId: 'veh-05',
    driverId: 'drv-05',
    status: 'DELAYED',
    orderTimestamp: '2026-08-16T11:00:00Z',
    dispatchTimestamp: '2026-08-16T13:40:00Z',
    expectedDelivery: '2026-08-16T19:40:00Z',
    actualDelivery: '2026-08-16T21:10:00Z',
    delayMinutes: 90,
    delayReason: 'Warehouse Dispatch Delay',
    packageWeightKg: 210,
    packageType: 'Fragile',
    deliveryCost: 1750,
    fuelCost: 620,
    distanceKm: 348,
    customerRating: 3,
    complaintLogged: true,
    complaintReason: 'Warehouse staging queue caused late departure',
    lat: 17.6868,
    lng: 83.2185
  },
  {
    id: 'del-1006',
    trackingNumber: 'SF-2026-98129',
    customerName: 'Bosch Automotive Components',
    originCity: 'Bengaluru North',
    destinationCity: 'Hubballi',
    region: 'Karnataka',
    routeId: 'rt-ka-033',
    vehicleId: 'veh-03',
    driverId: 'drv-03',
    status: 'OUT_FOR_DELIVERY',
    orderTimestamp: '2026-08-17T04:30:00Z',
    dispatchTimestamp: '2026-08-17T05:15:00Z',
    expectedDelivery: '2026-08-17T12:15:00Z',
    delayMinutes: 0,
    packageWeightKg: 520,
    packageType: 'Standard',
    deliveryCost: 1980,
    fuelCost: 710,
    distanceKm: 412,
    complaintLogged: false,
    lat: 15.2200,
    lng: 75.2000
  },
  {
    id: 'del-1007',
    trackingNumber: 'SF-2026-98130',
    customerName: 'Lulu Supermarket Retail Group',
    originCity: 'Chennai Ambattur',
    destinationCity: 'Madurai',
    region: 'Tamil Nadu',
    routeId: 'rt-tn-018',
    vehicleId: 'veh-06',
    driverId: 'drv-06',
    status: 'DELIVERED',
    orderTimestamp: '2026-08-16T10:00:00Z',
    dispatchTimestamp: '2026-08-16T11:00:00Z',
    expectedDelivery: '2026-08-16T18:30:00Z',
    actualDelivery: '2026-08-16T18:10:00Z',
    delayMinutes: 0,
    packageWeightKg: 310,
    packageType: 'Standard',
    deliveryCost: 1620,
    fuelCost: 540,
    distanceKm: 462,
    customerRating: 5,
    complaintLogged: false,
    lat: 9.9252,
    lng: 78.1198
  },
  {
    id: 'del-1008',
    trackingNumber: 'SF-2026-98131',
    customerName: 'Amazon Fulfilment Center BLR7',
    originCity: 'Bengaluru South',
    destinationCity: 'Mysuru',
    region: 'Karnataka',
    routeId: 'rt-ka-012',
    vehicleId: 'veh-03',
    driverId: 'drv-03',
    status: 'RETURNED',
    orderTimestamp: '2026-08-15T15:00:00Z',
    dispatchTimestamp: '2026-08-15T16:20:00Z',
    expectedDelivery: '2026-08-15T19:30:00Z',
    actualDelivery: '2026-08-15T21:00:00Z',
    delayMinutes: 90,
    delayReason: 'Customer Unavailable',
    packageWeightKg: 45,
    packageType: 'Express',
    deliveryCost: 950,
    fuelCost: 240,
    distanceKm: 146,
    complaintLogged: true,
    complaintReason: 'Receiver security dock closed at arrival',
    lat: 12.3100,
    lng: 76.6500
  }
];

export const INITIAL_DELAY_PARETO: DelayParetoItem[] = [
  {
    reason: 'Traffic Congestion',
    count: 712,
    percentage: 39.0,
    cumulativePercentage: 39.0,
    costImpact: 242000,
    primaryRegion: 'Tamil Nadu & Karnataka (Urban Corridors)'
  },
  {
    reason: 'Warehouse Dispatch Delay',
    count: 420,
    percentage: 23.0,
    cumulativePercentage: 62.0,
    costImpact: 142800,
    primaryRegion: 'Andhra Pradesh & Tamil Nadu'
  },
  {
    reason: 'Loading / Dock Delay',
    count: 248,
    percentage: 13.6,
    cumulativePercentage: 75.6,
    costImpact: 84300,
    primaryRegion: 'Karnataka & Kerala Ports'
  },
  {
    reason: 'Severe Weather',
    count: 146,
    percentage: 8.0,
    cumulativePercentage: 83.6,
    costImpact: 49600,
    primaryRegion: 'Coastal Kerala & Tamil Nadu'
  },
  {
    reason: 'Incorrect Customer Address',
    count: 112,
    percentage: 6.1,
    cumulativePercentage: 89.7,
    costImpact: 38100,
    primaryRegion: 'Tier-2 Peripheral Zones'
  },
  {
    reason: 'Driver Schedule Delay',
    count: 78,
    percentage: 4.3,
    cumulativePercentage: 94.0,
    costImpact: 26500,
    primaryRegion: 'Long-haul interstate routes'
  },
  {
    reason: 'Vehicle Breakdown',
    count: 62,
    percentage: 3.4,
    cumulativePercentage: 97.4,
    costImpact: 52000,
    primaryRegion: 'Older HCV Fleet (Tamil Nadu)'
  },
  {
    reason: 'Customer Unavailable',
    count: 46,
    percentage: 2.6,
    cumulativePercentage: 100.0,
    costImpact: 15600,
    primaryRegion: 'Commercial Retail Parks'
  }
];

export const INITIAL_COST_BREAKDOWN: CostBreakdownItem[] = [
  {
    category: 'Fuel & Energy',
    amount: 342000,
    percentage: 40.6,
    trend: -2.4,
    subCategories: [
      { name: 'Diesel (Heavy & Medium Trucks)', amount: 254000 },
      { name: 'EV Charging Infrastructure', amount: 52000 },
      { name: 'CNG Light Commercial', amount: 36000 }
    ]
  },
  {
    category: 'Driver Compensation & Allowances',
    amount: 218000,
    percentage: 25.9,
    trend: +1.5,
    subCategories: [
      { name: 'Base Driver Salaries', amount: 165000 },
      { name: 'Trip & On-Time Performance Incentives', amount: 38000 },
      { name: 'Overtime & Overnight Allowances', amount: 15000 }
    ]
  },
  {
    category: 'Warehouse & Staging Operations',
    amount: 112000,
    percentage: 13.3,
    trend: +4.2,
    subCategories: [
      { name: 'Dock Handling & Staging Staff', amount: 68000 },
      { name: 'Forklift & Pallet Lease', amount: 29000 },
      { name: 'Barcoding & Cold Storage Energy', amount: 15000 }
    ]
  },
  {
    category: 'Vehicle Maintenance & Spares',
    amount: 86000,
    percentage: 10.2,
    trend: -8.1,
    subCategories: [
      { name: 'Scheduled Preventative Servicing', amount: 54000 },
      { name: 'Tire Replacements & Consumables', amount: 22000 },
      { name: 'Emergency Breakdown Repairs', amount: 10000 }
    ]
  },
  {
    category: 'Tolls, Permits & Logistics Overhead',
    amount: 54000,
    percentage: 6.4,
    trend: +0.8,
    subCategories: [
      { name: 'FASTag National Highway Tolls', amount: 38000 },
      { name: 'Interstate Transit Permits', amount: 11000 },
      { name: 'Fleet Telematics & GPS Software', amount: 5000 }
    ]
  },
  {
    category: 'Returns & Exception Handling',
    amount: 30000,
    percentage: 3.6,
    trend: -12.4,
    subCategories: [
      { name: 'Reverse Logistics Transport', amount: 19000 },
      { name: 'Restocking & Re-inspection', amount: 11000 }
    ]
  }
];

export const INITIAL_FUNNEL_STAGES: DeliveryFunnelStage[] = [
  { stage: 'Orders Placed', count: 26500, percentageOfTotal: 100.0, dropOffCount: 600, dropOffRate: 2.3, isBottleneck: false },
  { stage: 'Dispatched from Hub', count: 25900, percentageOfTotal: 97.7, dropOffCount: 700, dropOffRate: 2.7, isBottleneck: true },
  { stage: 'In Transit Network', count: 25200, percentageOfTotal: 95.1, dropOffCount: 250, dropOffRate: 1.0, isBottleneck: false },
  { stage: 'Out for Final Delivery', count: 24950, percentageOfTotal: 94.2, dropOffCount: 130, dropOffRate: 0.5, isBottleneck: false },
  { stage: 'Successfully Delivered', count: 24820, percentageOfTotal: 93.7, dropOffCount: 380, dropOffRate: 1.5, isBottleneck: false },
  { stage: 'Returned / RTO', count: 380, percentageOfTotal: 1.4, dropOffCount: 0, dropOffRate: 0.0, isBottleneck: false }
];

export const INITIAL_ANOMALIES: AnomalyRecord[] = [
  {
    id: 'anom-01',
    metric: 'Delivery Cost Per Shipment',
    entityType: 'REGION',
    entityName: 'Andhra Pradesh - Coastal Corridor',
    currentValue: '₹362 / delivery',
    baselineValue: '₹294 / delivery',
    deviationPercent: 23.1,
    severity: 'HIGH',
    detectedAt: '2026-08-16 16:40',
    description: 'Delivery cost in Coastal AP is 23.1% above its 30-day baseline, triggered by warehouse queue times.',
    possibleRootCause: 'Vijayawada dispatch dock backlogs resulting in vehicle idle time and overtime driver wages.',
    recommendedInvestigation: 'Audit Vijayawada dispatch throughput between 11:00 AM and 3:00 PM shift change.',
    acknowledged: false
  },
  {
    id: 'anom-02',
    metric: 'Delay Rate on Arterial Route',
    entityType: 'ROUTE',
    entityName: 'Route TN-042 (Chennai ➔ Coimbatore)',
    currentValue: '18.4% delay rate',
    baselineValue: '7.2% baseline',
    deviationPercent: 155.5,
    severity: 'CRITICAL',
    detectedAt: '2026-08-17 04:15',
    description: 'Delay rate on TN-042 jumped by +11.2 percentage points over the last 7 days.',
    possibleRootCause: 'Highway maintenance work between Vellore and Salem causing 90+ min traffic bottlenecks during peak evening transit.',
    recommendedInvestigation: 'Reroute nighttime freight through SH-188 alternative corridor or adjust dispatch windows to 04:00 AM.',
    acknowledged: false
  },
  {
    id: 'anom-03',
    metric: 'Fuel Consumption Spike',
    entityType: 'VEHICLE',
    entityName: 'Vehicle TN 10 CK 8912 (Heavy Hauler)',
    currentValue: '4.1 km/L',
    baselineValue: '5.6 km/L',
    deviationPercent: -26.8,
    severity: 'ATTENTION',
    detectedAt: '2026-08-15 18:20',
    description: 'Vehicle TN 10 CK 8912 is consuming 26.8% more diesel than fleet baseline for identical payloads.',
    possibleRootCause: 'Fuel injector clogging or prolonged stationary AC/engine idling during warehouse dock holds.',
    recommendedInvestigation: 'Schedule immediate diagnostic engine check at Chennai depot.',
    acknowledged: true
  }
];

export const INITIAL_ALERTS: AlertRecord[] = [
  {
    id: 'alt-01',
    severity: 'CRITICAL',
    category: 'SLA_BREACH',
    title: 'Route TN-042 SLA Breach Threshold Exceeded',
    message: 'Delay rate on Chennai ➔ Coimbatore reached 18.4% (Threshold: 10.0%). 84 orders impacted today.',
    entityRef: 'Route TN-042',
    timestamp: '2026-08-17 07:15',
    acknowledged: false,
    resolved: false,
    thresholdConfig: {
      metric: 'Delay Rate',
      threshold: '10.0%',
      actual: '18.4%'
    }
  },
  {
    id: 'alt-02',
    severity: 'HIGH',
    category: 'COST_SPIKE',
    title: 'Fuel Expenditure Spike in Zone AP-North',
    message: 'Fuel cost in Visakhapatnam delivery zone is 19.4% higher than previous weekly average.',
    entityRef: 'Andhra Pradesh Zone',
    timestamp: '2026-08-16 21:00',
    acknowledged: true,
    resolved: false,
    thresholdConfig: {
      metric: 'Fuel Cost Deviation',
      threshold: '+10.0%',
      actual: '+19.4%'
    }
  },
  {
    id: 'alt-03',
    severity: 'ATTENTION',
    category: 'FLEET_MAINTENANCE',
    title: 'Scheduled Service Due for 4 Commercial Vehicles',
    message: 'Vehicles TN 10 CK 8912 and KA 05 LM 3319 are within 1,000 km of manufacturer mandatory overhaul.',
    entityRef: 'Fleet Depot',
    timestamp: '2026-08-16 11:30',
    acknowledged: false,
    resolved: false
  },
  {
    id: 'alt-04',
    severity: 'INFO',
    category: 'VOLUME_SURGE',
    title: 'Demand Inflow Surge in Karnataka Hub',
    message: 'Bengaluru fulfilment requests are trending +14.2% higher than forecast due to festive regional sales.',
    entityRef: 'Bengaluru Hub',
    timestamp: '2026-08-16 09:00',
    acknowledged: true,
    resolved: true
  }
];

export const INITIAL_AI_INSIGHTS: AiInsight[] = [
  {
    id: 'ins-01',
    category: 'PERFORMANCE',
    keyInsight: 'On-time delivery decreased by 6.2% over the last 7 days on long-haul routes.',
    possibleDriver: 'Warehouse dispatch delays increased by 28 mins during the 11:00 AM - 3:00 PM shift handover.',
    investigationSuggestion: 'Review dispatch staging and pallet loading protocols at Chennai and Vijayawada hubs.',
    opportunity: 'Standardizing shift-change dock handovers will recover 84% of SLA breaches.',
    confidenceScore: 94,
    impactEstimate: 'Save ₹68,000/week in late delivery penalties',
    source: 'Generated from dashboard data',
    timestamp: '2026-08-17 06:30',
    relatedEntity: 'Chennai Hub & Vijayawada Hub'
  },
  {
    id: 'ins-02',
    category: 'COST_SAVINGS',
    keyInsight: 'Route TN-042 has ₹382 cost per delivery vs network average of ₹339.',
    possibleDriver: 'Heavy vehicle idling in Vellore-Salem bypass construction combined with peak toll rates.',
    investigationSuggestion: 'Evaluate dynamic dispatch scheduling at 04:00 AM to bypass Salem congestion window.',
    opportunity: 'Shifting 60% of volume to morning departures reduces fuel drain by 14.5%.',
    confidenceScore: 91,
    impactEstimate: 'Save ₹1,12,000/month across Tamil Nadu freight',
    source: 'Generated from dashboard data',
    timestamp: '2026-08-16 18:45',
    relatedEntity: 'Route TN-042'
  },
  {
    id: 'ins-03',
    category: 'ROUTE_OPTIMIZATION',
    keyInsight: 'EV Delivery Vans in Bengaluru achieved 94.0% utilization with ₹295 cost per drop.',
    possibleDriver: 'Optimized multi-stop cluster routing inside Electronic City & Whitefield tech corridors.',
    investigationSuggestion: 'Replicate the Bengaluru EV cluster model to Chennai Ambattur and Kochi Port zones.',
    opportunity: 'Deploying 12 additional EV vans replaces high-maintenance diesel LCVs.',
    confidenceScore: 96,
    impactEstimate: 'Reduce operational emissions by 32% and cut urban fuel costs by 22%',
    source: 'Generated from dashboard data',
    timestamp: '2026-08-16 14:10',
    relatedEntity: 'Bengaluru Hub Fleet'
  }
];

export const INITIAL_DATA_QUALITY: DataQualityReport = {
  overallScore: 94,
  totalRows: 24820,
  cleanRows: 24190,
  duplicatesRemoved: 148,
  missingValuesImputed: 312,
  invalidDatesFixed: 42,
  outliersFlagged: 128,
  completenessScore: 96,
  accuracyScore: 95,
  consistencyScore: 93,
  timelinessScore: 97,
  duplicateRateScore: 98,
  lastAssessed: '2026-08-17 10:30 AM'
};

export const INITIAL_DATA_SOURCES: DataSourceItem[] = [
  {
    id: 'src-01',
    name: 'TMS Telematics GPS Gateway',
    type: 'REST_API',
    status: 'HEALTHY',
    lastSyncTimestamp: '2 mins ago (10:40 AM)',
    recordsIngested: 142000,
    qualityScore: 98,
    endpointUrl: 'https://telematics-api.supplyflow.internal/v2/stream',
    syncFrequency: 'Near Real-Time (5m)'
  },
  {
    id: 'src-02',
    name: 'Enterprise WMS Postgres DB',
    type: 'POSTGRES_DB',
    status: 'HEALTHY',
    lastSyncTimestamp: '15 mins ago (10:27 AM)',
    recordsIngested: 86400,
    qualityScore: 95,
    endpointUrl: 'postgresql://wms_prod.ap-south-1.internal:5432/supplyflow',
    syncFrequency: 'Hourly'
  },
  {
    id: 'src-03',
    name: 'FASTag National Toll Data Stream',
    type: 'REST_API',
    status: 'HEALTHY',
    lastSyncTimestamp: '1 hour ago (09:42 AM)',
    recordsIngested: 12800,
    qualityScore: 96,
    endpointUrl: 'https://api.fastag-clearinghouse.in/v1/settlements',
    syncFrequency: 'Hourly'
  },
  {
    id: 'src-04',
    name: 'Operations CSV Batch Feed',
    type: 'CSV_BATCH',
    status: 'HEALTHY',
    lastSyncTimestamp: '17 Aug 2026, 06:00 AM',
    recordsIngested: 24820,
    qualityScore: 94,
    syncFrequency: 'Daily Batch (12:00 AM)'
  }
];

export const HISTORICAL_30_DAYS = [
  { date: '19 Jul', deliveries: 740, onTime: 692, delayed: 48, onTimeRate: 93.5, cost: 248000, avgTimeHours: 4.1 },
  { date: '20 Jul', deliveries: 780, onTime: 726, delayed: 54, onTimeRate: 93.1, cost: 261000, avgTimeHours: 4.2 },
  { date: '21 Jul', deliveries: 810, onTime: 755, delayed: 55, onTimeRate: 93.2, cost: 272000, avgTimeHours: 4.0 },
  { date: '22 Jul', deliveries: 790, onTime: 738, delayed: 52, onTimeRate: 93.4, cost: 265000, avgTimeHours: 4.1 },
  { date: '23 Jul', deliveries: 830, onTime: 778, delayed: 52, onTimeRate: 93.7, cost: 279000, avgTimeHours: 4.0 },
  { date: '24 Jul', deliveries: 860, onTime: 808, delayed: 52, onTimeRate: 94.0, cost: 289000, avgTimeHours: 3.9 },
  { date: '25 Jul', deliveries: 840, onTime: 788, delayed: 52, onTimeRate: 93.8, cost: 282000, avgTimeHours: 4.0 },
  { date: '26 Jul', deliveries: 720, onTime: 678, delayed: 42, onTimeRate: 94.2, cost: 242000, avgTimeHours: 3.9 },
  { date: '27 Jul', deliveries: 790, onTime: 742, delayed: 48, onTimeRate: 93.9, cost: 266000, avgTimeHours: 4.1 },
  { date: '28 Jul', deliveries: 820, onTime: 768, delayed: 52, onTimeRate: 93.7, cost: 276000, avgTimeHours: 4.1 },
  { date: '29 Jul', deliveries: 850, onTime: 796, delayed: 54, onTimeRate: 93.6, cost: 286000, avgTimeHours: 4.0 },
  { date: '30 Jul', deliveries: 870, onTime: 814, delayed: 56, onTimeRate: 93.6, cost: 293000, avgTimeHours: 4.0 },
  { date: '31 Jul', deliveries: 890, onTime: 830, delayed: 60, onTimeRate: 93.3, cost: 301000, avgTimeHours: 4.2 },
  { date: '01 Aug', deliveries: 840, onTime: 782, delayed: 58, onTimeRate: 93.1, cost: 284000, avgTimeHours: 4.2 },
  { date: '02 Aug', deliveries: 860, onTime: 802, delayed: 58, onTimeRate: 93.3, cost: 290000, avgTimeHours: 4.1 },
  { date: '03 Aug', deliveries: 880, onTime: 818, delayed: 62, onTimeRate: 93.0, cost: 297000, avgTimeHours: 4.2 },
  { date: '04 Aug', deliveries: 850, onTime: 790, delayed: 60, onTimeRate: 92.9, cost: 288000, avgTimeHours: 4.3 },
  { date: '05 Aug', deliveries: 890, onTime: 825, delayed: 65, onTimeRate: 92.7, cost: 302000, avgTimeHours: 4.2 },
  { date: '06 Aug', deliveries: 910, onTime: 842, delayed: 68, onTimeRate: 92.5, cost: 310000, avgTimeHours: 4.3 },
  { date: '07 Aug', deliveries: 920, onTime: 850, delayed: 70, onTimeRate: 92.4, cost: 314000, avgTimeHours: 4.3 },
  { date: '08 Aug', deliveries: 880, onTime: 812, delayed: 68, onTimeRate: 92.3, cost: 301000, avgTimeHours: 4.4 },
  { date: '09 Aug', deliveries: 830, onTime: 766, delayed: 64, onTimeRate: 92.3, cost: 284000, avgTimeHours: 4.3 },
  { date: '10 Aug', deliveries: 890, onTime: 820, delayed: 70, onTimeRate: 92.1, cost: 305000, avgTimeHours: 4.3 },
  { date: '11 Aug', deliveries: 940, onTime: 864, delayed: 76, onTimeRate: 91.9, cost: 323000, avgTimeHours: 4.4 },
  { date: '12 Aug', deliveries: 960, onTime: 880, delayed: 80, onTimeRate: 91.7, cost: 330000, avgTimeHours: 4.5 },
  { date: '13 Aug', deliveries: 980, onTime: 896, delayed: 84, onTimeRate: 91.4, cost: 338000, avgTimeHours: 4.5 },
  { date: '14 Aug', deliveries: 950, onTime: 872, delayed: 78, onTimeRate: 91.8, cost: 327000, avgTimeHours: 4.4 },
  { date: '15 Aug', deliveries: 920, onTime: 850, delayed: 70, onTimeRate: 92.4, cost: 314000, avgTimeHours: 4.3 },
  { date: '16 Aug', deliveries: 990, onTime: 918, delayed: 72, onTimeRate: 92.7, cost: 341000, avgTimeHours: 4.2 },
  { date: '17 Aug', deliveries: 1020, onTime: 945, delayed: 75, onTimeRate: 92.6, cost: 352000, avgTimeHours: 4.18 }
];

export const DEMAND_FORECAST_DATA: ForecastPoint[] = [
  { date: '11 Aug', actual: 940, isModelEstimate: false },
  { date: '12 Aug', actual: 960, isModelEstimate: false },
  { date: '13 Aug', actual: 980, isModelEstimate: false },
  { date: '14 Aug', actual: 950, isModelEstimate: false },
  { date: '15 Aug', actual: 920, isModelEstimate: false },
  { date: '16 Aug', actual: 990, isModelEstimate: false },
  { date: '17 Aug (Today)', actual: 1020, forecast: 1020, lowerConfidence: 980, upperConfidence: 1060, isModelEstimate: false },
  { date: '18 Aug', forecast: 1045, lowerConfidence: 990, upperConfidence: 1100, isModelEstimate: true },
  { date: '19 Aug', forecast: 1080, lowerConfidence: 1015, upperConfidence: 1145, isModelEstimate: true },
  { date: '20 Aug', forecast: 1110, lowerConfidence: 1030, upperConfidence: 1190, isModelEstimate: true },
  { date: '21 Aug', forecast: 1090, lowerConfidence: 1000, upperConfidence: 1180, isModelEstimate: true },
  { date: '22 Aug', forecast: 1140, lowerConfidence: 1040, upperConfidence: 1240, isModelEstimate: true },
  { date: '23 Aug', forecast: 1180, lowerConfidence: 1070, upperConfidence: 1290, isModelEstimate: true },
  { date: '24 Aug', forecast: 1210, lowerConfidence: 1090, upperConfidence: 1330, isModelEstimate: true }
];

export const INITIAL_ORGANIZATIONS = [
  {
    id: 'org-nexora',
    name: 'Nexora Logistics',
    industry: '3PL Freight Distribution' as const,
    country: 'India',
    contactPerson: 'Arun Kumar',
    contactEmail: 'arun.k@nexoralogistics.com',
    logo: '📦',
    primaryBrandColor: '#0284c7', // Sky blue
    secondaryBrandColor: '#0f172a', // Slate navy
    dashboardTitle: 'Command Center — Southern Regional Hub',
    timezone: 'Asia/Kolkata (IST +5:30)',
    dataMode: 'DEMO' as const,
    createdAt: '2026-01-15',
    kpiTargets: {
      targetOnTimeRate: 94.0,
      maxDelayToleranceMins: 30,
      targetCostPerDelivery: 325,
      targetFleetUtilization: 88.0
    }
  },
  {
    id: 'org-apex',
    name: 'Apex Freight Network',
    industry: 'Manufacturing & Linehaul' as const,
    country: 'India',
    contactPerson: 'Priya Dharshini',
    contactEmail: 'priya.d@apexfreight.in',
    logo: '🚛',
    primaryBrandColor: '#0d9488', // Teal
    secondaryBrandColor: '#134e4a', // Dark teal
    dashboardTitle: 'National Linehaul Freight Dispatch',
    timezone: 'Asia/Kolkata (IST +5:30)',
    dataMode: 'LIVE' as const,
    createdAt: '2026-03-20',
    kpiTargets: {
      targetOnTimeRate: 92.5,
      maxDelayToleranceMins: 45,
      targetCostPerDelivery: 340,
      targetFleetUtilization: 90.0
    }
  },
  {
    id: 'org-bluedart',
    name: 'BlueDart Supply Solutions',
    industry: 'Courier & Parcel' as const,
    country: 'India',
    contactPerson: 'Vikram Seth',
    contactEmail: 'operations@bluedartsupply.example.com',
    logo: '⚡',
    primaryBrandColor: '#2563eb', // Royal blue
    secondaryBrandColor: '#1e3a8a', // Deep navy
    dashboardTitle: 'Express Parcel Delivery Operations',
    timezone: 'Asia/Kolkata (IST +5:30)',
    dataMode: 'DEMO' as const,
    createdAt: '2026-06-01',
    kpiTargets: {
      targetOnTimeRate: 96.0,
      maxDelayToleranceMins: 20,
      targetCostPerDelivery: 295,
      targetFleetUtilization: 92.0
    }
  }
];

export const DEFAULT_COLUMN_MAPPINGS = [
  {
    companyColumn: 'shipment_id',
    targetField: 'Order ID / Tracking Number',
    status: 'MAPPED' as const,
    confidence: 0.98,
    sampleValue: 'TRK-2026-8849',
    required: true,
    dataType: 'string' as const
  },
  {
    companyColumn: 'delivery_status',
    targetField: 'Delivery Status',
    status: 'MAPPED' as const,
    confidence: 0.96,
    sampleValue: 'DELIVERED',
    required: true,
    dataType: 'enum' as const
  },
  {
    companyColumn: 'rider_name',
    targetField: 'Assigned Driver',
    status: 'MAPPED' as const,
    confidence: 0.94,
    sampleValue: 'Rajesh Kannan',
    required: true,
    dataType: 'string' as const
  },
  {
    companyColumn: 'transport_cost',
    targetField: 'Delivery Cost (₹)',
    status: 'MAPPED' as const,
    confidence: 0.95,
    sampleValue: '340',
    required: true,
    dataType: 'number' as const
  },
  {
    companyColumn: 'dispatch_time',
    targetField: 'Dispatch Timestamp',
    status: 'MAPPED' as const,
    confidence: 0.92,
    sampleValue: '2026-08-17 06:30:00',
    required: true,
    dataType: 'date' as const
  },
  {
    companyColumn: 'delivery_time',
    targetField: 'Actual Delivery Timestamp',
    status: 'MAPPED' as const,
    confidence: 0.93,
    sampleValue: '2026-08-17 10:45:00',
    required: false,
    dataType: 'date' as const
  },
  {
    companyColumn: 'origin_hub',
    targetField: 'Origin City / Hub',
    status: 'MAPPED' as const,
    confidence: 0.91,
    sampleValue: 'Chennai Central',
    required: true,
    dataType: 'string' as const
  },
  {
    companyColumn: 'destination_hub',
    targetField: 'Destination City / Hub',
    status: 'MAPPED' as const,
    confidence: 0.92,
    sampleValue: 'Coimbatore Hub',
    required: true,
    dataType: 'string' as const
  },
  {
    companyColumn: 'delay_mins',
    targetField: 'Delay Minutes',
    status: 'MAPPED' as const,
    confidence: 0.97,
    sampleValue: '45',
    required: false,
    dataType: 'number' as const
  },
  {
    companyColumn: 'delay_cause',
    targetField: 'Delay Reason Category',
    status: 'AUTO_SUGGESTED' as const,
    confidence: 0.88,
    sampleValue: 'Traffic Congestion',
    required: false,
    dataType: 'enum' as const
  },
  {
    companyColumn: 'vehicle_plate',
    targetField: 'Vehicle Identifier',
    status: 'AUTO_SUGGESTED' as const,
    confidence: 0.89,
    sampleValue: 'TN-01-CV-4029',
    required: true,
    dataType: 'string' as const
  },
  {
    companyColumn: 'cargo_weight_kg',
    targetField: 'Package Weight (kg)',
    status: 'AUTO_SUGGESTED' as const,
    confidence: 0.90,
    sampleValue: '180.5',
    required: false,
    dataType: 'number' as const
  }
];

export const INITIAL_AUDIT_LOGS = [
  {
    id: 'aud-101',
    timestamp: '17 Aug 2026, 10:30 AM',
    user: 'Arun Kumar',
    userRole: 'ADMIN' as const,
    action: 'Data Ingestion & Quality Validation',
    category: 'DATA_IMPORT' as const,
    details: 'Ingested 24,820 records from TMS API. Quality score certified at 94.2%.',
    status: 'SUCCESS' as const,
    organizationId: 'org-nexora'
  },
  {
    id: 'aud-102',
    timestamp: '17 Aug 2026, 09:15 AM',
    user: 'Priya Dharshini',
    userRole: 'DATA_ANALYST' as const,
    action: 'Deduplication & Outlier Normalization',
    category: 'DATA_CLEAN' as const,
    details: 'Removed 18 duplicate shipment IDs and clamped 14 extreme highway fuel consumption outliers.',
    status: 'SUCCESS' as const,
    organizationId: 'org-nexora'
  },
  {
    id: 'aud-103',
    timestamp: '16 Aug 2026, 05:45 PM',
    user: 'Arun Kumar',
    userRole: 'ADMIN' as const,
    action: 'KPI Threshold Target Reconfigured',
    category: 'SETTINGS_CHANGED' as const,
    details: 'Updated On-Time SLA target benchmark from 92.0% to 94.0% for Q3.',
    status: 'SUCCESS' as const,
    organizationId: 'org-nexora'
  },
  {
    id: 'aud-104',
    timestamp: '16 Aug 2026, 02:00 PM',
    user: 'Karthik Raja',
    userRole: 'LOGISTICS_MANAGER' as const,
    action: 'Executive Weekly Report Generated',
    category: 'REPORT_GENERATED' as const,
    details: 'Generated and exported Monthly Management PDF report covering 30-day Southern corridor metrics.',
    status: 'SUCCESS' as const,
    organizationId: 'org-nexora'
  },
  {
    id: 'aud-105',
    timestamp: '15 Aug 2026, 11:20 AM',
    user: 'Arun Kumar',
    userRole: 'ADMIN' as const,
    action: 'User Account Provisioned',
    category: 'USER_MANAGEMENT' as const,
    details: 'Provisioned viewer account for Regional Warehouse Lead (Kochi Hub).',
    status: 'SUCCESS' as const,
    organizationId: 'org-nexora'
  }
];

export const INITIAL_USER_ACCOUNTS = [
  {
    id: 'usr-01',
    name: 'Arun Kumar',
    email: 'arun.k@nexoralogistics.com',
    role: 'ADMIN' as const,
    organizationId: 'org-nexora',
    status: 'ACTIVE' as const,
    lastActive: 'Active now',
    avatar: 'AK',
    assignedRegion: 'All Southern Regions'
  },
  {
    id: 'usr-02',
    name: 'Priya Dharshini',
    email: 'priya.d@nexoralogistics.com',
    role: 'DATA_ANALYST' as const,
    organizationId: 'org-nexora',
    status: 'ACTIVE' as const,
    lastActive: '12 mins ago',
    avatar: 'PD',
    assignedRegion: 'Analytics & Pipeline'
  },
  {
    id: 'usr-03',
    name: 'Karthik Raja',
    email: 'karthik.r@nexoralogistics.com',
    role: 'LOGISTICS_MANAGER' as const,
    organizationId: 'org-nexora',
    status: 'ACTIVE' as const,
    lastActive: '1 hour ago',
    avatar: 'KR',
    assignedRegion: 'Tamil Nadu & Kerala'
  },
  {
    id: 'usr-04',
    name: 'Meera Nambiar',
    email: 'meera.n@nexoralogistics.com',
    role: 'VIEWER' as const,
    organizationId: 'org-nexora',
    status: 'ACTIVE' as const,
    lastActive: '3 hours ago',
    avatar: 'MN',
    assignedRegion: 'Kochi Gateway Hub'
  }
];

export const CLIENT_IMPLEMENTATION_STEPS = [
  {
    stepNumber: 1,
    title: 'Requirement Discussion & Workflow Scoping',
    phase: 'DISCOVERY' as const,
    description: 'We meet with your operations, fleet, and IT leaders to understand your distribution hubs, shipment formats, fleet telemetry types, and exact KPI metrics.',
    duration: 'Day 1–2',
    deliverables: ['Logistics Workflow Architecture Document', 'Data Source Inventory', 'Custom KPI Definition Matrix'],
    owner: 'Joint Working Group' as const
  },
  {
    stepNumber: 2,
    title: 'Operational Data Collection & Ingestion',
    phase: 'INGESTION & MAPPING' as const,
    description: 'We establish secure connections to your TMS, WMS, ERP, FASTag toll portals, or periodic CSV/Excel batch upload feeds with tenant data isolation.',
    duration: 'Day 3–4',
    deliverables: ['Secure Ingestion Endpoint', 'Isolated Cloud Tenant Workspace', 'Initial Data Load (Raw Dataset)'],
    owner: 'SupplyFlow Team' as const
  },
  {
    stepNumber: 3,
    title: 'Automated Data Validation & Exception Profiling',
    phase: 'INGESTION & MAPPING' as const,
    description: 'Our validation engine screens the dataset for duplicate shipment IDs, missing timestamps, coordinate anomalies, and numeric outliers.',
    duration: 'Day 4–5',
    deliverables: ['Data Quality Health Audit (Completeness, Consistency, Validity)', 'Anomaly Diagnostic Report'],
    owner: 'SupplyFlow Team' as const
  },
  {
    stepNumber: 4,
    title: 'Intelligent Column Mapping to Standard Schema',
    phase: 'INGESTION & MAPPING' as const,
    description: 'We map your proprietary company column headers into SupplyFlow’s canonical logistics data model with zero data loss.',
    duration: 'Day 5–6',
    deliverables: ['Verified Column Schema Map', 'Automated Ingestion Translation Pipeline'],
    owner: 'SupplyFlow Team' as const
  },
  {
    stepNumber: 5,
    title: 'Controlled Data Cleaning & Pipeline Configuration',
    phase: 'CUSTOMIZATION' as const,
    description: 'We configure custom cleaning rules (timestamp normalization, status mapping, handling missing values) while preserving the raw original untouched.',
    duration: 'Day 6–7',
    deliverables: ['Cleaning Rulebook & Audit Log', 'Cleaned Production-Ready Dataset View'],
    owner: 'SupplyFlow Team' as const
  },
  {
    stepNumber: 6,
    title: 'Dashboard & Custom KPI Threshold Configuration',
    phase: 'CUSTOMIZATION' as const,
    description: 'We set up company-specific SLA targets, cost-per-drop benchmarks, fleet utilization models, and automatic anomaly alerting thresholds.',
    duration: 'Day 7–8',
    deliverables: ['Configured Metrics Suite', 'Custom Alert Rules & Triggers'],
    owner: 'Joint Working Group' as const
  },
  {
    stepNumber: 7,
    title: 'Client Visual Branding & Theme Deployment',
    phase: 'CUSTOMIZATION' as const,
    description: 'We apply your official corporate logo, brand colors, custom dashboard titles, and report templates.',
    duration: 'Day 8',
    deliverables: ['Co-Branded Enterprise Interface', 'Branded Executive PDF Report Templates'],
    owner: 'SupplyFlow Team' as const
  },
  {
    stepNumber: 8,
    title: 'Staging Testing & Data Reconciliation',
    phase: 'CUSTOMIZATION' as const,
    description: 'We cross-verify dashboard calculations, delay root causes, and fuel cost numbers against your internal finance and dispatch sheets.',
    duration: 'Day 9–10',
    deliverables: ['Reconciliation Sign-Off Sheet', 'Performance & Load Verification'],
    owner: 'Client Logistics Team' as const
  },
  {
    stepNumber: 9,
    title: 'Formal Client Operational Approval',
    phase: 'DEPLOYMENT & SLA' as const,
    description: 'Executive stakeholders review the live staging command center and approve production deployment.',
    duration: 'Day 10',
    deliverables: ['Executive Rollout Sign-Off'],
    owner: 'Client Logistics Team' as const
  },
  {
    stepNumber: 10,
    title: 'Production Deployment & Team Training',
    phase: 'DEPLOYMENT & SLA' as const,
    description: 'We deploy the dedicated tenant instance and conduct role-based training for dispatchers, hub managers, analysts, and directors.',
    duration: 'Day 11–12',
    deliverables: ['Role-Based User Accounts (RBAC)', 'Dispatcher Quick-Start Guide', 'Recorded Training Sessions'],
    owner: 'SupplyFlow Team' as const
  },
  {
    stepNumber: 11,
    title: 'Ongoing Dedicated SLA Support & Maintenance',
    phase: 'DEPLOYMENT & SLA' as const,
    description: 'We provide continuous data pipeline monitoring, monthly model tuning, new route additions, and priority technical support.',
    duration: 'Ongoing',
    deliverables: ['24/7 Pipeline Monitoring', 'Quarterly Optimization Reviews', 'New Feature Releases'],
    owner: 'SupplyFlow Team' as const
  }
];

