import React from 'react';
import { LogisticsProvider, useLogistics } from './context/LogisticsContext';
import { Sidebar } from './components/layout/Sidebar';
import { AppHeader } from './components/layout/AppHeader';
import { FilterBar } from './components/layout/FilterBar';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { NotificationDrawer } from './components/common/NotificationDrawer';

// Operations Views
import { MainDashboard } from './components/dashboard/MainDashboard';
import { DeliveriesView } from './components/operations/DeliveriesView';
import { RoutesView } from './components/operations/RoutesView';
import { LogisticsMapView } from './components/operations/LogisticsMapView';
import { FleetView } from './components/operations/FleetView';
import { DriversView } from './components/operations/DriversView';
import { RegionsView } from './components/operations/RegionsView';

// Analytics Views
import { PerformanceAnalyticsView } from './components/analytics/PerformanceAnalyticsView';
import { CostAnalyticsView } from './components/analytics/CostAnalyticsView';
import { DemandForecastView } from './components/analytics/DemandForecastView';
import { AnomaliesView } from './components/analytics/AnomaliesView';

// Intelligence Views
import { AiInsightsView } from './components/intelligence/AiInsightsView';
import { AiChatView } from './components/intelligence/AiChatView';
import { AlertsView } from './components/intelligence/AlertsView';

// Data Views
import { DataUploadView } from './components/data/DataUploadView';
import { DataSourcesView } from './components/data/DataSourcesView';
import { DataQualityView } from './components/data/DataQualityView';

// Reporting & Admin Views
import { ReportsView } from './components/reporting/ReportsView';
import { UsersView } from './components/admin/UsersView';
import { SettingsView } from './components/admin/SettingsView';
import { OrganizationsView } from './components/admin/OrganizationsView';
import { OnboardingWizardView } from './components/admin/OnboardingWizardView';
import { AuditLogView } from './components/admin/AuditLogView';
import { LandingView } from './components/landing/LandingView';
import { ImplementationView } from './components/landing/ImplementationView';
import { DemoRequestModal } from './components/landing/DemoRequestModal';

const AppContent: React.FC = () => {
  const { currentView } = useLogistics();

  const renderActiveView = () => {
    switch (currentView) {
      case 'dashboard':
        return <MainDashboard />;
      case 'deliveries':
        return <DeliveriesView />;
      case 'routes':
        return <RoutesView />;
      case 'map':
        return <LogisticsMapView />;
      case 'fleet':
        return <FleetView />;
      case 'drivers':
        return <DriversView />;
      case 'regions':
        return <RegionsView />;
      case 'performance':
        return <PerformanceAnalyticsView />;
      case 'costs':
        return <CostAnalyticsView />;
      case 'demand':
        return <DemandForecastView />;
      case 'anomalies':
        return <AnomaliesView />;
      case 'ai-insights':
        return <AiInsightsView />;
      case 'ai-chat':
        return <AiChatView />;
      case 'alerts':
        return <AlertsView />;
      case 'upload':
        return <DataUploadView />;
      case 'sources':
        return <DataSourcesView />;
      case 'quality':
        return <DataQualityView />;
      case 'reports':
        return <ReportsView />;
      case 'organizations':
        return <OrganizationsView />;
      case 'onboarding':
        return <OnboardingWizardView />;
      case 'audit-log':
        return <AuditLogView />;
      case 'users':
        return <UsersView />;
      case 'settings':
        return <SettingsView />;
      case 'landing':
        return <LandingView />;
      case 'implementation':
        return <ImplementationView />;
      default:
        return <MainDashboard />;
    }
  };

  const showFilterBar =
    currentView !== 'landing' &&
    currentView !== 'implementation' &&
    currentView !== 'onboarding' &&
    currentView !== 'organizations' &&
    currentView !== 'audit-log' &&
    currentView !== 'settings' &&
    currentView !== 'users' &&
    currentView !== 'ai-chat';

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 font-sans text-slate-900 antialiased">
      {/* Dark Navy Primary Navigation Sidebar */}
      <Sidebar />

      {/* Main Workspace Column */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        <AppHeader />
        {showFilterBar && <FilterBar />}

        {/* Dynamic Scrollable Body Area */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50">
          <div className="max-w-7xl mx-auto">
            {renderActiveView()}
          </div>
        </main>
      </div>

      {/* Global Modals & Drawers */}
      <GlobalSearchModal />
      <NotificationDrawer />
      <DemoRequestModal />
    </div>
  );
};

export default function App() {
  return (
    <LogisticsProvider>
      <AppContent />
    </LogisticsProvider>
  );
}
