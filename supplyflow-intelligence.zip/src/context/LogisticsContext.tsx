import React, { createContext, useContext, useState, useMemo, useEffect } from 'react';
import {
  UserRole,
  DataMode,
  DeliveryRecord,
  RouteInfo,
  VehicleInfo,
  DriverInfo,
  RegionalMetric,
  AnomalyRecord,
  AlertRecord,
  AiInsight,
  DataQualityReport,
  DataSourceItem,
  DataFilterState,
  CostBreakdownItem,
  DelayParetoItem,
  DeliveryFunnelStage,
  Organization,
  ColumnMapping,
  DataCleaningStep,
  AuditLogEntry,
  UserAccount
} from '../types';
import {
  INITIAL_DELIVERIES,
  INITIAL_ROUTES,
  INITIAL_VEHICLES,
  INITIAL_DRIVERS,
  INITIAL_REGIONS,
  INITIAL_ANOMALIES,
  INITIAL_ALERTS,
  INITIAL_AI_INSIGHTS,
  INITIAL_DATA_QUALITY,
  INITIAL_DATA_SOURCES,
  INITIAL_COST_BREAKDOWN,
  INITIAL_DELAY_PARETO,
  INITIAL_FUNNEL_STAGES,
  HISTORICAL_30_DAYS,
  INITIAL_ORGANIZATIONS,
  DEFAULT_COLUMN_MAPPINGS,
  INITIAL_AUDIT_LOGS,
  INITIAL_USER_ACCOUNTS
} from '../data/mockLogisticsData';

interface LogisticsContextType {
  // Navigation & Role
  currentView: string;
  setCurrentView: (view: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  
  // Organization / Tenant State
  organizations: Organization[];
  activeOrg: Organization;
  switchOrganization: (orgId: string) => void;
  updateOrganization: (updated: Partial<Organization>) => void;
  createOrganization: (newOrg: Organization) => void;
  currentOrg: string;
  setCurrentOrg: (org: string) => void;
  
  // Users & Access Control
  users: UserAccount[];
  addUser: (user: Omit<UserAccount, 'id' | 'lastActive'>) => void;
  updateUserRole: (id: string, role: UserRole) => void;
  removeUser: (id: string) => void;

  // Audit Logs
  auditLogs: AuditLogEntry[];
  addAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;

  // Column Mapping Engine
  columnMappings: ColumnMapping[];
  updateColumnMapping: (companyCol: string, targetField: string, status: ColumnMapping['status']) => void;
  resetColumnMappings: () => void;

  // Data Cleaning & Transformation Pipeline
  cleaningSteps: DataCleaningStep[];
  applyCleaningAction: (actionKey: string) => void;
  rawDataset: any[];
  processedDataset: any[];
  
  // Data Status & Mode
  dataMode: DataMode;
  setDataMode: (mode: DataMode) => void;
  lastUpdatedTime: string;
  dataPeriodLabel: string;
  isSimulatingLive: boolean;
  setIsSimulatingLive: (val: boolean) => void;

  // Filter State
  filters: DataFilterState;
  setFilters: React.Dispatch<React.SetStateAction<DataFilterState>>;
  resetFilters: () => void;
  updateFilter: <K extends keyof DataFilterState>(key: K, value: DataFilterState[K]) => void;

  // Entities
  deliveries: DeliveryRecord[];
  routes: RouteInfo[];
  vehicles: VehicleInfo[];
  drivers: DriverInfo[];
  regions: RegionalMetric[];
  costBreakdown: CostBreakdownItem[];
  delayPareto: DelayParetoItem[];
  funnelStages: DeliveryFunnelStage[];
  anomalies: AnomalyRecord[];
  alerts: AlertRecord[];
  aiInsights: AiInsight[];
  dataQuality: DataQualityReport;
  dataSources: DataSourceItem[];
  historicalTrend: typeof HISTORICAL_30_DAYS;

  // Filtered Derived Data
  filteredDeliveries: DeliveryRecord[];
  filteredRoutes: RouteInfo[];
  filteredVehicles: VehicleInfo[];
  filteredDrivers: DriverInfo[];
  
  // Calculated KPIs
  kpis: {
    totalDeliveries: number;
    deliveriesTrend: number;
    onTimeRate: number;
    onTimeTrend: number;
    avgDeliveryTimeStr: string;
    avgDeliveryTimeMinutes: number;
    avgDeliveryTimeTrend: string;
    totalCost: number;
    totalCostStr: string;
    costTrend: number;
    costPerDelivery: number;
    costPerDeliveryTrend: number;
    delayedDeliveries: number;
    delayedTrend: number;
    activeVehicles: number;
    totalVehicles: number;
    fleetUtilizationRate: number;
    customerComplaints: number;
    complaintsTrend: number;
  };

  // Actions
  acknowledgeAnomaly: (id: string) => void;
  acknowledgeAlert: (id: string) => void;
  resolveAlert: (id: string) => void;
  addAlert: (alert: Omit<AlertRecord, 'id' | 'timestamp' | 'acknowledged' | 'resolved'>) => void;
  applyUploadedDataset: (cleanedRows: any[], filename: string) => void;
  generateFreshAiInsights: () => Promise<void>;
  isGeneratingAi: boolean;
  aiGenerationError: string | null;

  // Onboarding Wizard State
  onboardingStep: number;
  setOnboardingStep: (step: number) => void;

  // UI state
  notificationOpen: boolean;
  setNotificationOpen: (open: boolean) => void;
  searchModalOpen: boolean;
  setSearchModalOpen: (open: boolean) => void;
  isDemoRequestModalOpen: boolean;
  setIsDemoRequestModalOpen: (open: boolean) => void;
}

const defaultFilters: DataFilterState = {
  dateRange: '30_DAYS',
  selectedRegion: 'ALL',
  selectedRoute: 'ALL',
  selectedVehicleType: 'ALL',
  selectedStatus: 'ALL',
  selectedDelayReason: 'ALL',
  searchQuery: ''
};

const INITIAL_CLEANING_STEPS: DataCleaningStep[] = [
  {
    id: 'cln-01',
    action: 'Deduplicate Records',
    description: 'Scans for matching shipment tracking numbers and keeps the latest timestamp.',
    affectedRows: 18,
    timestamp: '17 Aug 2026, 09:15 AM',
    applied: true
  },
  {
    id: 'cln-02',
    action: 'Standardize Timestamps',
    description: 'Converts diverse date formats (ISO, Unix, DD/MM/YYYY) into unified UTC/IST standards.',
    affectedRows: 24820,
    timestamp: '17 Aug 2026, 09:16 AM',
    applied: true
  },
  {
    id: 'cln-03',
    action: 'Normalize Status Enums',
    description: 'Maps legacy statuses like "DEL", "In-Route", "RTO" into standard canonical lifecycle states.',
    affectedRows: 342,
    timestamp: '17 Aug 2026, 09:18 AM',
    applied: true
  },
  {
    id: 'cln-04',
    action: 'Impute Missing Weights & Distances',
    description: 'Fills missing cargo weight fields using category mean and route corridor distance matrix.',
    affectedRows: 64,
    timestamp: '17 Aug 2026, 09:20 AM',
    applied: true
  }
];

const LogisticsContext = createContext<LogisticsContextType | undefined>(undefined);

export const LogisticsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [userRole, setUserRole] = useState<UserRole>('ADMIN');
  
  // Organization state
  const [organizations, setOrganizations] = useState<Organization[]>(INITIAL_ORGANIZATIONS);
  const [activeOrgId, setActiveOrgId] = useState<string>('org-nexora');
  
  const activeOrg = useMemo(() => {
    return organizations.find(o => o.id === activeOrgId) || organizations[0];
  }, [organizations, activeOrgId]);

  const [currentOrg, setCurrentOrg] = useState<string>(activeOrg.name);

  // Sync currentOrg with activeOrg
  useEffect(() => {
    setCurrentOrg(activeOrg.name);
    setDataMode(activeOrg.dataMode);
  }, [activeOrg]);

  const [users, setUsers] = useState<UserAccount[]>(INITIAL_USER_ACCOUNTS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>(DEFAULT_COLUMN_MAPPINGS);
  const [cleaningSteps, setCleaningSteps] = useState<DataCleaningStep[]>(INITIAL_CLEANING_STEPS);
  const [onboardingStep, setOnboardingStep] = useState<number>(1);
  
  const [dataMode, setDataMode] = useState<DataMode>('DEMO');
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>('17 Aug 2026, 10:42 AM');
  const dataPeriodLabel = '01 Aug – 17 Aug 2026';
  const [isSimulatingLive, setIsSimulatingLive] = useState<boolean>(false);

  const [filters, setFilters] = useState<DataFilterState>(defaultFilters);
  const [notificationOpen, setNotificationOpen] = useState<boolean>(false);
  const [searchModalOpen, setSearchModalOpen] = useState<boolean>(false);
  const [isDemoRequestModalOpen, setIsDemoRequestModalOpen] = useState<boolean>(false);

  // Entities in State
  const [deliveries, setDeliveries] = useState<DeliveryRecord[]>(INITIAL_DELIVERIES);
  const [routes, setRoutes] = useState<RouteInfo[]>(INITIAL_ROUTES);
  const [vehicles, setVehicles] = useState<VehicleInfo[]>(INITIAL_VEHICLES);
  const [drivers, setDrivers] = useState<DriverInfo[]>(INITIAL_DRIVERS);
  const [regions] = useState<RegionalMetric[]>(INITIAL_REGIONS);
  const [costBreakdown] = useState<CostBreakdownItem[]>(INITIAL_COST_BREAKDOWN);
  const [delayPareto] = useState<DelayParetoItem[]>(INITIAL_DELAY_PARETO);
  const [funnelStages] = useState<DeliveryFunnelStage[]>(INITIAL_FUNNEL_STAGES);
  const [anomalies, setAnomalies] = useState<AnomalyRecord[]>(INITIAL_ANOMALIES);
  const [alerts, setAlerts] = useState<AlertRecord[]>(INITIAL_ALERTS);
  const [aiInsights, setAiInsights] = useState<AiInsight[]>(INITIAL_AI_INSIGHTS);
  const [dataQuality, setDataQuality] = useState<DataQualityReport>(INITIAL_DATA_QUALITY);
  const [dataSources] = useState<DataSourceItem[]>(INITIAL_DATA_SOURCES);
  const [historicalTrend] = useState(HISTORICAL_30_DAYS);

  const [rawDataset, setRawDataset] = useState<any[]>(INITIAL_DELIVERIES.slice(0, 25));
  const [processedDataset, setProcessedDataset] = useState<any[]>(INITIAL_DELIVERIES.slice(0, 25));

  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [aiGenerationError, setAiGenerationError] = useState<string | null>(null);

  // Organization operations
  const switchOrganization = (orgId: string) => {
    const found = organizations.find(o => o.id === orgId);
    if (found) {
      setActiveOrgId(orgId);
      addAuditLog({
        user: 'System Admin',
        userRole: userRole,
        action: 'Switched Active Organization Workspace',
        category: 'SECURITY',
        details: `Switched tenant view to "${found.name}" (ID: ${found.id})`,
        status: 'SUCCESS',
        organizationId: orgId
      });
    }
  };

  const updateOrganization = (updated: Partial<Organization>) => {
    setOrganizations(prev => prev.map(org => {
      if (org.id === activeOrgId) {
        return { ...org, ...updated };
      }
      return org;
    }));
    addAuditLog({
      user: 'Admin',
      userRole: userRole,
      action: 'Updated Organization Profile & Branding',
      category: 'SETTINGS_CHANGED',
      details: `Updated parameters for organization: ${Object.keys(updated).join(', ')}`,
      status: 'SUCCESS',
      organizationId: activeOrgId
    });
  };

  const createOrganization = (newOrg: Organization) => {
    setOrganizations(prev => [...prev, newOrg]);
    setActiveOrgId(newOrg.id);
    addAuditLog({
      user: 'Admin',
      userRole: userRole,
      action: 'Created New Client Organization Tenant',
      category: 'SETTINGS_CHANGED',
      details: `Successfully provisioned tenant workspace for "${newOrg.name}"`,
      status: 'SUCCESS',
      organizationId: newOrg.id
    });
  };

  // User management
  const addUser = (user: Omit<UserAccount, 'id' | 'lastActive'>) => {
    const newAcc: UserAccount = {
      ...user,
      id: 'usr-' + Date.now(),
      lastActive: 'Just invited'
    };
    setUsers(prev => [newAcc, ...prev]);
    addAuditLog({
      user: 'Admin',
      userRole: userRole,
      action: 'Added User Account',
      category: 'USER_MANAGEMENT',
      details: `Invited user ${user.name} (${user.email}) with role ${user.role}`,
      status: 'SUCCESS',
      organizationId: activeOrgId
    });
  };

  const updateUserRole = (id: string, role: UserRole) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, role } : u));
    addAuditLog({
      user: 'Admin',
      userRole: userRole,
      action: 'Updated User Role Permissions',
      category: 'USER_MANAGEMENT',
      details: `Updated permissions for user ID ${id} to ${role}`,
      status: 'SUCCESS',
      organizationId: activeOrgId
    });
  };

  const removeUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
    addAuditLog({
      user: 'Admin',
      userRole: userRole,
      action: 'Removed User Account',
      category: 'USER_MANAGEMENT',
      details: `Removed access for user ID ${id}`,
      status: 'WARNING',
      organizationId: activeOrgId
    });
  };

  // Audit logging helper
  const addAuditLog = (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => {
    const newEntry: AuditLogEntry = {
      ...entry,
      id: 'aud-' + Date.now(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' })
    };
    setAuditLogs(prev => [newEntry, ...prev]);
  };

  // Column mapping methods
  const updateColumnMapping = (companyCol: string, targetField: string, status: ColumnMapping['status']) => {
    setColumnMappings(prev => prev.map(m => {
      if (m.companyColumn === companyCol) {
        return { ...m, targetField, status };
      }
      return m;
    }));
  };

  const resetColumnMappings = () => {
    setColumnMappings(DEFAULT_COLUMN_MAPPINGS);
  };

  // Data cleaning methods
  const applyCleaningAction = (actionKey: string) => {
    setCleaningSteps(prev => prev.map(s => {
      if (s.id === actionKey || s.action.toLowerCase().includes(actionKey.toLowerCase())) {
        return { ...s, applied: true, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
      }
      return s;
    }));
    addAuditLog({
      user: 'Data Analyst',
      userRole: userRole,
      action: `Executed Data Cleaning Task: ${actionKey}`,
      category: 'DATA_CLEAN',
      details: `Applied rule "${actionKey}" on active dataset schema.`,
      status: 'SUCCESS',
      organizationId: activeOrgId
    });
  };

  // Live simulation tick when toggled
  useEffect(() => {
    if (!isSimulatingLive) return;
    const interval = setInterval(() => {
      const now = new Date();
      setLastUpdatedTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setDataMode('LIVE');
    }, 10000);
    return () => clearInterval(interval);
  }, [isSimulatingLive]);

  const updateFilter = <K extends keyof DataFilterState>(key: K, value: DataFilterState[K]) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  // Filtered deliveries
  const filteredDeliveries = useMemo(() => {
    return deliveries.filter(item => {
      if (filters.selectedRegion !== 'ALL' && item.region !== filters.selectedRegion) return false;
      if (filters.selectedRoute !== 'ALL' && item.routeId !== filters.selectedRoute) return false;
      if (filters.selectedStatus !== 'ALL' && item.status !== filters.selectedStatus) return false;
      if (filters.selectedDelayReason !== 'ALL' && item.delayReason !== filters.selectedDelayReason) return false;
      if (filters.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        const matchTracking = item.trackingNumber.toLowerCase().includes(q);
        const matchCustomer = item.customerName.toLowerCase().includes(q);
        const matchCity = item.destinationCity.toLowerCase().includes(q) || item.originCity.toLowerCase().includes(q);
        if (!matchTracking && !matchCustomer && !matchCity) return false;
      }
      return true;
    });
  }, [deliveries, filters]);

  // Filtered routes
  const filteredRoutes = useMemo(() => {
    return routes.filter(rt => {
      if (filters.selectedRegion !== 'ALL' && rt.region !== filters.selectedRegion) return false;
      if (filters.selectedRoute !== 'ALL' && rt.id !== filters.selectedRoute) return false;
      return true;
    });
  }, [routes, filters]);

  // Filtered vehicles
  const filteredVehicles = useMemo(() => {
    return vehicles.filter(v => {
      if (filters.selectedRegion !== 'ALL' && v.region !== filters.selectedRegion) return false;
      if (filters.selectedVehicleType !== 'ALL' && v.type !== filters.selectedVehicleType) return false;
      return true;
    });
  }, [vehicles, filters]);

  // Filtered drivers
  const filteredDrivers = useMemo(() => {
    return drivers.filter(d => {
      if (filters.selectedRegion !== 'ALL' && d.region !== filters.selectedRegion) return false;
      return true;
    });
  }, [drivers, filters]);

  // Dynamic KPIs calculated
  const kpis = useMemo(() => {
    const isFiltered = filters.selectedRegion !== 'ALL' || filters.selectedRoute !== 'ALL';
    
    // Scale baseline by date filter
    let multiplier = 1;
    if (filters.dateRange === 'TODAY') multiplier = 0.04;
    else if (filters.dateRange === 'YESTERDAY') multiplier = 0.04;
    else if (filters.dateRange === '7_DAYS') multiplier = 0.25;
    else if (filters.dateRange === '30_DAYS') multiplier = 1;
    else if (filters.dateRange === '90_DAYS') multiplier = 2.8;
    else if (filters.dateRange === 'THIS_MONTH') multiplier = 0.6;
    else if (filters.dateRange === 'PREVIOUS_MONTH') multiplier = 1;

    if (isFiltered) {
      const total = Math.round((filteredDeliveries.length > 0 ? filteredDeliveries.length * 280 : 3420) * multiplier);
      const delayed = Math.round(total * 0.082);
      const onTimeRate = 91.8;
      const costTotal = total * 342;
      return {
        totalDeliveries: total,
        deliveriesTrend: 5.4,
        onTimeRate: onTimeRate,
        onTimeTrend: 0.8,
        avgDeliveryTimeStr: '4h 12m',
        avgDeliveryTimeMinutes: 252,
        avgDeliveryTimeTrend: '-8m',
        totalCost: costTotal,
        totalCostStr: `₹${(costTotal / 100000).toFixed(2)}L`,
        costTrend: -2.1,
        costPerDelivery: 342,
        costPerDeliveryTrend: -8,
        delayedDeliveries: delayed,
        delayedTrend: -3.2,
        activeVehicles: filteredVehicles.filter(v => v.currentStatus === 'ACTIVE').length,
        totalVehicles: Math.max(1, filteredVehicles.length),
        fleetUtilizationRate: 86.4,
        customerComplaints: Math.max(1, Math.round(total * 0.009)),
        complaintsTrend: -12.0
      };
    }

    // Default global scale metrics
    const totalDeliveries = Math.round(24820 * multiplier);
    const totalCostVal = Math.round(842000 * multiplier);
    const costLakhs = (totalCostVal / 100000).toFixed(2);
    return {
      totalDeliveries,
      deliveriesTrend: 8.4,
      onTimeRate: 92.6,
      onTimeTrend: 1.2,
      avgDeliveryTimeStr: '4h 18m',
      avgDeliveryTimeMinutes: 258,
      avgDeliveryTimeTrend: '-12m',
      totalCost: totalCostVal,
      totalCostStr: `₹${costLakhs}L`,
      costTrend: -3.1,
      costPerDelivery: 339,
      costPerDeliveryTrend: -14,
      delayedDeliveries: Math.round(1824 * multiplier),
      delayedTrend: -5.3,
      activeVehicles: 186,
      totalVehicles: 210,
      fleetUtilizationRate: 88.5,
      customerComplaints: Math.max(2, Math.round(248 * multiplier)),
      complaintsTrend: -18.2
    };
  }, [filters, filteredDeliveries, filteredVehicles]);

  const acknowledgeAnomaly = (id: string) => {
    setAnomalies(prev => prev.map(a => a.id === id ? { ...a, acknowledged: true } : a));
    addAuditLog({
      user: 'Operations Lead',
      userRole: userRole,
      action: 'Acknowledged Operational Anomaly',
      category: 'SETTINGS_CHANGED',
      details: `Acknowledged anomaly #${id}`,
      status: 'SUCCESS',
      organizationId: activeOrgId
    });
  };

  const acknowledgeAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, acknowledged: true } : a));
  };

  const resolveAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, resolved: true, acknowledged: true } : a));
    addAuditLog({
      user: 'Dispatcher',
      userRole: userRole,
      action: 'Resolved Operational Alert',
      category: 'SETTINGS_CHANGED',
      details: `Resolved alert ticket #${id}`,
      status: 'SUCCESS',
      organizationId: activeOrgId
    });
  };

  const addAlert = (alertData: Omit<AlertRecord, 'id' | 'timestamp' | 'acknowledged' | 'resolved'>) => {
    const newAlert: AlertRecord = {
      ...alertData,
      id: 'alt-' + Date.now(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      acknowledged: false,
      resolved: false
    };
    setAlerts(prev => [newAlert, ...prev]);
  };

  const applyUploadedDataset = (cleanedRows: any[], filename: string) => {
    if (cleanedRows.length > 0) {
      const adapted: DeliveryRecord[] = cleanedRows.map((r, i) => ({
        id: r.id || `upl-${i}`,
        trackingNumber: r.trackingNumber || `TRK-UPL-${10000 + i}`,
        customerName: r.customerName || 'Verified Commercial Consignee',
        destinationCity: r.destinationCity || 'Regional Hub',
        originCity: r.originCity || 'Chennai Central',
        region: r.region || 'Tamil Nadu',
        routeId: r.routeId || 'rt-tn-042',
        vehicleId: r.vehicleId || 'veh-01',
        driverId: r.driverId || 'drv-01',
        status: (r.status as any) || 'DELIVERED',
        orderTimestamp: r.orderTimestamp || new Date().toISOString(),
        dispatchTimestamp: r.dispatchTimestamp || new Date().toISOString(),
        expectedDelivery: r.expectedDelivery || new Date().toISOString(),
        delayMinutes: Number(r.delayMinutes) || 0,
        delayReason: r.delayReason || undefined,
        packageWeightKg: Number(r.packageWeightKg) || 150,
        packageType: r.packageType || 'Standard',
        deliveryCost: Number(r.deliveryCost) || 340,
        fuelCost: Number(r.fuelCost) || 120,
        distanceKm: Number(r.distanceKm) || 280,
        customerRating: 5,
        complaintLogged: Boolean(r.complaintLogged)
      }));

      setDeliveries(adapted);
      setRawDataset(cleanedRows.slice(0, 25));
      setProcessedDataset(adapted.slice(0, 25));
      setDataMode('CUSTOM_UPLOAD');
      setDataQuality(prev => ({
        ...prev,
        totalRows: cleanedRows.length,
        cleanRows: cleanedRows.length,
        lastAssessed: `Uploaded: ${filename} (${new Date().toLocaleTimeString()})`
      }));

      addAuditLog({
        user: 'Data Analyst',
        userRole: userRole,
        action: 'Imported Custom Company Dataset',
        category: 'DATA_IMPORT',
        details: `Successfully loaded ${cleanedRows.length} rows from ${filename} with column schema mapping.`,
        status: 'SUCCESS',
        organizationId: activeOrgId
      });

      setCurrentView('dashboard');
    }
  };

  const generateFreshAiInsights = async () => {
    setIsGeneratingAi(true);
    setAiGenerationError(null);
    try {
      const summaryPayload = {
        organization: activeOrg.name,
        kpis,
        topDelayReason: 'Traffic Congestion (39%)',
        troubledRoute: 'TN-042 (18.4% delay rate, ₹382 cost/drop)',
        regionalPerformance: regions.map(r => ({
          region: r.region,
          onTimeRate: r.onTimeRate,
          costPerDelivery: r.costPerDelivery
        }))
      };

      const res = await fetch('/api/ai/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ metricsSummary: summaryPayload, scope: 'Network-Wide Optimization' })
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (data.insights && Array.isArray(data.insights) && data.insights.length > 0) {
        setAiInsights(data.insights);
      }
    } catch (err: any) {
      console.warn('AI insight fetch fallback applied:', err);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  return (
    <LogisticsContext.Provider
      value={{
        currentView,
        setCurrentView,
        userRole,
        setUserRole,
        organizations,
        activeOrg,
        switchOrganization,
        updateOrganization,
        createOrganization,
        currentOrg,
        setCurrentOrg,
        users,
        addUser,
        updateUserRole,
        removeUser,
        auditLogs,
        addAuditLog,
        columnMappings,
        updateColumnMapping,
        resetColumnMappings,
        cleaningSteps,
        applyCleaningAction,
        rawDataset,
        processedDataset,
        dataMode,
        setDataMode,
        lastUpdatedTime,
        dataPeriodLabel,
        isSimulatingLive,
        setIsSimulatingLive,
        filters,
        setFilters,
        resetFilters,
        updateFilter,
        deliveries,
        routes,
        vehicles,
        drivers,
        regions,
        costBreakdown,
        delayPareto,
        funnelStages,
        anomalies,
        alerts,
        aiInsights,
        dataQuality,
        dataSources,
        historicalTrend,
        filteredDeliveries,
        filteredRoutes,
        filteredVehicles,
        filteredDrivers,
        kpis,
        acknowledgeAnomaly,
        acknowledgeAlert,
        resolveAlert,
        addAlert,
        applyUploadedDataset,
        generateFreshAiInsights,
        isGeneratingAi,
        aiGenerationError,
        onboardingStep,
        setOnboardingStep,
        notificationOpen,
        setNotificationOpen,
        searchModalOpen,
        setSearchModalOpen,
        isDemoRequestModalOpen,
        setIsDemoRequestModalOpen
      }}
    >
      {children}
    </LogisticsContext.Provider>
  );
};

export const useLogistics = (): LogisticsContextType => {
  const context = useContext(LogisticsContext);
  if (!context) {
    throw new Error('useLogistics must be used within a LogisticsProvider');
  }
  return context;
};
