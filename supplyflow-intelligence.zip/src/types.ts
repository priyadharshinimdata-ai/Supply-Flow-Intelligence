export type UserRole = 'ADMIN' | 'LOGISTICS_MANAGER' | 'DATA_ANALYST' | 'VIEWER';

export type DeliveryStatus = 'ORDER_PLACED' | 'DISPATCHED' | 'IN_TRANSIT' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'RETURNED' | 'DELAYED' | 'EXCEPTION';

export type DelayReason = 
  | 'Traffic Congestion'
  | 'Warehouse Dispatch Delay'
  | 'Loading / Dock Delay'
  | 'Severe Weather'
  | 'Incorrect Customer Address'
  | 'Driver Schedule Delay'
  | 'Vehicle Breakdown'
  | 'Customer Unavailable'
  | 'Documentation / Toll Check'
  | 'Other';

export type AlertSeverity = 'CRITICAL' | 'HIGH' | 'ATTENTION' | 'INFO';

export type DataMode = 'LIVE' | 'DATA_DELAYED' | 'DEMO' | 'CUSTOM_UPLOAD';

export interface DeliveryRecord {
  id: string;
  trackingNumber: string;
  customerName: string;
  destinationCity: string;
  originCity: string;
  region: string;
  routeId: string;
  vehicleId: string;
  driverId: string;
  status: DeliveryStatus;
  orderTimestamp: string;
  dispatchTimestamp: string;
  expectedDelivery: string;
  actualDelivery?: string;
  delayMinutes: number;
  delayReason?: DelayReason;
  packageWeightKg: number;
  packageType: 'Standard' | 'Express' | 'Fragile' | 'Heavy Cargo' | 'Cold Chain';
  deliveryCost: number; // in INR ₹
  fuelCost: number;
  distanceKm: number;
  customerRating?: number; // 1-5
  complaintLogged: boolean;
  complaintReason?: string;
  lat?: number;
  lng?: number;
}

export interface RouteInfo {
  id: string;
  code: string;
  name: string;
  origin: string;
  destination: string;
  region: string;
  distanceKm: number;
  expectedDurationMins: number;
  avgActualDurationMins: number;
  totalShipments: number;
  delayRate: number; // percentage (e.g., 18.4)
  avgFuelCost: number;
  costPerDelivery: number;
  status: 'EFFICIENT' | 'OPTIMAL' | 'NEEDS_ATTENTION' | 'CRITICAL';
  primaryDelayCause: DelayReason;
  coordinates: {
    origin: [number, number]; // [lat, lng]
    destination: [number, number];
    waypoints?: [number, number][];
  };
}

export interface VehicleInfo {
  id: string;
  plateNumber: string;
  type: 'Light Commercial (LCV)' | 'Medium Truck (MCV)' | 'Heavy Hauler (HCV)' | 'Electric Van (EV)' | 'Refrigerated Truck';
  assignedDriverId: string;
  assignedDriverName: string;
  region: string;
  currentStatus: 'ACTIVE' | 'IDLE' | 'MAINTENANCE' | 'OUT_OF_SERVICE';
  fuelType: 'Diesel' | 'EV' | 'CNG';
  fuelEfficiencyKmPerUnit: number; // km/l or km/kWh
  totalDistanceKm: number;
  activeOperatingHours: number;
  availableOperatingHours: number;
  utilizationRate: number; // percentage
  fuelConsumptionUnits: number;
  deliveriesCompleted: number;
  lastMaintenanceDate: string;
  nextServiceDueKm: number;
  healthScore: number; // 0-100
}

export interface DriverInfo {
  id: string;
  name: string;
  employeeCode: string;
  avatar?: string;
  region: string;
  assignedVehicleId: string;
  totalDeliveries: number;
  onTimeRate: number; // percentage e.g. 94.5
  avgDeliveryDurationMins: number;
  totalDistanceKm: number;
  complaintsReceived: number;
  delayRate: number;
  operationalPerformanceScore: number; // 0-100 neutral fair index
  safetyRating: number; // 1-5
  status: 'ON_DUTY' | 'ON_BREAK' | 'OFF_DUTY' | 'LEAVE';
  phone: string;
}

export interface RegionalMetric {
  region: string;
  hubCity: string;
  totalDeliveries: number;
  revenue: number;
  totalCost: number;
  delayRate: number;
  onTimeRate: number;
  customerComplaints: number;
  avgDeliveryTimeHours: number;
  activeVehicles: number;
  activeRoutes: number;
  costPerDelivery: number;
  growthRate: number; // %
}

export interface AnomalyRecord {
  id: string;
  metric: string;
  entityType: 'REGION' | 'ROUTE' | 'VEHICLE' | 'WAREHOUSE' | 'COST';
  entityName: string;
  currentValue: string;
  baselineValue: string;
  deviationPercent: number; // e.g. +23.4
  severity: AlertSeverity;
  detectedAt: string;
  description: string;
  possibleRootCause: string;
  recommendedInvestigation: string;
  acknowledged: boolean;
}

export interface AlertRecord {
  id: string;
  severity: AlertSeverity;
  category: 'SLA_BREACH' | 'COST_SPIKE' | 'ROUTE_DEVIATION' | 'FLEET_MAINTENANCE' | 'VOLUME_SURGE' | 'QUALITY_ANOMALY';
  title: string;
  message: string;
  entityRef?: string;
  timestamp: string;
  acknowledged: boolean;
  resolved: boolean;
  thresholdConfig?: {
    metric: string;
    threshold: number | string;
    actual: number | string;
  };
}

export interface AiInsight {
  id: string;
  category: 'PERFORMANCE' | 'COST_SAVINGS' | 'ROUTE_OPTIMIZATION' | 'DEMAND_SURGE' | 'RISK_MITIGATION';
  keyInsight: string;
  possibleDriver: string;
  investigationSuggestion: string;
  opportunity: string;
  confidenceScore: number; // 0-100
  impactEstimate: string; // e.g. "Save ₹45,000/month"
  source: 'Generated from dashboard data';
  timestamp: string;
  relatedEntity?: string;
}

export type DataRangeOption = 
  | 'TODAY' 
  | 'YESTERDAY' 
  | '7_DAYS' 
  | '30_DAYS' 
  | '90_DAYS' 
  | 'THIS_MONTH' 
  | 'PREVIOUS_MONTH' 
  | 'CUSTOM';

export interface DataFilterState {
  dateRange: DataRangeOption;
  customStartDate?: string;
  customEndDate?: string;
  selectedRegion: string; // 'ALL' or specific
  selectedRoute: string; // 'ALL' or specific
  selectedVehicleType: string; // 'ALL' or specific
  selectedStatus: string; // 'ALL' or specific
  selectedDelayReason: string; // 'ALL' or specific
  searchQuery: string;
}

export interface Organization {
  id: string;
  name: string;
  industry: 'Courier & Parcel' | 'E-Commerce Logistics' | '3PL Freight Distribution' | 'Manufacturing & Linehaul' | 'Cold Chain Logistics' | 'Warehousing & Fulfillment';
  country: string;
  contactPerson: string;
  contactEmail: string;
  logo: string;
  primaryBrandColor: string; // Hex e.g. #0284c7
  secondaryBrandColor: string; // Hex e.g. #0f172a
  dashboardTitle: string;
  timezone: string;
  dataMode: DataMode;
  createdAt: string;
  kpiTargets: {
    targetOnTimeRate: number; // e.g. 95.0
    maxDelayToleranceMins: number; // e.g. 30
    targetCostPerDelivery: number; // e.g. 320
    targetFleetUtilization: number; // e.g. 88
  };
}

export interface ColumnMapping {
  companyColumn: string;
  targetField: string;
  status: 'MAPPED' | 'UNMAPPED' | 'AUTO_SUGGESTED' | 'INVALID';
  confidence: number;
  sampleValue: string;
  required: boolean;
  dataType: 'string' | 'number' | 'date' | 'enum';
}

export interface DataCleaningStep {
  id: string;
  action: string;
  description: string;
  affectedRows: number;
  timestamp: string;
  applied: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  userRole: UserRole;
  action: string;
  category: 'DATA_IMPORT' | 'DATA_CLEAN' | 'USER_MANAGEMENT' | 'REPORT_GENERATED' | 'SETTINGS_CHANGED' | 'SECURITY';
  details: string;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
  organizationId: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  organizationId: string;
  status: 'ACTIVE' | 'INVITED' | 'SUSPENDED';
  lastActive: string;
  avatar?: string;
  assignedRegion?: string;
}

export interface ClientImplementationStep {
  stepNumber: number;
  title: string;
  phase: 'DISCOVERY' | 'INGESTION & MAPPING' | 'CUSTOMIZATION' | 'DEPLOYMENT & SLA';
  description: string;
  duration: string;
  deliverables: string[];
  owner: 'SupplyFlow Team' | 'Client Logistics Team' | 'Joint Working Group';
}

export interface DataQualityReport {
  overallScore: number; // e.g. 94%
  totalRows: number;
  cleanRows: number;
  duplicatesRemoved: number;
  missingValuesImputed: number;
  invalidDatesFixed: number;
  outliersFlagged: number;
  completenessScore: number;
  accuracyScore: number;
  consistencyScore: number;
  timelinessScore: number;
  duplicateRateScore: number;
  lastAssessed: string;
}

export interface DataSourceItem {
  id: string;
  name: string;
  type: 'REST_API' | 'POSTGRES_DB' | 'CSV_BATCH' | 'WMS_INTEGRATION' | 'MANUAL_UPLOAD';
  status: 'HEALTHY' | 'SYNCING' | 'ERROR' | 'PAUSED';
  lastSyncTimestamp: string;
  recordsIngested: number;
  qualityScore: number;
  endpointUrl?: string;
  syncFrequency: 'Near Real-Time (5m)' | 'Hourly' | 'Daily Batch (12:00 AM)' | 'Manual';
}

export interface ForecastPoint {
  date: string;
  actual?: number;
  forecast?: number;
  lowerConfidence?: number;
  upperConfidence?: number;
  isModelEstimate: boolean;
}

export interface CostBreakdownItem {
  category: string;
  amount: number; // in INR
  percentage: number;
  trend: number; // + / - %
  subCategories: { name: string; amount: number }[];
}

export interface DelayParetoItem {
  reason: DelayReason;
  count: number;
  percentage: number;
  cumulativePercentage: number;
  costImpact: number;
  primaryRegion: string;
}

export interface DeliveryFunnelStage {
  stage: string;
  count: number;
  percentageOfTotal: number;
  dropOffCount: number;
  dropOffRate: number;
  isBottleneck: boolean;
}
