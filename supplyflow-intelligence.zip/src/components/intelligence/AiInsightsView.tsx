import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Sparkles,
  RefreshCw,
  TrendingUp,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Brain,
  Lightbulb,
  Zap
} from 'lucide-react';

export const AiInsightsView: React.FC = () => {
  const { aiInsights, generateFreshAiInsights, isGeneratingAi, setCurrentView } = useLogistics();

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">AI Intelligence & Operations Recommendations</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Automated machine reasoning analyzing 24,800+ freight logs to detect hidden bottlenecks, route optimizations, and cost-reduction opportunities.
          </p>
        </div>

        <button
          onClick={() => generateFreshAiInsights()}
          disabled={isGeneratingAi}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold shadow-sm transition-colors flex items-center gap-2 disabled:opacity-50 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
          <span>{isGeneratingAi ? 'Synthesizing Insights...' : 'Re-Run Intelligence Engine'}</span>
        </button>
      </div>

      {/* Dark Intelligence Showcase Banner */}
      <div className="bg-[#0F172A] rounded-xl p-6 shadow-xl text-white">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-sky-500 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-sky-500/30">
            <Brain className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">SupplyFlow Neural Engine v4.2</h2>
            <p className="text-xs text-slate-400">Continuous telemetry parsing across 4 regional clusters & 10 key corridors</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 bg-slate-800/90 rounded-lg border-l-4 border-sky-400">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sky-400 block mb-1">
              CORRIDOR PERFORMANCE
            </span>
            <p className="text-slate-300">
              Shifting 18 night-haul departures on <strong className="text-white">Route TN-042</strong> to 04:00 AM saves ~₹42,000 monthly fuel waste.
            </p>
          </div>

          <div className="p-3.5 bg-slate-800/90 rounded-lg border-l-4 border-emerald-400">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400 block mb-1">
              NETWORK SLA UPSIDE
            </span>
            <p className="text-slate-300">
              Cross-docking Vijayawada cargo directly at Hyderabad hub improves overall network On-Time SLA from <strong className="text-white">92.6% to 94.8%</strong>.
            </p>
          </div>

          <div className="p-3.5 bg-slate-800/90 rounded-lg border-l-4 border-amber-400">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400 block mb-1">
              DOCK CAPACITY BOTTLENECK
            </span>
            <p className="text-slate-300">
              Coimbatore Depot queue delay averages <strong className="text-white">52 mins</strong> between 16:00 and 19:00 due to un-staggered vendor arrivals.
            </p>
          </div>
        </div>
      </div>

      {/* Comprehensive List of Structured AI Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {aiInsights.map((insight, idx) => (
          <div
            key={insight.id || idx}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-sky-300 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                  {insight.category || 'Strategic Optimization'}
                </span>
                <span className="text-xs font-mono font-bold text-slate-500">
                  {insight.confidenceScore}% Confidence
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 mb-2 leading-snug">
                {insight.keyInsight}
              </h3>

              <div className="space-y-2.5 text-xs text-slate-600 mb-4">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="font-bold text-slate-700 block mb-0.5 text-[11px]">Underlying Driver:</span>
                  <p>{insight.possibleDriver}</p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="font-bold text-slate-700 block mb-0.5 text-[11px]">Recommended Opportunity:</span>
                  <p className="text-slate-800 font-medium">{insight.opportunity}</p>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs font-extrabold text-emerald-600 font-mono">
                {insight.impactEstimate}
              </span>
              <button
                onClick={() => setCurrentView('ai-chat')}
                className="text-xs font-bold text-sky-700 hover:text-sky-900 flex items-center gap-1"
              >
                Discuss with AI Analyst <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
