import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Bell,
  CheckCircle,
  AlertOctagon,
  ShieldCheck,
  RotateCcw,
  Clock,
  ArrowRight,
  Filter
} from 'lucide-react';
import { SeverityBadge } from '../common/StatusBadge';

export const AlertsView: React.FC = () => {
  const { alerts, acknowledgeAlert, resolveAlert } = useLogistics();

  const unackCount = alerts.filter(a => !a.acknowledged).length;
  const criticalCount = alerts.filter(a => a.severity === 'CRITICAL' && !a.resolved).length;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Active Operational Alerts &amp; SLA Exception Center</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time threshold breaches, geofence deviations, mechanical breakdown telematics, and customer SLA escalations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-bold px-3 py-1.5 bg-rose-50 text-rose-700 rounded-lg border border-rose-200">
            {criticalCount} Critical Exceptions
          </span>
          <span className="text-xs font-bold px-3 py-1.5 bg-amber-50 text-amber-700 rounded-lg border border-amber-200">
            {unackCount} Unacknowledged
          </span>
        </div>
      </div>

      {/* Alerts Table / Feed */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="divide-y divide-slate-100">
          {alerts.map(alert => (
            <div
              key={alert.id}
              className={`p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors ${
                alert.resolved
                  ? 'bg-slate-50/60 opacity-70'
                  : !alert.acknowledged
                  ? 'bg-rose-50/30'
                  : 'hover:bg-slate-50'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  <SeverityBadge severity={alert.severity} />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold text-sky-700">{alert.entityRef || alert.category}</span>
                    <span className="text-slate-300">•</span>
                    <span className="text-xs text-slate-400 font-mono">{alert.timestamp}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">{alert.title}</h3>
                  <p className="text-xs text-slate-600 mt-0.5">{alert.message}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                {!alert.acknowledged && (
                  <button
                    onClick={() => acknowledgeAlert(alert.id)}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                  >
                    Acknowledge
                  </button>
                )}

                {!alert.resolved ? (
                  <button
                    onClick={() => resolveAlert(alert.id)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <CheckCircle className="w-3.5 h-3.5" /> Mark Resolved
                  </button>
                ) : (
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                    ✓ Resolved
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
