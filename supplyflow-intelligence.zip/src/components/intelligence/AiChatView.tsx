import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Bot,
  Send,
  Sparkles,
  User,
  RotateCcw,
  Zap,
  TrendingDown,
  Clock,
  DollarSign,
  AlertTriangle
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedAction?: {
    label: string;
    view: string;
  };
}

export const AiChatView: React.FC = () => {
  const { kpis, setCurrentView } = useLogistics();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'assistant',
      text: 'Good day! I am your AI Logistics Intelligence Analyst. I have real-time access to the current 24,820 delivery logs, corridor telemetry, vehicle utilization, and cost breakdowns. What would you like to investigate?',
      timestamp: '10:42 AM'
    },
    {
      id: '2',
      sender: 'user',
      text: 'Why is Route TN-042 (Chennai to Coimbatore) flagging a 18.4% delay rate and high fuel costs?',
      timestamp: '10:43 AM'
    },
    {
      id: '3',
      sender: 'assistant',
      text: 'Deep-dive analysis on Route TN-042 indicates two primary factors:\n\n1. **Highway Bottleneck**: Heavy road repaving on NH-544 between Vellore and Salem holds nighttime haulage for an average of 86 minutes.\n2. **Engine Idling**: Telematics show heavy trucks idle with cabin AC running during traffic queues, adding ~₹38,400 in unnecessary monthly fuel expense.\n\n**Recommendation**: Reschedule primary long-haul departures to 04:00 AM to bypass peak night highway congestions and bypass Salem junction.',
      timestamp: '10:43 AM',
      suggestedAction: {
        label: 'View Route TN-042 In Corridor Analytics',
        view: 'routes'
      }
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');

  const quickPrompts = [
    'How can we reduce our ₹339 cost per delivery to the ₹325 target?',
    'What are the top 3 root causes of delivery delays this month?',
    'Which regional hub has the highest SLA grievance rate?',
    'How will weekend peak volume impact our 210-vehicle fleet?'
  ];

  const handleSend = (textToSend?: string) => {
    const q = textToSend || inputQuery;
    if (!q.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');

    // Generate intelligent contextual response
    setTimeout(() => {
      let reply = '';
      let action: { label: string; view: string } | undefined;

      if (q.toLowerCase().includes('cost') || q.toLowerCase().includes('₹339') || q.toLowerCase().includes('325')) {
        reply = `To bridge the ₹14/drop gap from ₹339 to ₹325:\n\n1. **Eliminate Engine Idling**: Curtail truck idling on congested corridors (saves ₹8.40/drop).\n2. **Stagger Warehouse Docks**: Reduce driver overtime at Vijayawada and Coimbatore hubs (saves ₹4.20/drop).\n3. **Consolidate LTL Shipments**: Group smaller regional parcels onto heavy 10-ton vehicles to raise capacity utilization from 88.5% to 92.0% (saves ₹2.80/drop).`;
        action = { label: 'Explore Cost Intelligence', view: 'costs' };
      } else if (q.toLowerCase().includes('delay') || q.toLowerCase().includes('causes')) {
        reply = `Pareto analysis reveals:\n\n1. **Traffic Congestion (38.2%)**: Concentrated around Chennai, Bengaluru, and Vellore bypass.\n2. **Warehouse Dispatch Queue (23.8%)**: Late packing slips during morning shifts.\n3. **Loading Dock Holds (14.2%)**: Un-staggered vendor bay access.\n\nResolving the top 2 issues addresses 62.0% of all SLA delays across the network.`;
        action = { label: 'Open Performance Analytics', view: 'performance' };
      } else {
        reply = `Based on current network telemetry across 24,820 consignments: our average transit time is 4h 18m with a 92.6% On-Time SLA. Fleet utilization is at 88.5% across 210 active transport units. Would you like me to model a specific route or region?`;
        action = { label: 'Go to Command Dashboard', view: 'dashboard' };
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedAction: action
      };

      setMessages(prev => [...prev, aiMsg]);
    }, 600);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">AI Logistics Chat Analyst</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Ask natural language questions regarding transit bottlenecks, vehicle telematics, route costs, or demand forecasts.
          </p>
        </div>

        <button
          onClick={() => {
            setMessages([messages[0]]);
          }}
          className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Clear Conversation
        </button>
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col h-[560px] overflow-hidden">
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-[#0F172A] text-sky-400 flex items-center justify-center shrink-0 border border-slate-800 shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-2xl rounded-xl p-4 text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-sky-600 text-white rounded-tr-none'
                    : 'bg-slate-50 text-slate-800 border border-slate-200 rounded-tl-none'
                }`}
              >
                <div className="flex items-center justify-between gap-4 mb-1">
                  <span className={`font-bold ${msg.sender === 'user' ? 'text-sky-100' : 'text-slate-900'}`}>
                    {msg.sender === 'user' ? 'Operations Manager' : 'SupplyFlow AI Analyst'}
                  </span>
                  <span className={`text-[10px] ${msg.sender === 'user' ? 'text-sky-200' : 'text-slate-400'}`}>
                    {msg.timestamp}
                  </span>
                </div>

                <p className="whitespace-pre-line">{msg.text}</p>

                {msg.suggestedAction && (
                  <div className="mt-3 pt-2.5 border-t border-slate-200 flex justify-start">
                    <button
                      onClick={() => setCurrentView(msg.suggestedAction!.view)}
                      className="px-3 py-1 bg-white hover:bg-sky-50 text-sky-700 font-bold rounded-md border border-sky-200 transition-colors shadow-2xs flex items-center gap-1.5"
                    >
                      <Zap className="w-3 h-3 text-sky-600" />
                      {msg.suggestedAction.label}
                    </button>
                  </div>
                )}
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-800 flex items-center justify-center font-bold text-xs shrink-0 border border-sky-200">
                  OM
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Quick Prompt Chips */}
        <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center gap-2 overflow-x-auto">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0">Quick Ask:</span>
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-sky-50 hover:border-sky-300 text-slate-700 hover:text-sky-800 text-[11px] font-medium rounded-full border border-slate-200 transition-colors cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center gap-3">
          <input
            type="text"
            placeholder="Ask about shipment delays, driver safety index, route fuel burn, or cost models..."
            value={inputQuery}
            onChange={e => setInputQuery(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') handleSend();
            }}
            className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-sky-500 font-medium"
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputQuery.trim()}
            className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
