import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { MetricCard } from '../common/MetricCard';
import { DeliveryStatusBadge, SeverityBadge, DataModeBadge } from '../common/StatusBadge';
import {
  Truck,
  CheckCircle2,
  Clock,
  DollarSign,
  AlertTriangle,
  Users,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  RotateCw,
  Zap,
  Info,
  Calendar,
  Layers,
  MapPin
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  Line,
  ComposedChart
} from 'recharts';

export const MainDashboard: React.FC = () => {
  const {
    kpis,
    userRole,
    currentOrg,
    lastUpdatedTime,
    dataPeriodLabel,
    dataMode,
    funnelStages,
    delayPareto,
    historicalTrend,
    anomalies,
    aiInsights,
    setCurrentView,
    updateFilter,
    routes,
    generateFreshAiInsights,
    isGeneratingAi
  } = useLogistics();

  const [performanceViewRange, setPerformanceViewRange] = useState<'7D' | '30D'>('30D');

  const chartData = performanceViewRange === '7D'
    ? historicalTrend.slice(-7)
    : historicalTrend;

  const troubledRoute = routes.find(r => r.code === 'TN-042') || routes[0];
  const primaryAnomaly = anomalies.find(a => !a.acknowledged) || anomalies[0];
  const topInsight = aiInsights[0];

  const roleGreetings: Record<string, string> = {
    ADMIN: 'Operations Administrator',
    LOGISTICS_MANAGER: 'Operations Manager',
    DATA_ANALYST: 'Lead Data Analyst',
    VIEWER: 'Logistics Executive'
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* 1. Header & Data Connection Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 rounded-2xl p-6 text-white shadow-xl border border-slate-700/60 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 font-mono">
                Logistics Command Center
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-xs text-slate-300">{currentOrg}</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white">
              Good morning, {roleGreetings[userRole] || 'Logistics Leader'}
            </h1>
            <p className="text-xs lg:text-sm text-slate-300 mt-1 max-w-2xl">
              Turn raw logistics data into immediate operational action. Current fleet health is at <strong>92.6% On-Time SLA</strong> across 24,820 consignments.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-800/80 backdrop-blur-xs p-3 rounded-xl border border-slate-700 text-right">
              <div className="flex items-center justify-end gap-2 mb-1">
                <DataModeBadge mode={dataMode} />
              </div>
              <p className="text-[11px] text-slate-400">
                Last Data Refresh: <span className="font-mono text-slate-200 font-bold">{lastUpdatedTime}</span>
              </p>
              <p className="text-[10px] text-slate-500">
                Active Assessment: {dataPeriodLabel}
              </p>
            </div>

            <button
              onClick={() => generateFreshAiInsights()}
              disabled={isGeneratingAi}
              className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-900/40 flex items-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
            >
              <Sparkles className={`w-4 h-4 text-cyan-200 ${isGeneratingAi ? 'animate-spin' : ''}`} />
              <span>{isGeneratingAi ? 'Synthesizing Data...' : 'Run AI Analysis'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Key Operational Narrative Strip (What? Where? Why? Action?) */}
      <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-blue-600 text-white shrink-0 mt-0.5">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-800 font-mono">
              Operational Status in 5 Seconds
            </span>
            <p className="text-xs text-slate-800 font-medium leading-relaxed mt-0.5">
              <strong>1. What:</strong> Delivery SLA is healthy (92.6%) but cost per delivery spiked +₹18 on Route TN-042.<br />
              <strong>2. Where:</strong> Chennai ➔ Coimbatore arterial corridor.<br />
              <strong>3. Why:</strong> Vellore-Salem highway bottleneck + Vijayawada warehouse queue.<br />
              <strong>4. Action:</strong> Reroute nighttime freight through SH-188 or reschedule departure to 04:00 AM.
            </p>
          </div>
        </div>

        <button
          onClick={() => setCurrentView('anomalies')}
          className="whitespace-nowrap px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 shrink-0"
        >
          Investigate Anomalies <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 3. The 8 KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="kpi-total-deliveries"
          title="Total Deliveries"
          value={kpis.totalDeliveries.toLocaleString()}
          trendPercent={kpis.deliveriesTrend}
          tooltipText="Total count of completed, in-transit, and scheduled shipments across all hubs."
          sparklineData={[740, 780, 830, 860, 890, 940, 1020]}
          icon={<Truck className="w-4 h-4 text-blue-600" />}
          comparisonText="vs previous 30d (22,900)"
          accentColor="blue"
          onClick={() => setCurrentView('deliveries')}
        />

        <MetricCard
          id="kpi-on-time-rate"
          title="On-Time Delivery Rate"
          value={`${kpis.onTimeRate}%`}
          trendPercent={kpis.onTimeTrend}
          tooltipText="Percentage of shipments delivered on or before the committed Customer SLA window."
          sparklineData={[93.5, 93.8, 93.3, 92.7, 92.3, 91.9, 92.6]}
          icon={<CheckCircle2 className="w-4 h-4 text-emerald-600" />}
          comparisonText="Target SLA: ≥ 95.0%"
          accentColor="emerald"
          onClick={() => setCurrentView('performance')}
        />

        <MetricCard
          id="kpi-avg-delivery-time"
          title="Average Delivery Time"
          value={kpis.avgDeliveryTimeStr}
          trendPercent={-2.8}
          isInverseTrendPositive={true}
          tooltipText="Average transit elapsed duration from hub dock dispatch to customer door completion."
          sparklineData={[260, 258, 252, 255, 264, 270, 258]}
          icon={<Clock className="w-4 h-4 text-cyan-600" />}
          comparisonText={`${kpis.avgDeliveryTimeTrend} vs last month (4h 30m)`}
          accentColor="cyan"
          onClick={() => setCurrentView('performance')}
        />

        <MetricCard
          id="kpi-total-delivery-cost"
          title="Total Delivery Cost"
          value={kpis.totalCostStr}
          trendPercent={kpis.costTrend}
          isInverseTrendPositive={true}
          tooltipText="Aggregated operational expenses: fuel, driver compensation, maintenance, tolls, and warehousing."
          sparklineData={[280, 290, 305, 314, 323, 341, 352]}
          icon={<DollarSign className="w-4 h-4 text-indigo-600" />}
          comparisonText="Cost budget: ₹8.70L"
          accentColor="indigo"
          onClick={() => setCurrentView('costs')}
        />

        <MetricCard
          id="kpi-cost-per-delivery"
          title="Cost Per Delivery"
          value={`₹${kpis.costPerDelivery}`}
          trendPercent={-4.0}
          isInverseTrendPositive={true}
          tooltipText="Calculated as: Total Operational Logistics Cost / Total Delivered Orders."
          sparklineData={[358, 352, 348, 346, 342, 340, 339]}
          icon={<DollarSign className="w-4 h-4 text-emerald-600" />}
          comparisonText="Benchmark target: ₹325"
          accentColor="emerald"
          onClick={() => setCurrentView('costs')}
        />

        <MetricCard
          id="kpi-delayed-deliveries"
          title="Delayed Deliveries"
          value={kpis.delayedDeliveries.toLocaleString()}
          trendPercent={kpis.delayedTrend}
          isInverseTrendPositive={true}
          tooltipText="Total shipments that missed expected delivery ETA due to traffic, warehouse holds, or weather."
          sparklineData={[48, 52, 60, 68, 76, 84, 75]}
          icon={<Clock className="w-4 h-4 text-amber-600" />}
          comparisonText="7.4% of total network load"
          accentColor="amber"
          onClick={() => setCurrentView('deliveries')}
        />

        <MetricCard
          id="kpi-active-vehicles"
          title="Fleet Utilization"
          value={`${kpis.activeVehicles} / ${kpis.totalVehicles}`}
          trendPercent={+3.2}
          tooltipText="Active vehicles operating on routes divided by total commercial fleet size (88.5% utilization)."
          sparklineData={[170, 172, 178, 180, 182, 185, 186]}
          icon={<Truck className="w-4 h-4 text-blue-600" />}
          comparisonText="14 Idle • 10 In Maintenance"
          accentColor="blue"
          onClick={() => setCurrentView('fleet')}
        />

        <MetricCard
          id="kpi-customer-complaints"
          title="Customer Complaints"
          value={kpis.customerComplaints}
          trendPercent={kpis.complaintsTrend}
          isInverseTrendPositive={true}
          tooltipText="Total formal complaints logged regarding transit delays, address issues, or package condition."
          sparklineData={[34, 31, 28, 26, 22, 19, 18]}
          icon={<AlertTriangle className="w-4 h-4 text-rose-600" />}
          comparisonText="Complaint rate: 0.99%"
          accentColor="rose"
          onClick={() => setCurrentView('deliveries')}
        />
      </div>

      {/* 4. Main Performance Trend & Pareto Delay Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Delivery Performance Line/Area Chart */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Delivery Performance Trend</h2>
              <p className="text-xs text-slate-500">Tracking Total Deliveries vs On-Time vs Delayed consignments</p>
            </div>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-semibold">
              <button
                onClick={() => setPerformanceViewRange('7D')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  performanceViewRange === '7D' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Last 7 Days
              </button>
              <button
                onClick={() => setPerformanceViewRange('30D')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  performanceViewRange === '30D' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Last 30 Days
              </button>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorDeliveries" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorOnTime" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorDelayed" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Area type="monotone" dataKey="deliveries" name="Total Shipments" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#colorDeliveries)" />
                <Area type="monotone" dataKey="onTime" name="On-Time Delivered" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorOnTime)" />
                <Area type="monotone" dataKey="delayed" name="Delayed Deliveries" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorDelayed)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right 1 Col: Delay Reason Pareto Analysis */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Delay Causes (Pareto)</h2>
                <p className="text-xs text-slate-500">Root causes accounting for 80% of delay volume</p>
              </div>
              <button
                onClick={() => setCurrentView('performance')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800"
              >
                Deep Dive
              </button>
            </div>

            <div className="space-y-3">
              {delayPareto.slice(0, 5).map((item, i) => (
                <div key={item.reason} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-800 truncate font-semibold">{i + 1}. {item.reason}</span>
                    <span className="text-slate-500 font-mono">{item.count} ({item.percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                    <div
                      className={`h-full rounded-full ${
                        i === 0 ? 'bg-rose-500' : i === 1 ? 'bg-amber-500' : 'bg-blue-500'
                      }`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Cost Impact: ₹{(item.costImpact / 1000).toFixed(1)}k</span>
                    <span className="truncate max-w-[150px]">{item.primaryRegion}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-600">
            <strong>Key Pareto Takeaway:</strong> Traffic congestion and warehouse dispatch account for <strong>62.0%</strong> of all SLA delays across the network.
          </div>
        </div>
      </div>

      {/* 5. Delivery Funnel Stage Breakdown */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">Shipment Pipeline Funnel</h2>
            <p className="text-xs text-slate-500">Order lifecycle conversion from intake to customer completion</p>
          </div>
          <span className="text-xs font-bold px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-200">
            93.7% Final Delivery Conversion
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {funnelStages.map((stage, idx) => (
            <div
              key={stage.stage}
              className={`p-3.5 rounded-xl border text-center relative ${
                stage.isBottleneck
                  ? 'bg-amber-50/60 border-amber-300 ring-1 ring-amber-300'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              {stage.isBottleneck && (
                <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-amber-600 text-white uppercase tracking-wider shadow-xs">
                  Largest Drop-off
                </span>
              )}
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide mb-1 truncate">
                {stage.stage}
              </div>
              <div className="text-lg font-extrabold text-slate-900 font-mono">
                {stage.count.toLocaleString()}
              </div>
              <div className="text-xs font-semibold text-blue-700 mt-0.5">
                {stage.percentageOfTotal}%
              </div>
              <div className="text-[10px] text-slate-400 mt-2 pt-2 border-t border-slate-200/60">
                {idx > 0 ? (
                  <span>Drop: <strong className="text-slate-600">-{stage.dropOffCount}</strong> ({stage.dropOffRate}%)</span>
                ) : (
                  <span>Pipeline Intake</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Spotlight Dual Cards: Troubled Route Spotlight & Active Anomaly Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Route Inefficiency Highlight */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-2 mb-3">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Critical Inefficiency Spotlight
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1.5 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  Route {troubledRoute.code}: {troubledRoute.name}
                </h3>
              </div>
              <span className="px-2.5 py-1 rounded-md text-xs font-extrabold bg-red-100 text-red-800 border border-red-200">
                🔴 Needs Attention
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 my-4 p-3 bg-slate-50 rounded-lg text-center font-mono">
              <div>
                <span className="block text-[10px] text-slate-400 font-sans font-semibold">Delay Rate</span>
                <span className="text-lg font-extrabold text-rose-600">{troubledRoute.delayRate}%</span>
                <span className="block text-[10px] text-slate-400 font-sans">Net Avg: 7.8%</span>
              </div>
              <div>
                <span className="block text-[10px] text-slate-400 font-sans font-semibold">Cost / Drop</span>
                <span className="text-lg font-extrabold text-slate-800">₹{troubledRoute.costPerDelivery}</span>
                <span className="block text-[10px] text-slate-400 font-sans">+12.7% dev.</span>
              </div>
              <div>
                <span className="block text-[10px] text-slate-400 font-sans font-semibold">Monthly Fuel</span>
                <span className="text-lg font-extrabold text-slate-800">₹{(troubledRoute.avgFuelCost / 1000).toFixed(1)}k</span>
                <span className="block text-[10px] text-slate-400 font-sans">High idle drain</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>Root Cause:</strong> Vellore-Salem highway maintenance work causes 90+ min evening traffic holds. Heavy trucks idle for extensive periods, driving fuel burn and late delivery penalties.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">Recommended: Shift freight departure to 04:00 AM</span>
            <button
              onClick={() => {
                updateFilter('selectedRoute', troubledRoute.id);
                setCurrentView('routes');
              }}
              className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
            >
              Route Details <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* AI Insight Spotlight */}
        <div className="bg-gradient-to-br from-slate-900 to-blue-950 p-5 rounded-xl border border-slate-800 text-white shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400">
                    AI Logistics Intelligence
                  </span>
                  <h3 className="text-sm font-bold text-white leading-tight">
                    {topInsight.keyInsight}
                  </h3>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                {topInsight.confidenceScore}% Confidence
              </span>
            </div>

            <div className="space-y-2.5 my-3 text-xs text-slate-300">
              <div className="p-2.5 bg-slate-800/60 rounded-lg border border-slate-700/60">
                <span className="text-[11px] font-bold text-cyan-300 block mb-0.5">Probable Driver:</span>
                <p className="text-slate-300">{topInsight.possibleDriver}</p>
              </div>

              <div className="p-2.5 bg-slate-800/60 rounded-lg border border-slate-700/60">
                <span className="text-[11px] font-bold text-emerald-400 block mb-0.5">Value Opportunity:</span>
                <p className="text-slate-200">{topInsight.opportunity}</p>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-emerald-400 font-bold font-mono">{topInsight.impactEstimate}</span>
            <button
              onClick={() => setCurrentView('ai-insights')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
            >
              Explore All AI Insights <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
