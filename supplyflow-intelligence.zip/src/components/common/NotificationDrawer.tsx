import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { X, Bell, CheckCircle, AlertTriangle, ArrowRight, ShieldCheck } from 'lucide-react';
import { SeverityBadge } from './StatusBadge';

export const NotificationDrawer: React.FC = () => {
  const {
    notificationOpen,
    setNotificationOpen,
    alerts,
    acknowledgeAlert,
    resolveAlert,
    setCurrentView
  } = useLogistics();

  if (!notificationOpen) return null;

  const unackAlerts = alerts.filter(a => !a.acknowledged);
  const resolvedAlerts = alerts.filter(a => a.resolved);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
        onClick={() => setNotificationOpen(false)}
      />
      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl border-l border-slate-200 flex flex-col">
          {/* Header */}
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-600" />
              <h2 className="text-base font-bold text-slate-900">Operations Alerts & Notifications</h2>
              {unackAlerts.length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700 border border-red-200">
                  {unackAlerts.length} New
                </span>
              )}
            </div>
            <button
              onClick={() => setNotificationOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Alerts List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {alerts.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500 mb-2 stroke-1" />
                <p className="text-sm font-semibold text-slate-700">All systems operating within threshold</p>
                <p className="text-xs text-slate-500 mt-1">No active critical exceptions</p>
              </div>
            ) : (
              alerts.map(alert => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-xl border transition-all ${
                    alert.resolved
                      ? 'bg-slate-50 border-slate-200 opacity-60'
                      : !alert.acknowledged
                      ? 'bg-red-50/40 border-red-200 shadow-xs'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <SeverityBadge severity={alert.severity} />
                    <span className="text-[11px] font-medium text-slate-400 font-mono">{alert.timestamp}</span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 leading-snug">{alert.title}</h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{alert.message}</p>

                  {alert.thresholdConfig && (
                    <div className="mt-2.5 p-2 bg-slate-100/80 rounded text-[11px] font-mono text-slate-700 flex justify-between">
                      <span>Threshold: <strong>{alert.thresholdConfig.threshold}</strong></span>
                      <span className="text-red-700 font-bold">Actual: {alert.thresholdConfig.actual}</span>
                    </div>
                  )}

                  <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setCurrentView('alerts');
                        setNotificationOpen(false);
                      }}
                      className="text-xs font-semibold text-blue-700 hover:text-blue-900 inline-flex items-center gap-1"
                    >
                      Investigate <ArrowRight className="w-3 h-3" />
                    </button>

                    <div className="flex gap-2">
                      {!alert.acknowledged && (
                        <button
                          onClick={() => acknowledgeAlert(alert.id)}
                          className="text-xs px-2.5 py-1 font-semibold rounded bg-slate-200 hover:bg-slate-300 text-slate-800"
                        >
                          Acknowledge
                        </button>
                      )}
                      {!alert.resolved && (
                        <button
                          onClick={() => resolveAlert(alert.id)}
                          className="text-xs px-2.5 py-1 font-semibold rounded bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" /> Resolve
                        </button>
                      )}
                      {alert.resolved && (
                        <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" /> Resolved
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              {resolvedAlerts.length} resolved of {alerts.length} total
            </span>
            <button
              onClick={() => {
                setCurrentView('alerts');
                setNotificationOpen(false);
              }}
              className="text-xs font-bold text-blue-700 hover:underline"
            >
              Configure Alert Thresholds
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
