import React from 'react';
import { DeliveryStatus, AlertSeverity, DataMode } from '../../types';
import { CheckCircle2, Clock, AlertTriangle, AlertOctagon, Info, Sparkles, RefreshCw, XCircle, Truck, PackageCheck } from 'lucide-react';

export const DeliveryStatusBadge: React.FC<{ status: DeliveryStatus; className?: string }> = ({ status, className = '' }) => {
  switch (status) {
    case 'DELIVERED':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 ${className}`}>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          Delivered
        </span>
      );
    case 'OUT_FOR_DELIVERY':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 ${className}`}>
          <Truck className="w-3.5 h-3.5 text-blue-600" />
          Out for Delivery
        </span>
      );
    case 'IN_TRANSIT':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-50 text-cyan-700 border border-cyan-200 ${className}`}>
          <RefreshCw className="w-3.5 h-3.5 text-cyan-600 animate-spin" style={{ animationDuration: '6s' }} />
          In Transit
        </span>
      );
    case 'DISPATCHED':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 ${className}`}>
          <PackageCheck className="w-3.5 h-3.5 text-indigo-600" />
          Dispatched
        </span>
      );
    case 'DELAYED':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 ${className}`}>
          <Clock className="w-3.5 h-3.5 text-amber-600" />
          Delayed
        </span>
      );
    case 'RETURNED':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 ${className}`}>
          <XCircle className="w-3.5 h-3.5 text-rose-600" />
          Returned / RTO
        </span>
      );
    case 'EXCEPTION':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-200 ${className}`}>
          <AlertOctagon className="w-3.5 h-3.5 text-red-600" />
          Exception
        </span>
      );
    default:
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200 ${className}`}>
          {status}
        </span>
      );
  }
};

export const SeverityBadge: React.FC<{ severity: AlertSeverity; className?: string }> = ({ severity, className = '' }) => {
  switch (severity) {
    case 'CRITICAL':
      return (
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-red-100 text-red-800 border border-red-300 ${className}`}>
          <AlertOctagon className="w-3.5 h-3.5 text-red-600" />
          🔴 CRITICAL
        </span>
      );
    case 'HIGH':
      return (
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 ${className}`}>
          <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
          🟠 HIGH
        </span>
      );
    case 'ATTENTION':
      return (
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-yellow-100 text-yellow-900 border border-yellow-300 ${className}`}>
          <AlertTriangle className="w-3.5 h-3.5 text-yellow-700" />
          🟡 ATTENTION
        </span>
      );
    case 'INFO':
      return (
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300 ${className}`}>
          <Info className="w-3.5 h-3.5 text-blue-600" />
          🔵 INFO
        </span>
      );
  }
};

export const DataModeBadge: React.FC<{ mode: DataMode; className?: string }> = ({ mode, className = '' }) => {
  switch (mode) {
    case 'LIVE':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-xs ${className}`}>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          🟢 LIVE DATA
        </span>
      );
    case 'DATA_DELAYED':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-300 shadow-xs ${className}`}>
          <span className="w-2 h-2 rounded-full bg-amber-500"></span>
          🟠 DATA DELAYED
        </span>
      );
    case 'CUSTOM_UPLOAD':
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-800 border border-indigo-300 shadow-xs ${className}`}>
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          CUSTOM DATASET
        </span>
      );
    case 'DEMO':
    default:
      return (
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-300 shadow-xs ${className}`}>
          <span className="w-2 h-2 rounded-full bg-blue-600"></span>
          DEMO ENVIRONMENT
        </span>
      );
  }
};
