import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { Search, X, Truck, MapPin, AlertTriangle, User, Package, ArrowRight } from 'lucide-react';
import { DeliveryStatusBadge } from './StatusBadge';

export const GlobalSearchModal: React.FC = () => {
  const {
    searchModalOpen,
    setSearchModalOpen,
    deliveries,
    routes,
    vehicles,
    drivers,
    anomalies,
    setCurrentView,
    updateFilter
  } = useLogistics();

  const [query, setQuery] = useState('');

  if (!searchModalOpen) return null;

  const q = query.trim().toLowerCase();

  const matchedDeliveries = q ? deliveries.filter(d => 
    d.trackingNumber.toLowerCase().includes(q) ||
    d.customerName.toLowerCase().includes(q) ||
    d.destinationCity.toLowerCase().includes(q)
  ).slice(0, 4) : [];

  const matchedRoutes = q ? routes.filter(r => 
    r.code.toLowerCase().includes(q) ||
    r.name.toLowerCase().includes(q) ||
    r.origin.toLowerCase().includes(q) ||
    r.destination.toLowerCase().includes(q)
  ).slice(0, 3) : [];

  const matchedVehicles = q ? vehicles.filter(v => 
    v.plateNumber.toLowerCase().includes(q) ||
    v.type.toLowerCase().includes(q)
  ).slice(0, 3) : [];

  const matchedDrivers = q ? drivers.filter(d => 
    d.name.toLowerCase().includes(q) ||
    d.employeeCode.toLowerCase().includes(q)
  ).slice(0, 3) : [];

  const handleSelectDelivery = (tracking: string) => {
    updateFilter('searchQuery', tracking);
    setCurrentView('deliveries');
    setSearchModalOpen(false);
  };

  const handleSelectRoute = (routeId: string) => {
    updateFilter('selectedRoute', routeId);
    setCurrentView('routes');
    setSearchModalOpen(false);
  };

  const handleSelectVehicle = () => {
    setCurrentView('fleet');
    setSearchModalOpen(false);
  };

  const handleSelectDriver = () => {
    setCurrentView('drivers');
    setSearchModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Search Input */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 gap-3">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            autoFocus
            type="text"
            placeholder="Search tracking #, customer, route, vehicle plate, or driver..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="flex-1 text-slate-900 placeholder-slate-400 text-sm outline-hidden font-medium"
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 text-slate-400 hover:text-slate-600 rounded">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setSearchModalOpen(false)}
            className="text-xs font-semibold px-2 py-1 bg-slate-100 text-slate-600 rounded border border-slate-200 hover:bg-slate-200"
          >
            ESC
          </button>
        </div>

        {/* Search Results */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-4">
          {!q && (
            <div className="py-8 text-center text-slate-400">
              <Package className="w-10 h-10 mx-auto mb-2 text-slate-300 stroke-1" />
              <p className="text-sm font-medium">Type to search across the logistics network</p>
              <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-xs">
                <span className="text-slate-500 font-semibold">Try:</span>
                <button onClick={() => setQuery('TN-042')} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded">TN-042</button>
                <button onClick={() => setQuery('SF-2026-98124')} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded">SF-2026-98124</button>
                <button onClick={() => setQuery('Rajesh')} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded">Rajesh</button>
                <button onClick={() => setQuery('Electric')} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded">Electric Van</button>
              </div>
            </div>
          )}

          {q && (
            <>
              {/* Deliveries */}
              {matchedDeliveries.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5" /> Deliveries & Consignments
                  </h4>
                  <div className="space-y-1.5">
                    {matchedDeliveries.map(del => (
                      <div
                        key={del.id}
                        onClick={() => handleSelectDelivery(del.trackingNumber)}
                        className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 cursor-pointer transition-colors"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-blue-700">{del.trackingNumber}</span>
                            <DeliveryStatusBadge status={del.status} />
                          </div>
                          <p className="text-xs text-slate-600 mt-0.5">{del.customerName} • {del.originCity} ➔ {del.destinationCity}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Routes */}
              {matchedRoutes.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" /> Routes
                  </h4>
                  <div className="space-y-1.5">
                    {matchedRoutes.map(rt => (
                      <div
                        key={rt.id}
                        onClick={() => handleSelectRoute(rt.id)}
                        className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 cursor-pointer transition-colors"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-slate-800">{rt.code}</span>
                            <span className="text-xs text-slate-600">{rt.name}</span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">{rt.distanceKm} km • Delay: {rt.delayRate}% • Cost/Drop: ₹{rt.costPerDelivery}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Vehicles */}
              {matchedVehicles.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5" /> Fleet Vehicles
                  </h4>
                  <div className="space-y-1.5">
                    {matchedVehicles.map(veh => (
                      <div
                        key={veh.id}
                        onClick={handleSelectVehicle}
                        className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 cursor-pointer transition-colors"
                      >
                        <div>
                          <span className="font-mono text-xs font-bold text-slate-800">{veh.plateNumber}</span>
                          <span className="text-xs text-slate-600 ml-2">({veh.type})</span>
                          <p className="text-[11px] text-slate-500 mt-0.5">Driver: {veh.assignedDriverName} • Utilization: {veh.utilizationRate}%</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Drivers */}
              {matchedDrivers.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" /> Drivers
                  </h4>
                  <div className="space-y-1.5">
                    {matchedDrivers.map(drv => (
                      <div
                        key={drv.id}
                        onClick={handleSelectDriver}
                        className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-200 cursor-pointer transition-colors"
                      >
                        <div>
                          <span className="text-xs font-bold text-slate-800">{drv.name}</span>
                          <span className="font-mono text-xs text-slate-500 ml-2">({drv.employeeCode})</span>
                          <p className="text-[11px] text-slate-500 mt-0.5">Region: {drv.region} • On-Time: {drv.onTimeRate}% • Deliveries: {drv.totalDeliveries}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-400" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {matchedDeliveries.length === 0 && matchedRoutes.length === 0 && matchedVehicles.length === 0 && matchedDrivers.length === 0 && (
                <div className="py-8 text-center text-slate-500">
                  <p className="text-sm">No results found for "{query}"</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
