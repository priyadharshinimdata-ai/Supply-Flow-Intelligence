import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus, HelpCircle } from 'lucide-react';

interface MetricCardProps {
  id: string;
  title: string;
  value: string | number;
  comparisonText?: string;
  trendPercent?: number; // e.g. +8.4 or -3.1
  isInverseTrendPositive?: boolean; // For metrics like 'Delays', 'Cost', 'Complaints' where negative trend is good
  tooltipText: string;
  sparklineData?: number[];
  icon?: React.ReactNode;
  lastUpdated?: string;
  onClick?: () => void;
  accentColor?: 'blue' | 'emerald' | 'amber' | 'rose' | 'indigo' | 'cyan';
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  title,
  value,
  comparisonText = 'vs previous 30-day period',
  trendPercent,
  isInverseTrendPositive = false,
  tooltipText,
  sparklineData,
  icon,
  lastUpdated,
  onClick,
  accentColor = 'blue'
}) => {
  const isPositiveNumber = trendPercent !== undefined && trendPercent > 0;
  const isNegativeNumber = trendPercent !== undefined && trendPercent < 0;
  
  const isGoodTrend = isInverseTrendPositive ? isNegativeNumber : isPositiveNumber;
  const isBadTrend = isInverseTrendPositive ? isPositiveNumber : isNegativeNumber;

  const barColor = isGoodTrend ? 'bg-emerald-500' : isBadTrend ? 'bg-rose-500' : 'bg-sky-500';

  return (
    <div
      id={id}
      onClick={onClick}
      className={`bg-white p-4 rounded-xl border border-slate-200 shadow-sm transition-all duration-200 hover:border-slate-300 ${
        onClick ? 'cursor-pointer hover:shadow-md' : ''
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 group relative">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">{title}</p>
          <div className="relative">
            <HelpCircle className="w-3 h-3 text-slate-400 cursor-help" />
            <div className="absolute left-0 bottom-full mb-2 hidden group-hover:block z-30 w-52 p-2 bg-slate-900 text-white text-[11px] rounded-lg shadow-xl pointer-events-none leading-relaxed">
              {tooltipText}
            </div>
          </div>
        </div>
        {icon && <div className="text-slate-400">{icon}</div>}
      </div>

      <h3 className="text-2xl font-bold text-slate-800 mt-1 font-mono tracking-tight">{value}</h3>

      <div className="flex items-center gap-2 mt-2">
        {trendPercent !== undefined && (
          <span
            className={`text-xs font-semibold flex items-center gap-0.5 ${
              isGoodTrend ? 'text-emerald-600' : isBadTrend ? 'text-rose-600' : 'text-slate-600'
            }`}
          >
            {isPositiveNumber ? <ArrowUpRight className="w-3.5 h-3.5" /> : isNegativeNumber ? <ArrowDownRight className="w-3.5 h-3.5" /> : <Minus className="w-3 h-3" />}
            {isPositiveNumber ? `+${trendPercent}%` : `${trendPercent}%`}
          </span>
        )}

        {/* Progress Bar Indicator */}
        <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden">
          <div
            className={`h-full ${barColor} transition-all duration-500`}
            style={{ width: `${Math.min(100, Math.max(25, Math.abs(trendPercent || 50) * 8))}%` }}
          />
        </div>
      </div>

      {/* Footer Subtext */}
      <div className="text-[11px] text-slate-400 mt-2 truncate">
        {comparisonText}
      </div>
    </div>
  );
};
