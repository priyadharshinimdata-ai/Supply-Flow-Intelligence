import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Search,
  Bell,
  Activity,
  Shield,
  Building2,
  Calendar,
  Sparkles,
  ExternalLink,
  ChevronDown,
  Layers,
  Plus,
  Rocket,
  CheckCircle2
} from 'lucide-react';
import { UserRole } from '../../types';

export const AppHeader: React.FC = () => {
  const {
    currentOrg,
    activeOrg,
    organizations,
    switchOrganization,
    userRole,
    setUserRole,
    dataMode,
    setDataMode,
    lastUpdatedTime,
    dataPeriodLabel,
    isSimulatingLive,
    setIsSimulatingLive,
    alerts,
    setNotificationOpen,
    setSearchModalOpen,
    currentView,
    setCurrentView,
    setIsDemoRequestModalOpen
  } = useLogistics();

  const [orgDropdownOpen, setOrgDropdownOpen] = useState(false);
  const unackAlertsCount = alerts.filter(a => !a.acknowledged).length;

  const roleLabels: Record<UserRole, { title: string; badge: string }> = {
    ADMIN: { title: 'System Administrator', badge: 'AD' },
    LOGISTICS_MANAGER: { title: 'Operations Manager', badge: 'OM' },
    DATA_ANALYST: { title: 'Lead Data Analyst', badge: 'DA' },
    VIEWER: { title: 'Executive Viewer', badge: 'EV' }
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 flex flex-col shrink-0">
      {/* Top Utility / Live Status Strip */}
      <div className="bg-slate-900 text-slate-300 px-6 py-1.5 text-xs flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${isSimulatingLive ? 'bg-emerald-400 animate-pulse' : dataMode === 'DEMO' ? 'bg-amber-400' : 'bg-emerald-500'}`}></span>
            <span className="text-[11px] font-semibold text-slate-200">
              {dataMode === 'LIVE' ? 'LIVE TELEMETRY STREAM' : dataMode === 'CUSTOM_UPLOAD' ? 'CUSTOM TENANT DATASET' : 'DEMO ENVIRONMENT (SOUTH INDIA)'}
            </span>
            <span className="text-[11px] text-slate-400">
              • Updated: <strong className="text-slate-200 font-mono">{lastUpdatedTime}</strong>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-1.5 text-[11px] text-slate-400 border-l border-slate-700 pl-3">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Scope: <strong className="text-slate-200">{dataPeriodLabel}</strong></span>
          </div>

          <button
            onClick={() => {
              const next = !isSimulatingLive;
              setIsSimulatingLive(next);
              if (next) setDataMode('LIVE');
              else setDataMode(activeOrg.dataMode);
            }}
            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider transition-colors flex items-center gap-1 cursor-pointer ${
              isSimulatingLive
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
            }`}
          >
            <Activity className="w-3 h-3" />
            {isSimulatingLive ? 'Live Simulation Active' : 'Simulate Live Stream'}
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsDemoRequestModalOpen(true)}
            className="px-2.5 py-0.5 bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 rounded text-[11px] font-bold transition-colors cursor-pointer flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3 text-sky-400" /> Request Commercial Demo
          </button>

          {currentView === 'landing' ? (
            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-2.5 py-0.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-bold transition-colors cursor-pointer"
            >
              Open Console
            </button>
          ) : (
            <button
              onClick={() => setCurrentView('landing')}
              className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
            >
              Commercial Page <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="h-16 px-6 lg:px-8 flex items-center justify-between gap-4">
        {/* Left: Organization Tenant Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setOrgDropdownOpen(!orgDropdownOpen)}
            className="flex items-center gap-2.5 p-1.5 -ml-1.5 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-all text-left cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-lg shadow-2xs">
              {activeOrg.logo}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-slate-900 group-hover:text-sky-600 transition-colors">
                  {activeOrg.name}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </div>
              <p className="text-[11px] text-slate-500 flex items-center gap-1.5">
                <span>{activeOrg.industry}</span>
                <span className="text-slate-300">•</span>
                <span className="font-mono text-[10px] bg-slate-100 text-slate-600 px-1 py-0.2 rounded">
                  {activeOrg.dataMode}
                </span>
              </p>
            </div>
          </button>

          {/* Org Switcher Menu Popover */}
          {orgDropdownOpen && (
            <div className="absolute top-12 left-0 w-80 bg-white rounded-xl border border-slate-200 shadow-xl p-2 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Switch Organization Tenant
              </div>
              <div className="space-y-1 max-h-60 overflow-y-auto py-1">
                {organizations.map(org => {
                  const isSelected = org.id === activeOrg.id;
                  return (
                    <button
                      key={org.id}
                      onClick={() => {
                        switchOrganization(org.id);
                        setOrgDropdownOpen(false);
                      }}
                      className={`w-full flex items-center justify-between p-2 rounded-lg text-left text-xs transition-colors cursor-pointer ${
                        isSelected ? 'bg-sky-50 text-sky-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{org.logo}</span>
                        <div>
                          <p className="font-semibold leading-tight">{org.name}</p>
                          <span className="text-[10px] text-slate-400">{org.industry}</span>
                        </div>
                      </div>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                    </button>
                  );
                })}
              </div>
              <div className="border-t border-slate-100 pt-1 mt-1">
                <button
                  onClick={() => {
                    setOrgDropdownOpen(false);
                    setCurrentView('onboarding');
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-sky-600 hover:bg-sky-50 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Onboard New Organization
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-3 lg:gap-4">
          {/* Search trigger */}
          <button
            onClick={() => setSearchModalOpen(true)}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg text-xs text-slate-500 w-52 lg:w-64 transition-colors cursor-pointer"
          >
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <span className="flex-1 text-left">Search shipments, routes...</span>
            <kbd className="font-mono text-[10px] px-1.5 py-0.5 bg-white text-slate-500 rounded border border-slate-300">⌘K</kbd>
          </button>

          {/* AI Quick Button */}
          <button
            onClick={() => setCurrentView('ai-chat')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden md:inline">AI Analyst</span>
          </button>

          {/* Notifications Button */}
          <button
            onClick={() => setNotificationOpen(true)}
            className="relative p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
            title="Operations Alerts & Notifications"
          >
            <Bell className="w-4 h-4" />
            {unackAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white">
                {unackAlertsCount}
              </span>
            )}
          </button>

          {/* Role Switcher Pill */}
          <div className="flex items-center gap-1.5 bg-slate-100 px-2.5 py-1.5 rounded-lg border border-slate-200">
            <Shield className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={userRole}
              onChange={e => setUserRole(e.target.value as UserRole)}
              className="bg-transparent text-xs font-bold text-slate-800 outline-hidden cursor-pointer"
            >
              <option value="ADMIN">Admin</option>
              <option value="LOGISTICS_MANAGER">Logistics Manager</option>
              <option value="DATA_ANALYST">Data Analyst</option>
              <option value="VIEWER">Viewer</option>
            </select>
          </div>

          {/* User Profile */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-800 font-extrabold text-xs flex items-center justify-center border border-sky-200">
              {roleLabels[userRole].badge}
            </div>
            <div className="hidden xl:block text-left">
              <span className="block text-xs font-bold text-slate-900 leading-tight">Ananya Rao</span>
              <span className="block text-[10px] text-slate-500 font-medium">{activeOrg.name.split(' ')[0]} Hub</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
