import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  LayoutDashboard,
  Truck,
  Route as RouteIcon,
  MapPin,
  Car,
  Users,
  Globe2,
  TrendingUp,
  DollarSign,
  BarChart3,
  AlertTriangle,
  Sparkles,
  Bot,
  Bell,
  UploadCloud,
  Database,
  CheckCircle,
  FileText,
  UserCheck,
  Settings,
  ChevronLeft,
  ChevronRight,
  Building2,
  Rocket,
  Shield,
  Layers
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { currentView, setCurrentView, userRole, anomalies, alerts, dataMode, lastUpdatedTime } = useLogistics();
  const [collapsed, setCollapsed] = useState(false);

  const activeAnomaliesCount = anomalies.filter(a => !a.acknowledged).length;
  const activeAlertsCount = alerts.filter(a => !a.acknowledged).length;

  interface NavItem {
    id: string;
    label: string;
    icon: React.ReactNode;
    badge?: string | number;
    badgeColor?: string;
  }

  interface NavGroup {
    title: string;
    items: NavItem[];
  }

  const navGroups: NavGroup[] = [
    {
      title: 'PUBLIC & COMMERCIAL',
      items: [
        { id: 'landing', label: 'Commercial Overview', icon: <Layers className="w-4 h-4 text-sky-400" /> },
        { id: 'implementation', label: 'How We Implement', icon: <Rocket className="w-4 h-4 text-emerald-400" /> }
      ]
    },
    {
      title: 'OVERVIEW',
      items: [
        { id: 'dashboard', label: 'Command Center', icon: <LayoutDashboard className="w-4 h-4" /> }
      ]
    },
    {
      title: 'OPERATIONS',
      items: [
        { id: 'deliveries', label: 'Deliveries', icon: <Truck className="w-4 h-4" /> },
        { id: 'routes', label: 'Routes', icon: <RouteIcon className="w-4 h-4" /> },
        { id: 'map', label: 'Logistics Map', icon: <MapPin className="w-4 h-4" /> },
        { id: 'fleet', label: 'Fleet Utilization', icon: <Car className="w-4 h-4" /> },
        { id: 'drivers', label: 'Driver Scorecard', icon: <Users className="w-4 h-4" /> },
        { id: 'regions', label: 'Regional Hubs', icon: <Globe2 className="w-4 h-4" /> }
      ]
    },
    {
      title: 'ANALYTICS',
      items: [
        { id: 'performance', label: 'Delivery SLA', icon: <TrendingUp className="w-4 h-4" /> },
        { id: 'costs', label: 'Cost Analytics', icon: <DollarSign className="w-4 h-4" /> },
        { id: 'demand', label: 'Demand & Forecast', icon: <BarChart3 className="w-4 h-4" /> },
        {
          id: 'anomalies',
          label: 'Anomaly Detection',
          icon: <AlertTriangle className="w-4 h-4" />,
          badge: activeAnomaliesCount > 0 ? activeAnomaliesCount : undefined,
          badgeColor: 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
        }
      ]
    },
    {
      title: 'INTELLIGENCE',
      items: [
        { id: 'ai-insights', label: 'AI Operations Insights', icon: <Sparkles className="w-4 h-4 text-sky-400" /> },
        { id: 'ai-chat', label: 'AI Logistics Analyst', icon: <Bot className="w-4 h-4 text-sky-400" /> },
        {
          id: 'alerts',
          label: 'Alerts & Escalations',
          icon: <Bell className="w-4 h-4" />,
          badge: activeAlertsCount > 0 ? activeAlertsCount : undefined,
          badgeColor: 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
        }
      ]
    },
    {
      title: 'DATA ENGINE',
      items: [
        { id: 'upload', label: 'Import & Mapping', icon: <UploadCloud className="w-4 h-4" /> },
        { id: 'sources', label: 'Data Sources', icon: <Database className="w-4 h-4" /> },
        { id: 'quality', label: 'Quality & Cleaning', icon: <CheckCircle className="w-4 h-4 text-emerald-400" /> }
      ]
    },
    {
      title: 'REPORTING',
      items: [
        { id: 'reports', label: 'Report Generator', icon: <FileText className="w-4 h-4" /> }
      ]
    },
    {
      title: 'ADMIN & TENANT',
      items: [
        { id: 'organizations', label: 'Tenants & Branding', icon: <Building2 className="w-4 h-4" /> },
        { id: 'onboarding', label: 'Onboarding Wizard', icon: <Rocket className="w-4 h-4" /> },
        { id: 'users', label: 'Users & RBAC', icon: <UserCheck className="w-4 h-4" /> },
        { id: 'audit-log', label: 'Audit Trail', icon: <Shield className="w-4 h-4" /> },
        { id: 'settings', label: 'Platform Config', icon: <Settings className="w-4 h-4" /> }
      ]
    }
  ];

  return (
    <aside
      className={`bg-[#0F172A] text-slate-300 border-r border-slate-800 transition-all duration-200 flex flex-col justify-between shrink-0 select-none ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="p-5 flex items-center gap-3 border-b border-slate-800 cursor-pointer" onClick={() => setCurrentView('dashboard')}>
        <div className="w-8 h-8 bg-sky-500 rounded-lg flex items-center justify-center font-extrabold text-white shrink-0 shadow-md shadow-sky-500/20">
          S
        </div>
        {!collapsed && (
          <div className="flex flex-col">
            <span className="text-white font-bold leading-none tracking-wide text-sm">SUPPLYFLOW</span>
            <span className="text-[10px] text-sky-400 uppercase tracking-widest mt-1 font-mono font-semibold">Intelligence</span>
          </div>
        )}
      </div>

      {/* Navigation Groups */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-4 scrollbar-thin">
        {navGroups.map((group, gIdx) => {
          if (userRole === 'VIEWER' && group.title === 'ADMIN') return null;

          return (
            <div key={gIdx} className="space-y-1">
              {!collapsed && (
                <div className="text-[10px] uppercase tracking-wider text-slate-500 px-3 py-1 font-bold">
                  {group.title}
                </div>
              )}
              {group.items.map(item => {
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentView(item.id)}
                    title={collapsed ? item.label : undefined}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs font-medium transition-colors relative cursor-pointer ${
                      isActive
                        ? 'bg-sky-600/15 text-sky-400 font-semibold'
                        : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                    } ${collapsed ? 'justify-center px-0' : ''}`}
                  >
                    {isActive && !collapsed && (
                      <span className="w-1 h-4 bg-sky-400 rounded-full absolute left-0" />
                    )}

                    <span className={`${isActive ? 'text-sky-400' : 'text-slate-400'}`}>
                      {item.icon}
                    </span>

                    {!collapsed && (
                      <span className="truncate flex-1 text-left">{item.label}</span>
                    )}

                    {!collapsed && item.badge !== undefined && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Footer System Status */}
      <div className="p-4 border-t border-slate-800 text-[11px] bg-slate-950/40">
        {!collapsed && (
          <div className="space-y-1 mb-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-slate-300 font-bold uppercase tracking-wider text-[10px]">
                {dataMode === 'LIVE' ? 'LIVE DATA STREAM' : 'TELEMETRY ACTIVE'}
              </span>
            </div>
            <div className="text-slate-400 text-[10px]">Last updated: {lastUpdatedTime.split(', ')[1] || 'Just now'}</div>
          </div>
        )}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full py-1 px-2 flex items-center justify-center text-xs text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors cursor-pointer"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : (
            <span className="flex items-center gap-1.5 text-[11px]">
              <ChevronLeft className="w-3.5 h-3.5" /> Collapse Sidebar
            </span>
          )}
        </button>
      </div>
    </aside>
  );
};
