import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { Filter, RotateCcw, X, Calendar, MapPin, Route, Truck, Clock } from 'lucide-react';

export const FilterBar: React.FC = () => {
  const { filters, updateFilter, resetFilters, regions, routes } = useLogistics();

  const isAnyFilterActive =
    filters.dateRange !== '30_DAYS' ||
    filters.selectedRegion !== 'ALL' ||
    filters.selectedRoute !== 'ALL' ||
    filters.selectedVehicleType !== 'ALL' ||
    filters.selectedStatus !== 'ALL' ||
    filters.selectedDelayReason !== 'ALL' ||
    filters.searchQuery !== '';

  return (
    <div className="bg-white border-b border-slate-200 px-4 py-2.5 shadow-xs">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider pr-1">
            <Filter className="w-3.5 h-3.5 text-blue-600" />
            <span>Filters:</span>
          </div>

          {/* Date Range Selector */}
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <Calendar className="w-3.5 h-3.5 text-slate-400 ml-1" />
            <select
              value={filters.dateRange}
              onChange={e => updateFilter('dateRange', e.target.value as any)}
              className="bg-transparent font-semibold text-slate-700 outline-hidden cursor-pointer pr-1"
            >
              <option value="TODAY">Today (17 Aug)</option>
              <option value="YESTERDAY">Yesterday (16 Aug)</option>
              <option value="7_DAYS">Last 7 Days</option>
              <option value="30_DAYS">Last 30 Days (Aug 2026)</option>
              <option value="90_DAYS">Last 90 Days (Q3 2026)</option>
              <option value="THIS_MONTH">This Month (August)</option>
              <option value="PREVIOUS_MONTH">Previous Month (July)</option>
              <option value="CUSTOM">Custom Range</option>
            </select>
          </div>

          {/* Region Dropdown */}
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <MapPin className="w-3.5 h-3.5 text-slate-400 ml-1" />
            <select
              value={filters.selectedRegion}
              onChange={e => updateFilter('selectedRegion', e.target.value)}
              className="bg-transparent font-semibold text-slate-700 outline-hidden cursor-pointer pr-1"
            >
              <option value="ALL">All Regions</option>
              {regions.map(r => (
                <option key={r.region} value={r.region}>{r.region}</option>
              ))}
            </select>
          </div>

          {/* Route Dropdown */}
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <Route className="w-3.5 h-3.5 text-slate-400 ml-1" />
            <select
              value={filters.selectedRoute}
              onChange={e => updateFilter('selectedRoute', e.target.value)}
              className="bg-transparent font-semibold text-slate-700 outline-hidden cursor-pointer pr-1 max-w-[140px] truncate"
            >
              <option value="ALL">All Routes</option>
              {routes.map(rt => (
                <option key={rt.id} value={rt.id}>{rt.code} - {rt.origin.split(' ')[0]}</option>
              ))}
            </select>
          </div>

          {/* Delivery Status Dropdown */}
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <Truck className="w-3.5 h-3.5 text-slate-400 ml-1" />
            <select
              value={filters.selectedStatus}
              onChange={e => updateFilter('selectedStatus', e.target.value)}
              className="bg-transparent font-semibold text-slate-700 outline-hidden cursor-pointer pr-1"
            >
              <option value="ALL">All Statuses</option>
              <option value="DELIVERED">Delivered</option>
              <option value="OUT_FOR_DELIVERY">Out for Delivery</option>
              <option value="IN_TRANSIT">In Transit</option>
              <option value="DELAYED">Delayed</option>
              <option value="RETURNED">Returned</option>
            </select>
          </div>

          {/* Delay Reason Dropdown */}
          <div className="hidden xl:flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200 text-xs">
            <Clock className="w-3.5 h-3.5 text-slate-400 ml-1" />
            <select
              value={filters.selectedDelayReason}
              onChange={e => updateFilter('selectedDelayReason', e.target.value)}
              className="bg-transparent font-semibold text-slate-700 outline-hidden cursor-pointer pr-1 max-w-[160px] truncate"
            >
              <option value="ALL">All Delay Causes</option>
              <option value="Traffic Congestion">Traffic Congestion</option>
              <option value="Warehouse Dispatch Delay">Warehouse Dispatch Delay</option>
              <option value="Loading / Dock Delay">Loading / Dock Delay</option>
              <option value="Severe Weather">Severe Weather</option>
              <option value="Vehicle Breakdown">Vehicle Breakdown</option>
              <option value="Incorrect Customer Address">Incorrect Address</option>
            </select>
          </div>
        </div>

        {/* Clear Filter / Active Indicator */}
        <div className="flex items-center gap-2">
          {isAnyFilterActive && (
            <button
              onClick={resetFilters}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 rounded-md border border-rose-200 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Active Filter Pills Bar */}
      {isAnyFilterActive && (
        <div className="flex flex-wrap items-center gap-2 pt-2 mt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-400 text-[11px] font-semibold">Active:</span>
          {filters.dateRange !== '30_DAYS' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-medium">
              Range: {filters.dateRange}
              <button onClick={() => updateFilter('dateRange', '30_DAYS')} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
            </span>
          )}
          {filters.selectedRegion !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-medium">
              Region: {filters.selectedRegion}
              <button onClick={() => updateFilter('selectedRegion', 'ALL')} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
            </span>
          )}
          {filters.selectedRoute !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-medium">
              Route: {routes.find(r => r.id === filters.selectedRoute)?.code || filters.selectedRoute}
              <button onClick={() => updateFilter('selectedRoute', 'ALL')} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
            </span>
          )}
          {filters.selectedStatus !== 'ALL' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-medium">
              Status: {filters.selectedStatus}
              <button onClick={() => updateFilter('selectedStatus', 'ALL')} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
            </span>
          )}
          {filters.searchQuery && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-medium">
              Search: "{filters.searchQuery}"
              <button onClick={() => updateFilter('searchQuery', '')} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
            </span>
          )}
        </div>
      )}
    </div>
  );
};
