import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  X,
  Building2,
  Mail,
  User,
  Phone,
  Truck,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const DemoRequestModal: React.FC = () => {
  const { isDemoRequestModalOpen, setIsDemoRequestModalOpen, addAuditLog, activeOrg } = useLogistics();

  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [workEmail, setWorkEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [fleetSize, setFleetSize] = useState('50 - 200 Vehicles');
  const [primaryNeed, setPrimaryNeed] = useState('Delay Reduction & SLA Visibility');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isDemoRequestModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addAuditLog({
      user: fullName || 'Enterprise Lead',
      userRole: 'VIEWER',
      action: 'Submitted Enterprise Demo Request',
      category: 'USER_MANAGEMENT',
      details: `Demo requested for "${companyName}" (${workEmail}, Fleet: ${fleetSize}, Primary Focus: ${primaryNeed})`,
      status: 'SUCCESS',
      organizationId: activeOrg.id
    });
    setSubmitted(true);
  };

  const handleClose = () => {
    setIsDemoRequestModalOpen(false);
    setSubmitted(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-150">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div className="p-8 space-y-6">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-600 uppercase tracking-wider mb-1">
                <Sparkles className="w-3.5 h-3.5" /> SupplyFlow Commercial Demo
              </div>
              <h3 className="text-xl font-bold text-slate-900">Request a Customized Live Walkthrough</h3>
              <p className="text-xs text-slate-500 mt-1">
                See how SupplyFlow Intelligence identifies delay bottlenecks and cost leakage on your specific freight corridors.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Full Name *</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vikram Sharma"
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Company / Fleet Name *</label>
                  <div className="relative">
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. BlueSky Express"
                      value={companyName}
                      onChange={e => setCompanyName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Work Email *</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      required
                      placeholder="vikram@bluesky.com"
                      value={workEmail}
                      onChange={e => setWorkEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Phone Number</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      placeholder="+91 98400 12345"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Fleet / Daily Drops Size</label>
                  <select
                    value={fleetSize}
                    onChange={e => setFleetSize(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-1 focus:ring-sky-500 focus:outline-none font-medium text-slate-700"
                  >
                    <option value="10 - 50 Vehicles">10 - 50 Vehicles (&lt; 2,000 drops/day)</option>
                    <option value="50 - 200 Vehicles">50 - 200 Vehicles (2,000 - 10,000 drops/day)</option>
                    <option value="200 - 1000 Vehicles">200 - 1,000 Vehicles (10,000 - 50,000 drops/day)</option>
                    <option value="1000+ Vehicles">1,000+ Vehicles (&gt; 50,000 drops/day)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Primary Operational Focus</label>
                  <select
                    value={primaryNeed}
                    onChange={e => setPrimaryNeed(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-1 focus:ring-sky-500 focus:outline-none font-medium text-slate-700"
                  >
                    <option value="Delay Reduction & SLA Visibility">Delay Reduction & SLA Visibility</option>
                    <option value="Cost Per Delivery & Fuel Auditing">Cost Per Delivery & Fuel Auditing</option>
                    <option value="Driver Performance & Safety Scoring">Driver Performance & Safety Scoring</option>
                    <option value="Executive Reporting & Multi-Tenant BI">Executive Reporting & Multi-Tenant BI</option>
                    <option value="Automated Anomaly & SLA Alerts">Automated Anomaly & SLA Alerts</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Notes on current TMS / Data Format (Optional)</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. We export daily CSVs from SAP/FarEye and want automated weekly delay summaries..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Strict NDA & Zero Data Sharing</span>
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold shadow-md shadow-sky-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  Schedule Demo Walkthrough <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </div>
        ) : (
          <div className="p-10 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-bold text-slate-900">Demo Request Confirmed!</h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                Thank you, <strong>{fullName}</strong>. A logistics solutions engineer from SupplyFlow will reach out to <strong>{workEmail}</strong> within 1 business day with a customized dataset sandbox tailored for <strong>{companyName}</strong>.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={handleClose}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Back to Platform
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
