import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Layers,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  Zap,
  Sparkles,
  Truck,
  Globe2,
  DollarSign,
  Clock,
  CheckCircle2,
  Bot,
  Rocket,
  Building2,
  Database,
  BarChart3,
  AlertTriangle,
  HelpCircle,
  FileText,
  Sliders,
  Check
} from 'lucide-react';

export const LandingView: React.FC = () => {
  const { setCurrentView, setIsDemoRequestModalOpen } = useLogistics();

  return (
    <div className="space-y-16 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* 1. Hero Section */}
      <div className="bg-[#0F172A] rounded-3xl p-8 sm:p-12 lg:p-16 text-white shadow-2xl border border-slate-800 relative overflow-hidden">
        <div className="max-w-3xl relative z-10 space-y-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono font-bold tracking-wide">
            <Sparkles className="w-3.5 h-3.5" />
            B2B LOGISTICS INTELLIGENCE SAAS
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Turn Logistics Data Into <span className="text-sky-400">Smarter Decisions.</span>
          </h1>

          <p className="text-sm sm:text-base lg:text-lg text-slate-300 leading-relaxed max-w-2xl">
            A commercial analytics platform that transforms raw TMS logs, GPS telematics, and dispatch spreadsheets into actionable delay reduction, cost auditing, and automated AI insights.
          </p>

          {/* Value Highlights Pill Row */}
          <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-300">
            <span className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <Check className="w-3.5 h-3.5 text-emerald-400" /> Multi-Tenant Isolation
            </span>
            <span className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <Check className="w-3.5 h-3.5 text-emerald-400" /> 10-Step Onboarding Engine
            </span>
            <span className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <Check className="w-3.5 h-3.5 text-emerald-400" /> Grounded Gemini AI Analyst
            </span>
          </div>

          <div className="pt-4 flex flex-wrap items-center gap-4">
            <button
              onClick={() => setIsDemoRequestModalOpen(true)}
              className="px-6 py-3.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-sky-900/50 flex items-center gap-2 transition-all cursor-pointer"
            >
              <span>Request Commercial Demo</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs sm:text-sm font-semibold border border-slate-700 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Layers className="w-4 h-4 text-sky-400" />
              <span>Explore Live Demo Console</span>
            </button>

            <button
              onClick={() => setCurrentView('implementation')}
              className="px-5 py-3.5 text-slate-400 hover:text-white text-xs sm:text-sm font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Rocket className="w-4 h-4 text-emerald-400" />
              <span>How We Implement</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. The Core Problem vs SupplyFlow Solution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-rose-50/50 border border-rose-200 rounded-2xl p-8 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-rose-700 uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" /> The Operational Challenge
          </div>
          <h3 className="text-xl font-bold text-slate-900">Why Logistics Teams Struggle With Data</h3>
          <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-2 shrink-0"></span>
              <span><strong>Data Fragmentation:</strong> Telematics, ERP orders, and driver manifests sit in disconnected silos.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-2 shrink-0"></span>
              <span><strong>Hidden Cost Leakage:</strong> Unmonitored idle times, suboptimal corridor routing, and excessive fuel drain eat margins.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-2 shrink-0"></span>
              <span><strong>Reactive firefighting:</strong> Operations leads only discover missed SLAs after customers escalate complaints.</span>
            </li>
          </ul>
        </div>

        <div className="bg-emerald-50/50 border border-emerald-200 rounded-2xl p-8 space-y-4">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 uppercase tracking-wider">
            <CheckCircle2 className="w-4 h-4" /> The SupplyFlow Solution
          </div>
          <h3 className="text-xl font-bold text-slate-900">Continuous Intelligence & Action</h3>
          <ul className="space-y-3 text-xs sm:text-sm text-slate-700">
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0"></span>
              <span><strong>Automated Ingestion & ETL:</strong> Flexible schema mapper unifies CSVs, Excel sheets, and REST APIs.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0"></span>
              <span><strong>Granular Root-Cause Attribution:</strong> Identifies whether delays stem from dock bottlenecks, traffic, or dispatch lag.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0"></span>
              <span><strong>AI Logistics Analyst:</strong> Natural language querying grounded purely in actual company shipment records.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* 3. Core Product Modules */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Comprehensive Operational Modules</h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto">
            Everything dispatchers, data analysts, and C-level logistics executives need in a single pane of glass.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-200">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Delivery & SLA Performance</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Real-time tracking across delivery lifecycle stages, on-time percentage benchmarks, and Pareto delay cause classification.
              </p>
            </div>
            <button
              onClick={() => setCurrentView('performance')}
              className="text-xs font-bold text-sky-600 hover:text-sky-700 flex items-center gap-1 mt-4 pt-4 border-t border-slate-100"
            >
              Explore Performance Analytics <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200">
                <DollarSign className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Cost & Fuel Auditing</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Breakdown of fuel, driver wages, toll fees, and maintenance per corridor with automated cost per delivery leakage detection.
              </p>
            </div>
            <button
              onClick={() => setCurrentView('costs')}
              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 mt-4 pt-4 border-t border-slate-100"
            >
              Audit Transport Costs <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-200">
                <Bot className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">AI Intelligence & Insights</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Automated root-cause synthesizers, predictive delivery forecasts, and conversational logistics query assistant.
              </p>
            </div>
            <button
              onClick={() => setCurrentView('ai-chat')}
              className="text-xs font-bold text-purple-600 hover:text-purple-700 flex items-center gap-1 mt-4 pt-4 border-t border-slate-100"
            >
              Ask AI Logistics Assistant <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. Multi-Tenant Architecture & Security */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 space-y-6">
        <div className="max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5" /> ENTERPRISE DATA GOVERNANCE
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold">Cryptographically Isolated Multi-Tenancy</h2>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            Built from the ground up for high-trust commercial logistics networks. Your proprietary shipment pricing, client registries, and driver data remain strictly partitioned.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700">
            <h4 className="font-bold text-sm text-white mb-1">Tenant Partitioning</h4>
            <p className="text-xs text-slate-400">Strict organization_id scoping on all DB queries and AI prompts.</p>
          </div>

          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700">
            <h4 className="font-bold text-sm text-white mb-1">Role-Based Access (RBAC)</h4>
            <p className="text-xs text-slate-400">Granular permissions across Admin, Operations Manager, Data Analyst, and Viewer.</p>
          </div>

          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700">
            <h4 className="font-bold text-sm text-white mb-1">Immutable Audit Trail</h4>
            <p className="text-xs text-slate-400">Complete logging of data imports, ETL cleaning operations, and permission changes.</p>
          </div>

          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700">
            <h4 className="font-bold text-sm text-white mb-1">Zero Public Training</h4>
            <p className="text-xs text-slate-400">Your operational data is never used to train third-party machine learning models.</p>
          </div>
        </div>
      </div>

      {/* 5. How We Implement Section Callout */}
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="space-y-3 max-w-xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <Rocket className="w-3.5 h-3.5 text-emerald-600" /> Standardized Client Rollout
          </div>
          <h3 className="text-2xl font-bold text-slate-900">11-Step Commercial Implementation Blueprint</h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Our logistics data engineers work directly with your operations team to map columns, configure custom SLA thresholds, and achieve production go-live in 2 to 4 weeks.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('implementation')}
          className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all whitespace-nowrap cursor-pointer"
        >
          View Full Implementation Methodology →
        </button>
      </div>

      {/* 6. Frequently Asked Questions (FAQ) */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-slate-900">Frequently Asked Questions</h2>
          <p className="text-xs text-slate-500">Key commercial, technical, and operational questions answered.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-sky-600" /> What formats can we import into SupplyFlow?
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              SupplyFlow supports CSV files, Excel spreadsheets (.xlsx), direct REST API webhook streams from TMS systems (like FarEye, SAP, Shipsy), and direct read-only SQL warehouse replicas.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-sky-600" /> Is our logistics and pricing data isolated?
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Yes. Every company workspace runs in an isolated tenant schema with strict cryptographic separation. No other organization can view or query your fleet records.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-sky-600" /> How does the AI Logistics Analyst work?
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              The AI Analyst is grounded directly on your loaded metrics (active deliveries, delay root causes, fleet utilization, and corridor costs) using Google Gemini, eliminating hallucinations.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-sky-600" /> Can we customize our SLA benchmarks?
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Yes. Each organization can configure custom target on-time percentages, max delay tolerance minutes, target drop costs, and driver safety score weightings.
            </p>
          </div>
        </div>
      </div>

      {/* 7. Final Call to Action */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-3xl p-8 sm:p-12 text-center space-y-6 border border-slate-700">
        <div className="max-w-2xl mx-auto space-y-3">
          <h2 className="text-2xl sm:text-4xl font-bold">Ready to Optimize Your Logistics Operations?</h2>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            Join logistics and courier operators utilizing SupplyFlow Intelligence for sub-minute SLA tracking and cost reduction.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => setIsDemoRequestModalOpen(true)}
            className="px-8 py-3.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-sky-900/50 transition-all cursor-pointer"
          >
            Request Commercial Walkthrough
          </button>
          <button
            onClick={() => setCurrentView('dashboard')}
            className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer"
          >
            Explore Live Demo Platform
          </button>
        </div>
      </div>
    </div>
  );
};
