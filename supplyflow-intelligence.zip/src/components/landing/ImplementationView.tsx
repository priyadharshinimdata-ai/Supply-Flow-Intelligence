import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Rocket,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  Server,
  Database,
  Sliders,
  Users,
  Sparkles,
  Award,
  Clock,
  Building2
} from 'lucide-react';
import { CLIENT_IMPLEMENTATION_STEPS } from '../../data/mockLogisticsData';

export const ImplementationView: React.FC = () => {
  const { setCurrentView, setIsDemoRequestModalOpen } = useLogistics();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white border-b border-slate-800 py-16 px-6 lg:px-12">
        <div className="max-w-5xl mx-auto space-y-4 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs font-bold uppercase tracking-widest">
            <Rocket className="w-3.5 h-3.5" /> Enterprise Deployment Blueprint
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white">
            How We Implement SupplyFlow
          </h1>
          <p className="text-slate-400 text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
            A standardized, battle-tested 11-step client rollout methodology designed to take courier and freight networks from raw logs to live AI intelligence within 2 to 4 weeks.
          </p>

          <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => setIsDemoRequestModalOpen(true)}
              className="px-6 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-sky-500/20 transition-all cursor-pointer"
            >
              Request Custom Implementation Proposal
            </button>
            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Explore Live Demo Console
            </button>
          </div>
        </div>
      </div>

      {/* 11-Step Interactive Implementation Roadmap */}
      <div className="max-w-5xl mx-auto py-16 px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-slate-900">Standard Client Implementation Lifecycle</h2>
          <p className="text-xs text-slate-500">Every deployment includes dedicated data engineers, SLA validation, and enterprise role provisioning.</p>
        </div>

        <div className="space-y-4">
          {CLIENT_IMPLEMENTATION_STEPS.map((step) => (
            <div
              key={step.stepNumber}
              className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all flex flex-col md:flex-row md:items-start gap-5"
            >
              <div className="flex items-center gap-3 md:flex-col md:items-center shrink-0">
                <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 font-extrabold flex items-center justify-center text-sm font-mono shadow-2xs">
                  {String(step.stepNumber).padStart(2, '0')}
                </div>
                <span className="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                  {step.duration}
                </span>
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-sky-600 uppercase tracking-wider">{step.phase}</span>
                    <h3 className="text-base font-bold text-slate-900">{step.title}</h3>
                  </div>
                  <span className="text-xs font-mono font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> {step.deliverables.join(', ')}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{step.description}</p>
                <div className="text-[11px] text-slate-400 font-medium pt-1">
                  Responsible: <strong className="text-slate-600">{step.owner}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Guaranteed SLA & Deployment Standards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
            <ShieldCheck className="w-6 h-6 text-sky-600 mb-1" />
            <h4 className="font-bold text-slate-900 text-sm">Tenant Isolation</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Every client operates within a dedicated logical tenant schema. No customer data is ever co-mingled or used to train third-party models.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
            <Database className="w-6 h-6 text-emerald-600 mb-1" />
            <h4 className="font-bold text-slate-900 text-sm">Zero Data Lock-in</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Full data portability with daily automated encrypted JSON/CSV backups, raw data export, and open BI connection adapters.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
            <Clock className="w-6 h-6 text-indigo-600 mb-1" />
            <h4 className="font-bold text-slate-900 text-sm">Rapid Time-to-Value</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Achieve initial operations visibility and delay root-cause insights within the first 7 business days of flat-file ingestion.
            </p>
          </div>
        </div>

        {/* Call to Action Card */}
        <div className="bg-slate-900 text-white p-8 md:p-10 rounded-2xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl md:text-2xl font-bold">Ready to modernize your logistics operations?</h3>
            <p className="text-xs text-slate-400 max-w-xl leading-relaxed">
              Schedule a technical discovery session with our logistics data architects. We will review your current TMS export files and demonstrate customized ROI potential.
            </p>
          </div>
          <button
            onClick={() => setIsDemoRequestModalOpen(true)}
            className="px-6 py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-sky-500/20 whitespace-nowrap transition-all cursor-pointer"
          >
            Schedule Technical Discovery
          </button>
        </div>
      </div>
    </div>
  );
};
