import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  UserCheck,
  Shield,
  UserPlus,
  Key,
  Lock,
  Mail,
  CheckCircle2
} from 'lucide-react';
import { UserRole } from '../../types';

export const UsersView: React.FC = () => {
  const { userRole, setUserRole } = useLogistics();

  const userList = [
    {
      id: 'u-1',
      name: 'Priyadharshini K.',
      email: 'priyadharshinidataanalyst2027@gmail.com',
      role: 'LOGISTICS_MANAGER' as UserRole,
      department: 'Regional Operations (South Hub)',
      status: 'ACTIVE',
      lastActive: 'Just now'
    },
    {
      id: 'u-2',
      name: 'Anand Raman',
      email: 'anand.raman@apexlogistics.com',
      role: 'ADMIN' as UserRole,
      department: 'Enterprise IT & Telematics Infrastructure',
      status: 'ACTIVE',
      lastActive: '12 mins ago'
    },
    {
      id: 'u-3',
      name: 'Vikram Sethi',
      email: 'v.sethi@apexlogistics.com',
      role: 'DATA_ANALYST' as UserRole,
      department: 'Supply Chain Optimization & ML Group',
      status: 'ACTIVE',
      lastActive: '1 hour ago'
    },
    {
      id: 'u-4',
      name: 'Kavita Nair',
      email: 'kavita.nair@apexlogistics.com',
      role: 'VIEWER' as UserRole,
      department: 'Customer Success & SLA Resolution',
      status: 'ACTIVE',
      lastActive: 'Yesterday'
    }
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">User Management & Role-Based Access Control (RBAC)</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Configure permissions for Logistics Managers, Lead Data Analysts, Operations Viewers, and Administrators.
          </p>
        </div>

        <button className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors flex items-center gap-2 cursor-pointer">
          <UserPlus className="w-4 h-4" />
          <span>Invite Team Member</span>
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
            <tr>
              <th className="px-5 py-3">Team Member</th>
              <th className="px-5 py-3">Department</th>
              <th className="px-5 py-3">Assigned Role</th>
              <th className="px-5 py-3">Last Active</th>
              <th className="px-5 py-3">Access State</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {userList.map(user => (
              <tr key={user.id} className="hover:bg-slate-50">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center border border-slate-200">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 block">{user.name}</span>
                      <span className="text-slate-400 text-[11px]">{user.email}</span>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-slate-600">{user.department}</td>
                <td className="px-5 py-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    user.role === 'ADMIN'
                      ? 'bg-purple-50 text-purple-700 border border-purple-200'
                      : user.role === 'DATA_ANALYST'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-sky-50 text-sky-700 border border-sky-200'
                  }`}>
                    {user.role}
                  </span>
                </td>
                <td className="px-5 py-3 text-slate-500 font-mono text-[11px]">{user.lastActive}</td>
                <td className="px-5 py-3">
                  <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Active
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
