import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Building2,
  Plus,
  CheckCircle,
  ExternalLink,
  Settings,
  Shield,
  Sliders,
  Sparkles,
  Users,
  Palette,
  Clock,
  MapPin,
  FileSpreadsheet
} from 'lucide-react';
import { Organization } from '../../types';

export const OrganizationsView: React.FC = () => {
  const {
    organizations,
    activeOrg,
    switchOrganization,
    updateOrganization,
    setCurrentView,
    userRole
  } = useLogistics();

  const [selectedOrgId, setSelectedOrgId] = useState<string>(activeOrg.id);
  const [editingOrg, setEditingOrg] = useState<Organization>(activeOrg);
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const handleSelectOrg = (org: Organization) => {
    setSelectedOrgId(org.id);
    setEditingOrg(org);
  };

  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    updateOrganization(editingOrg);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-sky-600 uppercase tracking-wider">
            <Building2 className="w-4 h-4" /> Multi-Tenant Workspace & Client Isolation
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mt-1">Organization Management & Branding</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage company tenant boundaries, custom SLA benchmarks, visual branding, and role-based access.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('onboarding')}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Onboard New Organization
          </button>
        </div>
      </div>

      {/* Grid: Left - Organizations List, Right - Org Customizer & Tenant Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Organization List */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Provisioned Tenants ({organizations.length})</h3>

          <div className="space-y-3">
            {organizations.map(org => {
              const isActive = activeOrg.id === org.id;
              const isSelected = selectedOrgId === org.id;

              return (
                <div
                  key={org.id}
                  onClick={() => handleSelectOrg(org)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-sky-500 bg-sky-50/40 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-xl shadow-2xs">
                        {org.logo}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-tight">{org.name}</h4>
                        <span className="text-[11px] text-slate-500">{org.industry}</span>
                      </div>
                    </div>

                    {isActive && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 font-bold text-[10px] uppercase rounded border border-emerald-200">
                        Active View
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100 mt-2">
                    <span className="font-mono text-[10px]">{org.country}</span>
                    <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">
                      {org.dataMode}
                    </span>
                  </div>

                  <div className="mt-3 pt-2 flex items-center justify-between">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        switchOrganization(org.id);
                      }}
                      disabled={isActive}
                      className={`text-xs font-bold px-3 py-1 rounded transition-colors cursor-pointer ${
                        isActive
                          ? 'bg-slate-100 text-slate-400 cursor-default'
                          : 'bg-sky-600 hover:bg-sky-500 text-white shadow-2xs'
                      }`}
                    >
                      {isActive ? 'Current Workspace' : 'Switch to Workspace'}
                    </button>
                    <span className="text-[10px] text-slate-400 font-mono">ID: {org.id}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Organization Details, Branding & SLA Editor */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Tenant Configuration & Branding: {editingOrg.name}</h3>
                <p className="text-xs text-slate-500">Customize visual appearance, reporting header, and SLA benchmarks for this tenant.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded border border-slate-200 text-slate-600">
                  Created: {editingOrg.createdAt}
                </span>
              </div>
            </div>

            <form onSubmit={handleSaveBranding} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Company Display Name</label>
                  <input
                    type="text"
                    value={editingOrg.name}
                    onChange={e => setEditingOrg({ ...editingOrg, name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Dashboard Header Title</label>
                  <input
                    type="text"
                    value={editingOrg.dashboardTitle}
                    onChange={e => setEditingOrg({ ...editingOrg, dashboardTitle: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Contact Person</label>
                  <input
                    type="text"
                    value={editingOrg.contactPerson}
                    onChange={e => setEditingOrg({ ...editingOrg, contactPerson: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Contact Email</label>
                  <input
                    type="email"
                    value={editingOrg.contactEmail}
                    onChange={e => setEditingOrg({ ...editingOrg, contactEmail: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Timezone</label>
                  <input
                    type="text"
                    value={editingOrg.timezone}
                    onChange={e => setEditingOrg({ ...editingOrg, timezone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Primary Brand Accent</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={editingOrg.primaryBrandColor}
                      onChange={e => setEditingOrg({ ...editingOrg, primaryBrandColor: e.target.value })}
                      className="w-9 h-9 rounded border border-slate-300 cursor-pointer p-0.5"
                    />
                    <span className="font-mono text-xs text-slate-700 font-bold">{editingOrg.primaryBrandColor}</span>
                  </div>
                </div>
              </div>

              {/* SLA Target Controls */}
              <div className="pt-4 border-t border-slate-200">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">Custom Tenant SLA Benchmarks</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Target On-Time SLA</span>
                    <div className="flex items-center gap-1 mt-1">
                      <input
                        type="number"
                        step="0.1"
                        value={editingOrg.kpiTargets.targetOnTimeRate}
                        onChange={e => setEditingOrg({
                          ...editingOrg,
                          kpiTargets: { ...editingOrg.kpiTargets, targetOnTimeRate: Number(e.target.value) }
                        })}
                        className="w-16 px-2 py-1 border border-slate-300 rounded text-xs font-mono font-bold"
                      />
                      <span className="text-xs font-bold text-slate-600">%</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Max Delay Tolerance</span>
                    <div className="flex items-center gap-1 mt-1">
                      <input
                        type="number"
                        value={editingOrg.kpiTargets.maxDelayToleranceMins}
                        onChange={e => setEditingOrg({
                          ...editingOrg,
                          kpiTargets: { ...editingOrg.kpiTargets, maxDelayToleranceMins: Number(e.target.value) }
                        })}
                        className="w-16 px-2 py-1 border border-slate-300 rounded text-xs font-mono font-bold"
                      />
                      <span className="text-xs font-bold text-slate-600">min</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Target Cost/Drop</span>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-xs font-bold text-slate-600">₹</span>
                      <input
                        type="number"
                        value={editingOrg.kpiTargets.targetCostPerDelivery}
                        onChange={e => setEditingOrg({
                          ...editingOrg,
                          kpiTargets: { ...editingOrg.kpiTargets, targetCostPerDelivery: Number(e.target.value) }
                        })}
                        className="w-16 px-2 py-1 border border-slate-300 rounded text-xs font-mono font-bold"
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Target Fleet Util</span>
                    <div className="flex items-center gap-1 mt-1">
                      <input
                        type="number"
                        step="0.1"
                        value={editingOrg.kpiTargets.targetFleetUtilization}
                        onChange={e => setEditingOrg({
                          ...editingOrg,
                          kpiTargets: { ...editingOrg.kpiTargets, targetFleetUtilization: Number(e.target.value) }
                        })}
                        className="w-16 px-2 py-1 border border-slate-300 rounded text-xs font-mono font-bold"
                      />
                      <span className="text-xs font-bold text-slate-600">%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <div className="flex items-center gap-2">
                  {isSaved && (
                    <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" /> Tenant profile saved successfully
                    </span>
                  )}
                </div>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold transition-colors shadow-xs cursor-pointer"
                >
                  Save Configuration
                </button>
              </div>
            </form>
          </div>

          {/* Tenant Security & Isolation Card */}
          <div className="bg-slate-900 text-slate-200 p-6 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider">
              <Shield className="w-4 h-4" /> Tenant Data Isolation Guarantee
            </div>
            <h4 className="text-sm font-bold text-white">Cryptographically Isolated Multi-Tenancy</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              All database records, AI prompts, telemetry queries, and alert histories are strictly partitioned by <code className="text-sky-300 bg-slate-800 px-1 py-0.5 rounded">organization_id: {editingOrg.id}</code>. Cross-tenant data leakage is prevented at the database view and API controller layers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
