import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Settings,
  Sliders,
  Bell,
  Database,
  Shield,
  CheckCircle2,
  Save
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [saved, setSaved] = useState(false);
  const [slaTarget, setSlaTarget] = useState(95.0);
  const [costBenchmark, setCostBenchmark] = useState(325);
  const [anomalySensitivity, setAnomalySensitivity] = useState('HIGH');
  const [autoEmailAlerts, setAutoEmailAlerts] = useState(true);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Platform Settings & Threshold Configuration</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Global SLA contract targets, cost per delivery benchmarks, outlier anomaly triggers, and notification rules.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>{saved ? 'Saved Configuration!' : 'Save Settings'}</span>
        </button>
      </div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* SLA & Operational Thresholds */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-600" />
            <h2 className="text-sm font-bold text-slate-900">SLA & Operational Target Thresholds</h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-bold text-slate-800 block mb-1">
                Committed Customer On-Time SLA Benchmark (%)
              </label>
              <input
                type="number"
                step="0.1"
                value={slaTarget}
                onChange={e => setSlaTarget(parseFloat(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold text-slate-900 focus:outline-hidden focus:border-sky-500"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">Current contractual baseline: 95.0%</span>
            </div>

            <div>
              <label className="font-bold text-slate-800 block mb-1">
                Cost Per Delivery Ceiling Target (₹)
              </label>
              <input
                type="number"
                value={costBenchmark}
                onChange={e => setCostBenchmark(parseInt(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-bold text-slate-900 focus:outline-hidden focus:border-sky-500"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">Network target benchmark: ₹325/drop</span>
            </div>
          </div>
        </div>

        {/* Anomaly & Telematics Sensitivity */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-100 flex items-center gap-2">
            <Shield className="w-4 h-4 text-sky-600" />
            <h2 className="text-sm font-bold text-slate-900">Outlier Detection & Alert Rules</h2>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-800 block mb-1">
                Z-Score Anomaly Sensitivity Level
              </label>
              <select
                value={anomalySensitivity}
                onChange={e => setAnomalySensitivity(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-900 focus:outline-hidden focus:border-sky-500 cursor-pointer"
              >
                <option value="HIGH">High Sensitivity (2.0 Standard Deviations)</option>
                <option value="MEDIUM">Medium Sensitivity (2.5 Standard Deviations)</option>
                <option value="LOW">Low Sensitivity (3.0 Standard Deviations)</option>
              </select>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                <span className="font-bold text-slate-800 block">Critical SLA Breach Email Dispatch</span>
                <span className="text-slate-400 text-[11px]">Send automated dispatch to duty manager</span>
              </div>
              <input
                type="checkbox"
                checked={autoEmailAlerts}
                onChange={e => setAutoEmailAlerts(e.target.checked)}
                className="w-4 h-4 text-sky-600 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
