import React, { useState, useMemo } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  ShieldAlert,
  Search,
  Download,
  Filter,
  CheckCircle,
  AlertTriangle,
  FileSpreadsheet,
  Clock,
  User,
  Shield,
  Activity
} from 'lucide-react';
import { AuditLogEntry } from '../../types';

export const AuditLogView: React.FC = () => {
  const { auditLogs, activeOrg } = useLogistics();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  const filteredLogs = useMemo(() => {
    return auditLogs.filter(log => {
      if (selectedCategory !== 'ALL' && log.category !== selectedCategory) return false;
      if (selectedStatus !== 'ALL' && log.status !== selectedStatus) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchUser = log.user.toLowerCase().includes(q);
        const matchAction = log.action.toLowerCase().includes(q);
        const matchDetails = log.details.toLowerCase().includes(q);
        if (!matchUser && !matchAction && !matchDetails) return false;
      }
      return true;
    });
  }, [auditLogs, selectedCategory, selectedStatus, searchQuery]);

  const handleExportCSV = () => {
    const headers = ['Timestamp', 'User', 'Role', 'Category', 'Action', 'Details', 'Status', 'Organization ID'];
    const rows = filteredLogs.map(l => [
      `"${l.timestamp}"`,
      `"${l.user}"`,
      `"${l.userRole}"`,
      `"${l.category}"`,
      `"${l.action}"`,
      `"${l.details}"`,
      `"${l.status}"`,
      `"${l.organizationId || activeOrg.id}"`
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `supplyflow_audit_log_${activeOrg.id}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getCategoryBadge = (cat: AuditLogEntry['category']) => {
    switch (cat) {
      case 'DATA_IMPORT':
        return 'bg-sky-100 text-sky-700 border-sky-200';
      case 'DATA_CLEAN':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'USER_MANAGEMENT':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'SETTINGS_CHANGED':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'REPORT_GENERATED':
        return 'bg-indigo-100 text-indigo-700 border-indigo-200';
      case 'SECURITY':
        return 'bg-rose-100 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-sky-600 uppercase tracking-wider">
            <Shield className="w-4 h-4" /> Compliance & Security Trail
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mt-1">Tenant System Audit Log</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Immutable tracking of data modifications, ETL cleaning tasks, user role assignments, and schema adjustments.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" /> Export CSV Audit Trail
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search user, action, or log details..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-sky-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700 font-medium"
            >
              <option value="ALL">All Categories</option>
              <option value="DATA_IMPORT">Data Import</option>
              <option value="DATA_CLEAN">Data Clean</option>
              <option value="USER_MANAGEMENT">User Management</option>
              <option value="SETTINGS_CHANGED">Settings & Branding</option>
              <option value="REPORT_EXPORT">Report Export</option>
              <option value="SECURITY">Security & Access</option>
            </select>
          </div>

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700 font-medium"
          >
            <option value="ALL">All Statuses</option>
            <option value="SUCCESS">Success</option>
            <option value="WARNING">Warning</option>
            <option value="ERROR">Error</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3.5">Timestamp</th>
                <th className="p-3.5">User & Role</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Action Executed</th>
                <th className="p-3.5">Details & Parameters</th>
                <th className="p-3.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="p-3.5 font-mono text-slate-500 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {log.timestamp}
                    </div>
                  </td>
                  <td className="p-3.5">
                    <div className="font-bold text-slate-900">{log.user}</div>
                    <div className="text-[10px] text-slate-400 font-mono uppercase">{log.userRole}</div>
                  </td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getCategoryBadge(log.category)}`}>
                      {log.category.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="p-3.5 font-semibold text-slate-800">{log.action}</td>
                  <td className="p-3.5 text-slate-600 max-w-md truncate" title={log.details}>
                    {log.details}
                  </td>
                  <td className="p-3.5">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                        log.status === 'SUCCESS'
                          ? 'bg-emerald-100 text-emerald-700'
                          : log.status === 'WARNING'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {log.status === 'SUCCESS' && <CheckCircle className="w-3 h-3" />}
                      {log.status === 'WARNING' && <AlertTriangle className="w-3 h-3" />}
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex justify-between items-center">
          <span>Showing {filteredLogs.length} audit entries</span>
          <span className="font-mono text-[11px]">Workspace: {activeOrg.name} (Tenant: {activeOrg.id})</span>
        </div>
      </div>
    </div>
  );
};
