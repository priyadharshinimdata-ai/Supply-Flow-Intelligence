import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Building2,
  Database,
  UploadCloud,
  FileSpreadsheet,
  Columns,
  CheckCircle2,
  Sparkles,
  Palette,
  Rocket,
  ArrowRight,
  ArrowLeft,
  Sliders,
  Check,
  AlertTriangle,
  FileText,
  ShieldCheck
} from 'lucide-react';
import { Organization, ColumnMapping } from '../../types';

export const OnboardingWizardView: React.FC = () => {
  const {
    createOrganization,
    setCurrentView,
    columnMappings,
    updateColumnMapping,
    cleaningSteps,
    applyCleaningAction,
    addAuditLog
  } = useLogistics();

  const [step, setStep] = useState<number>(1);

  // Step 1: Org Details
  const [orgName, setOrgName] = useState('SwiftHaul Logistics');
  const [industry, setIndustry] = useState<Organization['industry']>('Courier & Parcel');
  const [country, setCountry] = useState('India');
  const [contactPerson, setContactPerson] = useState('Ananya Rao');
  const [contactEmail, setContactEmail] = useState('ananya.r@swifthaul.in');
  const [logo, setLogo] = useState('🚛');
  const [primaryBrandColor, setPrimaryBrandColor] = useState('#0284c7');
  const [secondaryBrandColor, setSecondaryBrandColor] = useState('#0f172a');
  const [timezone, setTimezone] = useState('Asia/Kolkata (IST +5:30)');

  // Step 2: Data Source
  const [sourceType, setSourceType] = useState<'CSV' | 'EXCEL' | 'API' | 'DB' | 'DEMO'>('CSV');

  // Step 3: Imported Data Simulation
  const [fileUploaded, setFileUploaded] = useState(true);
  const [fileName, setFileName] = useState('swifthaul_operations_aug2026.csv');
  const [rowCount, setRowCount] = useState(14850);

  // Step 8: KPI Configuration
  const [kpiOnTime, setKpiOnTime] = useState(95.0);
  const [kpiMaxDelay, setKpiMaxDelay] = useState(30);
  const [kpiTargetCost, setKpiTargetCost] = useState(315);
  const [kpiFleetUtil, setKpiFleetUtil] = useState(88.0);

  // Step 10: Completion
  const handlePublishDashboard = () => {
    const newOrg: Organization = {
      id: 'org-' + Date.now(),
      name: orgName,
      industry,
      country,
      contactPerson,
      contactEmail,
      logo,
      primaryBrandColor,
      secondaryBrandColor,
      dashboardTitle: `${orgName} — Operations Command Center`,
      timezone,
      dataMode: sourceType === 'DEMO' ? 'DEMO' : 'CUSTOM_UPLOAD',
      createdAt: new Date().toISOString().split('T')[0],
      kpiTargets: {
        targetOnTimeRate: kpiOnTime,
        maxDelayToleranceMins: kpiMaxDelay,
        targetCostPerDelivery: kpiTargetCost,
        targetFleetUtilization: kpiFleetUtil
      }
    };

    createOrganization(newOrg);
    addAuditLog({
      user: contactPerson,
      userRole: 'ADMIN',
      action: 'Completed Company Onboarding Wizard',
      category: 'SETTINGS_CHANGED',
      details: `Provisioned isolated tenant workspace for "${orgName}" with ${rowCount} records and customized KPIs.`,
      status: 'SUCCESS',
      organizationId: newOrg.id
    });

    setCurrentView('dashboard');
  };

  const stepsList = [
    { num: 1, label: 'Organization' },
    { num: 2, label: 'Data Source' },
    { num: 3, label: 'Import Data' },
    { num: 4, label: 'Preview' },
    { num: 5, label: 'Map Columns' },
    { num: 6, label: 'Validate' },
    { num: 7, label: 'Clean Data' },
    { num: 8, label: 'Configure KPIs' },
    { num: 9, label: 'Apply Branding' },
    { num: 10, label: 'Publish' }
  ];

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-sky-600 uppercase tracking-wider">
            <Rocket className="w-4 h-4" /> Commercial Client Onboarding
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mt-1">Tenant Setup & Data Mapping Engine</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Configure isolated company data pipeline, column mappings, data cleaning rules, and custom dashboard KPIs.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200">
            Step {step} of 10
          </span>
          <button
            onClick={() => setCurrentView('organizations')}
            className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>

      {/* 10-Step Progress Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
        <div className="flex items-center justify-between min-w-[720px] gap-2">
          {stepsList.map(s => {
            const isCompleted = step > s.num;
            const isCurrent = step === s.num;
            return (
              <button
                key={s.num}
                onClick={() => setStep(s.num)}
                className="flex items-center gap-2 group cursor-pointer"
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    isCompleted
                      ? 'bg-emerald-500 text-white'
                      : isCurrent
                      ? 'bg-sky-600 text-white ring-4 ring-sky-100'
                      : 'bg-slate-100 text-slate-400 border border-slate-200'
                  }`}
                >
                  {isCompleted ? <Check className="w-3.5 h-3.5" /> : s.num}
                </div>
                <span
                  className={`text-xs font-semibold whitespace-nowrap ${
                    isCurrent ? 'text-sky-700 font-bold' : isCompleted ? 'text-slate-700' : 'text-slate-400'
                  }`}
                >
                  {s.label}
                </span>
                {s.num < 10 && <div className="w-6 h-[1px] bg-slate-200 mx-1" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Wizard Body Containers */}
      <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm min-h-[480px] flex flex-col justify-between">
        {/* STEP 1: Organization Details */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 1: Create Organization Tenant</h3>
              <p className="text-xs text-slate-500">Provide legal entity details, primary contact, and timezone for tenant isolation.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Company Name</label>
                <input
                  type="text"
                  value={orgName}
                  onChange={e => setOrgName(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="e.g. SwiftHaul Logistics"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Logistics Industry</label>
                <select
                  value={industry}
                  onChange={e => setIndustry(e.target.value as any)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  <option value="Courier & Parcel">Courier & Parcel</option>
                  <option value="E-Commerce Logistics">E-Commerce Logistics</option>
                  <option value="3PL Freight Distribution">3PL Freight Distribution</option>
                  <option value="Manufacturing & Linehaul">Manufacturing & Linehaul</option>
                  <option value="Cold Chain Logistics">Cold Chain Logistics</option>
                  <option value="Warehousing & Fulfillment">Warehousing & Fulfillment</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Country & Region</label>
                <input
                  type="text"
                  value={country}
                  onChange={e => setCountry(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Timezone</label>
                <input
                  type="text"
                  value={timezone}
                  onChange={e => setTimezone(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Primary Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={e => setContactPerson(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Contact Email (for Alerts & Reports)</label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={e => setContactEmail(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Company Logo Icon / Emoji</label>
                <div className="flex gap-2">
                  {['🚛', '📦', '⚡', '🏢', '✈️', '⚓'].map(emoji => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setLogo(emoji)}
                      className={`w-10 h-10 rounded-lg border text-lg flex items-center justify-center cursor-pointer transition-all ${
                        logo === emoji ? 'border-sky-500 bg-sky-50 ring-2 ring-sky-200' : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Primary Brand Color</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={primaryBrandColor}
                    onChange={e => setPrimaryBrandColor(e.target.value)}
                    className="w-10 h-10 rounded border border-slate-300 cursor-pointer p-0.5"
                  />
                  <span className="font-mono text-xs text-slate-700 font-bold">{primaryBrandColor}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Choose Data Source */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 2: Choose Data Source Architecture</h3>
              <p className="text-xs text-slate-500">Select how operational shipments, routes, and vehicle telemetry will be ingested.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                {
                  id: 'CSV',
                  title: 'CSV / Flat File Batch',
                  desc: 'Upload historical or periodic daily dispatch dumps with automatic column header detection.',
                  icon: <UploadCloud className="w-6 h-6 text-sky-600" />
                },
                {
                  id: 'EXCEL',
                  title: 'Excel (.xlsx / .xls)',
                  desc: 'Import multi-tab spreadsheet workbooks with automated tab schema profiling.',
                  icon: <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
                },
                {
                  id: 'API',
                  title: 'REST API Telematics',
                  desc: 'Connect live TMS/GPS webhook streams with near real-time 5-minute ingestion.',
                  icon: <Database className="w-6 h-6 text-indigo-600" />
                },
                {
                  id: 'DB',
                  title: 'Direct Database Sync',
                  desc: 'Connect read-only PostgreSQL, MySQL, or SQL Server ERP warehouse instances.',
                  icon: <Sliders className="w-6 h-6 text-amber-600" />
                },
                {
                  id: 'DEMO',
                  title: 'Enterprise Demo Dataset',
                  desc: 'Initialize the workspace with realistic, verified South India logistics data.',
                  icon: <Sparkles className="w-6 h-6 text-purple-600" />
                }
              ].map(s => (
                <div
                  key={s.id}
                  onClick={() => setSourceType(s.id as any)}
                  className={`p-5 rounded-xl border-2 cursor-pointer transition-all ${
                    sourceType === s.id
                      ? 'border-sky-500 bg-sky-50/50 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="p-2.5 bg-white rounded-lg w-fit border border-slate-200 shadow-2xs mb-3">
                    {s.icon}
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm">{s.title}</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 3: Import Data */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 3: Import Data File</h3>
              <p className="text-xs text-slate-500">Upload your logistics records or confirm batch ingestion parameters.</p>
            </div>

            <div className="border-2 border-dashed border-sky-300 bg-sky-50/30 rounded-xl p-10 text-center space-y-4">
              <div className="w-14 h-14 bg-sky-100 text-sky-600 rounded-full flex items-center justify-center mx-auto">
                <UploadCloud className="w-7 h-7" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">
                  {fileUploaded ? `File Ready: ${fileName}` : 'Drag & drop your logistics CSV or Excel file'}
                </p>
                <p className="text-xs text-slate-500 mt-1">Supports UTF-8 CSV, TSV, XLSX up to 50MB</p>
              </div>

              {fileUploaded && (
                <div className="inline-flex items-center gap-4 bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-2xs text-xs">
                  <span className="font-mono text-slate-700"><strong>{rowCount.toLocaleString()}</strong> Rows Detected</span>
                  <span className="text-slate-300">•</span>
                  <span className="font-mono text-slate-700"><strong>12</strong> Columns Identified</span>
                  <span className="text-slate-300">•</span>
                  <span className="text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Ready for Mapping
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: Preview Data */}
        {step === 4 && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 4: Raw Ingestion Preview</h3>
              <p className="text-xs text-slate-500">Inspect the first 5 records of your uploaded operational dataset before transformation.</p>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 uppercase font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">shipment_id</th>
                    <th className="p-3">rider_name</th>
                    <th className="p-3">delivery_status</th>
                    <th className="p-3">origin_hub</th>
                    <th className="p-3">destination_hub</th>
                    <th className="p-3">transport_cost</th>
                    <th className="p-3">delay_mins</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-slate-600">
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">TRK-2026-8849</td>
                    <td className="p-3">Rajesh Kannan</td>
                    <td className="p-3 text-emerald-600 font-bold">DELIVERED</td>
                    <td className="p-3">Chennai Central</td>
                    <td className="p-3">Coimbatore Hub</td>
                    <td className="p-3">₹340</td>
                    <td className="p-3">0</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">TRK-2026-8850</td>
                    <td className="p-3">Suresh Babu</td>
                    <td className="p-3 text-amber-600 font-bold">DELAYED</td>
                    <td className="p-3">Bengaluru E-City</td>
                    <td className="p-3">Hubballi Gateway</td>
                    <td className="p-3">₹410</td>
                    <td className="p-3 text-rose-600">+45</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">TRK-2026-8851</td>
                    <td className="p-3">Vignesh V</td>
                    <td className="p-3 text-emerald-600 font-bold">DELIVERED</td>
                    <td className="p-3">Kochi Port Hub</td>
                    <td className="p-3">Thiruvananthapuram</td>
                    <td className="p-3">₹290</td>
                    <td className="p-3">0</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-[11px] text-slate-400 italic">Showing 3 of {rowCount.toLocaleString()} records.</p>
          </div>
        )}

        {/* STEP 5: Map Columns */}
        {step === 5 && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 5: Column Mapping Engine</h3>
              <p className="text-xs text-slate-500">
                Match your custom column names into SupplyFlow's standard logistics model with automatic AI suggestion support.
              </p>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 uppercase font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Your Column Header</th>
                    <th className="p-3">Sample Value</th>
                    <th className="p-3">SupplyFlow Canonical Field</th>
                    <th className="p-3">Data Type</th>
                    <th className="p-3">Mapping Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {columnMappings.slice(0, 6).map((m, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-3 font-mono font-bold text-slate-900">{m.companyColumn}</td>
                      <td className="p-3 font-mono text-slate-500">{m.sampleValue}</td>
                      <td className="p-3">
                        <select
                          value={m.targetField}
                          onChange={e => updateColumnMapping(m.companyColumn, e.target.value, 'MAPPED')}
                          className="px-2.5 py-1.5 border border-slate-300 rounded text-xs bg-white focus:ring-1 focus:ring-sky-500 font-semibold text-slate-800"
                        >
                          <option value="Order ID / Tracking Number">Order ID / Tracking Number</option>
                          <option value="Delivery Status">Delivery Status</option>
                          <option value="Assigned Driver">Assigned Driver</option>
                          <option value="Delivery Cost (₹)">Delivery Cost (₹)</option>
                          <option value="Origin City / Hub">Origin City / Hub</option>
                          <option value="Destination City / Hub">Destination City / Hub</option>
                          <option value="Delay Minutes">Delay Minutes</option>
                        </select>
                      </td>
                      <td className="p-3">
                        <span className="font-mono text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                          {m.dataType}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          <Check className="w-3 h-3" /> Auto-Mapped (98%)
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* STEP 6: Validate Data */}
        {step === 6 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 6: Data Quality & Validation Audit</h3>
              <p className="text-xs text-slate-500">Automated verification of missing coordinates, duplicate tracking codes, and negative costs.</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-xs text-slate-500 font-medium">Total Rows Screened</span>
                <p className="text-2xl font-bold font-mono text-slate-900 mt-1">{rowCount.toLocaleString()}</p>
              </div>
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="text-xs text-emerald-700 font-medium">Valid & Clean Rows</span>
                <p className="text-2xl font-bold font-mono text-emerald-700 mt-1">14,482</p>
                <span className="text-[10px] text-emerald-600 font-semibold">97.5% Quality Score</span>
              </div>
              <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
                <span className="text-xs text-amber-700 font-medium">Duplicate Tracking IDs</span>
                <p className="text-2xl font-bold font-mono text-amber-700 mt-1">18</p>
                <span className="text-[10px] text-amber-600">Ready for automated deduplication</span>
              </div>
              <div className="p-4 bg-sky-50 rounded-xl border border-sky-200">
                <span className="text-xs text-sky-700 font-medium">Missing Imputable Fields</span>
                <p className="text-2xl font-bold font-mono text-sky-700 mt-1">350</p>
                <span className="text-[10px] text-sky-600">Mean weight & distance matrix</span>
              </div>
            </div>

            <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-200 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-800">
                <strong>Validation Passed with Zero Critical Errors:</strong> The schema conforms to SupplyFlow multi-tenant SLA engine. All primary tracking identifiers and dispatch timestamps are valid.
              </div>
            </div>
          </div>
        )}

        {/* STEP 7: Clean Data */}
        {step === 7 && (
          <div className="space-y-5">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 7: Controlled Cleaning & Transformation</h3>
              <p className="text-xs text-slate-500">Apply non-destructive standardization rules with complete cleaning history logging.</p>
            </div>

            <div className="space-y-3">
              {cleaningSteps.map(stepItem => (
                <div key={stepItem.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">{stepItem.action}</span>
                      <span className="text-[10px] bg-sky-100 text-sky-700 font-bold px-2 py-0.5 rounded">
                        {stepItem.affectedRows.toLocaleString()} rows affected
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{stepItem.description}</p>
                  </div>
                  <button
                    onClick={() => applyCleaningAction(stepItem.id)}
                    className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-emerald-500 transition-colors cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" /> Applied
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 8: Configure KPIs */}
        {step === 8 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 8: Configure Company-Specific KPIs & SLA Benchmarks</h3>
              <p className="text-xs text-slate-500">Set custom operational thresholds for automated anomaly detection and executive alerting.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-700 uppercase">Target On-Time SLA Rate</label>
                  <span className="font-mono text-sm font-bold text-sky-600">{kpiOnTime}%</span>
                </div>
                <input
                  type="range"
                  min="80"
                  max="99"
                  step="0.5"
                  value={kpiOnTime}
                  onChange={e => setKpiOnTime(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
                <p className="text-[11px] text-slate-500">Alerts will trigger if network or regional on-time drops below this benchmark.</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-700 uppercase">Max Delay Tolerance (Minutes)</label>
                  <span className="font-mono text-sm font-bold text-sky-600">{kpiMaxDelay} mins</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  step="5"
                  value={kpiMaxDelay}
                  onChange={e => setKpiMaxDelay(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
                <p className="text-[11px] text-slate-500">Shipments exceeding this threshold are flagged as delayed delivery exceptions.</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-700 uppercase">Target Cost Per Delivery</label>
                  <span className="font-mono text-sm font-bold text-sky-600">₹{kpiTargetCost}</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="500"
                  step="5"
                  value={kpiTargetCost}
                  onChange={e => setKpiTargetCost(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
                <p className="text-[11px] text-slate-500">Cost leakage audit triggers when route cost exceeds target by &gt;12%.</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-700 uppercase">Target Fleet Utilization Rate</label>
                  <span className="font-mono text-sm font-bold text-sky-600">{kpiFleetUtil}%</span>
                </div>
                <input
                  type="range"
                  min="70"
                  max="98"
                  step="1"
                  value={kpiFleetUtil}
                  onChange={e => setKpiFleetUtil(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
                <p className="text-[11px] text-slate-500">Formula: (Active Operating Hours / Available Operating Hours) * 100.</p>
              </div>
            </div>
          </div>
        )}

        {/* STEP 9: Apply Branding */}
        {step === 9 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 9: Apply Custom Company Branding</h3>
              <p className="text-xs text-slate-500">Preview your customized enterprise theme and branded report styling.</p>
            </div>

            <div className="p-6 rounded-xl border border-slate-200 bg-slate-50 space-y-4">
              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-slate-200 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center text-xl bg-sky-50 border border-sky-200">
                    {logo}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{orgName}</h4>
                    <p className="text-xs text-slate-500">{orgName} — Operations Command Center</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 rounded-full" style={{ backgroundColor: primaryBrandColor }}></span>
                  <span className="text-xs font-mono font-bold text-slate-700">{primaryBrandColor}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">SLA Target</span>
                  <p className="text-lg font-bold text-slate-900 mt-1">{kpiOnTime}%</p>
                </div>
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Target Cost</span>
                  <p className="text-lg font-bold text-slate-900 mt-1">₹{kpiTargetCost}</p>
                </div>
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Tenant Status</span>
                  <p className="text-lg font-bold text-emerald-600 mt-1">Ready</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 10: Publish Dashboard */}
        {step === 10 && (
          <div className="space-y-6 text-center py-6">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
              <Rocket className="w-8 h-8" />
            </div>

            <div className="max-w-md mx-auto space-y-2">
              <h3 className="text-2xl font-bold text-slate-900">Ready to Publish {orgName} Dashboard</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                All 10 setup phases are complete. Your isolated company tenant is provisioned with {rowCount.toLocaleString()} validated records, standard column mappings, and customized SLA models.
              </p>
            </div>

            <div className="inline-flex gap-4">
              <button
                onClick={handlePublishDashboard}
                className="px-6 py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Rocket className="w-4 h-4" /> Launch Production Dashboard
              </button>
            </div>
          </div>
        )}

        {/* Wizard Footer Buttons */}
        <div className="flex items-center justify-between border-t border-slate-200 pt-5 mt-6">
          <button
            disabled={step === 1}
            onClick={() => setStep(prev => Math.max(1, prev - 1))}
            className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
              step === 1
                ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Previous Step
          </button>

          {step < 10 ? (
            <button
              onClick={() => setStep(prev => Math.min(10, prev + 1))}
              className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              Continue to Step {step + 1} <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={handlePublishDashboard}
              className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Check className="w-4 h-4" /> Complete & Publish
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
