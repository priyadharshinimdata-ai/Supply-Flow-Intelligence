import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  BarChart3,
  TrendingUp,
  Calendar,
  Layers,
  ArrowUpRight,
  Sparkles,
  Package,
  AlertCircle,
  Truck
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { MetricCard } from '../common/MetricCard';

export const DemandForecastView: React.FC = () => {
  const { kpis } = useLogistics();
  const [forecastHorizon, setForecastHorizon] = useState<'WEEKLY' | 'MONTHLY'>('WEEKLY');

  const weeklyForecastData = [
    { day: 'Mon', historical: 820, predicted: 840, lowerBound: 800, upperBound: 880 },
    { day: 'Tue', historical: 890, predicted: 910, lowerBound: 870, upperBound: 950 },
    { day: 'Wed', historical: 940, predicted: 960, lowerBound: 910, upperBound: 1010 },
    { day: 'Thu', historical: 920, predicted: 940, lowerBound: 890, upperBound: 990 },
    { day: 'Fri', historical: 1050, predicted: 1080, lowerBound: 1020, upperBound: 1140 },
    { day: 'Sat', historical: null, predicted: 1180, lowerBound: 1100, upperBound: 1260 },
    { day: 'Sun', historical: null, predicted: 890, lowerBound: 820, upperBound: 960 }
  ];

  const categoryDemand = [
    { category: 'E-Commerce & Retail', growth: '+14.2%', volume: 11200, risk: 'High Peak on Fri-Sat' },
    { category: 'Pharma & Temperature-Controlled', growth: '+8.6%', volume: 4800, risk: 'Cold-chain buffer required' },
    { category: 'Industrial & Spare Parts', growth: '+3.1%', volume: 5600, risk: 'Stable demand corridor' },
    { category: 'FMCG & Groceries', growth: '+18.4%', volume: 3220, risk: 'South Hub surge expected' }
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Demand Forecasting & Predictive Volume</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Machine-learning volume forecast, regional surge modeling, and fleet capacity allocation recommendations.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg text-xs font-semibold">
          <button
            onClick={() => setForecastHorizon('WEEKLY')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              forecastHorizon === 'WEEKLY' ? 'bg-white text-sky-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            7-Day Horizon
          </button>
          <button
            onClick={() => setForecastHorizon('MONTHLY')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              forecastHorizon === 'MONTHLY' ? 'bg-white text-sky-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            30-Day Outlook
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="demand-expected"
          title="Predicted Consignment Inflow"
          value="27,400"
          trendPercent={+10.4}
          tooltipText="Projected shipment load for next 30 days based on historical seasonality and corridor booking trends."
          icon={<Package className="w-4 h-4 text-sky-600" />}
          comparisonText="+2,580 vs current period"
          accentColor="blue"
        />

        <MetricCard
          id="demand-fleet-req"
          title="Recommended Active Fleet"
          value="202 Trucks"
          trendPercent={+8.6}
          tooltipText="Total vehicles needed to maintain >= 93% on-time SLA under forecasted volume."
          icon={<Truck className="w-4 h-4 text-emerald-600" />}
          comparisonText="16 additional trucks needed"
          accentColor="emerald"
        />

        <MetricCard
          id="demand-surge-risk"
          title="Peak Surge Index"
          value="1.28x"
          tooltipText="Friday-Saturday peak multiplier relative to average weekday volume."
          icon={<TrendingUp className="w-4 h-4 text-amber-600" />}
          comparisonText="Chennai & Bengaluru hubs"
          accentColor="amber"
        />

        <MetricCard
          id="demand-confidence"
          title="Model Confidence Score"
          value="94.6%"
          tooltipText="Backtested accuracy over the previous 90-day demand predictions."
          icon={<Sparkles className="w-4 h-4 text-sky-500" />}
          comparisonText="Gradient Boosted ML Model"
          accentColor="cyan"
        />
      </div>

      {/* Main Forecast Chart */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">Weekly Daily Volume vs Predicted Surge</h2>
            <p className="text-xs text-slate-500">Historical intake (Mon-Fri) combined with weekend predicted load and confidence intervals</p>
          </div>
          <span className="text-xs font-mono font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded border border-sky-200">
            Confidence Band: ±5.2%
          </span>
        </div>

        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={weeklyForecastData} margin={{ top: 10, right: 15, left: -15, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
              />
              <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }} />
              <Bar dataKey="historical" name="Actual Intake" fill="#0284c7" radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="predicted" name="Predicted Volume" stroke="#10b981" strokeWidth={3} strokeDasharray="4 4" dot={{ r: 4 }} />
              <Line type="monotone" dataKey="upperBound" name="Upper Threshold" stroke="#f59e0b" strokeWidth={1} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Demand Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Cargo Category Inflow Forecast</h2>
            <p className="text-xs text-slate-500">Segmented growth trajectory and capacity requirement</p>
          </div>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
            <tr>
              <th className="px-5 py-3">Category</th>
              <th className="px-5 py-3">Projected Monthly Units</th>
              <th className="px-5 py-3">Growth vs Last Month</th>
              <th className="px-5 py-3">Capacity Recommendation</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {categoryDemand.map((item, idx) => (
              <tr key={idx} className="hover:bg-slate-50">
                <td className="px-5 py-3 font-semibold text-slate-800">{item.category}</td>
                <td className="px-5 py-3 font-mono font-bold text-slate-900">{item.volume.toLocaleString()}</td>
                <td className="px-5 py-3 font-semibold text-emerald-600">{item.growth}</td>
                <td className="px-5 py-3 text-slate-600">{item.risk}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
