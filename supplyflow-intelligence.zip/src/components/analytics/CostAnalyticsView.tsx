import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  DollarSign,
  Fuel,
  TrendingDown,
  AlertTriangle,
  Sparkles,
  PieChart as PieIcon,
  ShieldAlert,
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';
import { MetricCard } from '../common/MetricCard';

export const CostAnalyticsView: React.FC = () => {
  const { kpis, costBreakdown, historicalTrend, setCurrentView } = useLogistics();

  const pieColors = ['#0284c7', '#0d9488', '#f59e0b', '#8b5cf6', '#64748b', '#ec4899'];

  const costTrendData = historicalTrend.slice(-14).map(item => {
    const perDrop = Math.round(item.cost / (item.deliveries || 1));
    return {
      date: item.date,
      costPerDelivery: perDrop,
      fuelCost: Math.round(perDrop * 0.34),
      laborCost: Math.round(perDrop * 0.28)
    };
  });

  const costLeakages = [
    {
      title: 'Excessive Engine Idling on Highway Corridors',
      corridor: 'Route TN-042 (Chennai ➔ Coimbatore)',
      monthlyWaste: 38400,
      cause: 'Severe traffic holds near Vellore bypass; trucks idle up to 48 mins with AC running.',
      remedy: 'Auto-engine shutdown policy + shift departure to off-peak 04:00 AM.'
    },
    {
      title: 'Warehouse Dock Demurrage & Overtime',
      corridor: 'Vijayawada Multi-Modal Terminal',
      monthlyWaste: 24000,
      cause: 'Congested loading bays cause 3+ hour driver overtime shifts.',
      remedy: 'Staggered dock appointment scheduling.'
    },
    {
      title: 'Off-Route Mileage Deviations',
      corridor: 'Kochi-Coimbatore Route (KL-014)',
      monthlyWaste: 19200,
      cause: 'Drivers taking manual diversions to avoid toll plazas, adding 42 km extra haul.',
      remedy: 'Geofenced GPS corridor enforcement.'
    }
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Cost Analytics & Financial Leakage Intelligence</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Granular breakdown of fuel expenses, driver overtime, vehicle maintenance, and route profitability analysis.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="cost-total"
          title="Total Operational Logistics Cost"
          value={kpis.totalCostStr}
          trendPercent={kpis.costTrend}
          isInverseTrendPositive={true}
          tooltipText="Total monthly spend across fuel, maintenance, driver salaries, and infrastructure."
          icon={<DollarSign className="w-4 h-4 text-sky-600" />}
          comparisonText="Budget ceiling: ₹8.70L"
          accentColor="blue"
        />

        <MetricCard
          id="cost-per-unit"
          title="Cost Per Delivery"
          value={`₹${kpis.costPerDelivery}`}
          trendPercent={-4.0}
          isInverseTrendPositive={true}
          tooltipText="Net expenditure per drop completed across all active routes."
          icon={<DollarSign className="w-4 h-4 text-emerald-600" />}
          comparisonText="Target benchmark: ₹325"
          accentColor="emerald"
        />

        <MetricCard
          id="cost-fuel"
          title="Fuel Expenditure Ratio"
          value="34.2%"
          tooltipText="Percentage of overall logistics outlay attributed purely to fuel / energy consumption."
          icon={<Fuel className="w-4 h-4 text-amber-600" />}
          comparisonText="₹2.88L Fuel spend"
          accentColor="amber"
        />

        <MetricCard
          id="cost-leakage-identified"
          title="Identified Waste / Leakage"
          value="₹81,600 / mo"
          trendPercent={-14.2}
          isInverseTrendPositive={true}
          tooltipText="Total avoidable monthly cost from idling, un-staggered dock wait times, and off-route diversions."
          icon={<AlertTriangle className="w-4 h-4 text-rose-600" />}
          comparisonText="3 critical hotspots flagged"
          accentColor="rose"
        />
      </div>

      {/* Breakdown Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Cost Category Donut Chart */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="pb-3 mb-2 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Cost Composition</h2>
            <p className="text-xs text-slate-500">Distribution of operational expenditures</p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={costBreakdown}
                  dataKey="amount"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                >
                  {costBreakdown.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => `₹${Number(val).toLocaleString()}`}
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 14-Day Cost per Delivery Trend */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="pb-3 mb-4 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Cost Per Delivery Trend (₹)</h2>
            <p className="text-xs text-slate-500">Tracking fuel component vs labor component per delivery drop</p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costTrendData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="fuelCost" name="Fuel / Energy Component (₹)" fill="#0284c7" stackId="a" />
                <Bar dataKey="laborCost" name="Driver / Labor Component (₹)" fill="#0d9488" stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Identified Cost Leakages Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Operational Cost Leakage Hotspots</h2>
            <p className="text-xs text-slate-500">Identified algorithmic waste &amp; recommended remediation</p>
          </div>
          <span className="text-xs font-mono font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded border border-rose-200">
            Total Leakage: ₹81,600/month
          </span>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
            <tr>
              <th className="px-5 py-3">Leakage Opportunity</th>
              <th className="px-5 py-3">Affected Corridor / Hub</th>
              <th className="px-5 py-3">Monthly Avoidable Loss</th>
              <th className="px-5 py-3">Root Cause &amp; Remediation</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {costLeakages.map((leak, idx) => (
              <tr key={idx} className="hover:bg-slate-50">
                <td className="px-5 py-3 font-semibold text-slate-900">{leak.title}</td>
                <td className="px-5 py-3 font-mono font-bold text-sky-700">{leak.corridor}</td>
                <td className="px-5 py-3 font-mono font-bold text-rose-600">₹{leak.monthlyWaste.toLocaleString()}</td>
                <td className="px-5 py-3 text-slate-600 leading-relaxed">
                  <p><strong className="text-slate-800">Cause:</strong> {leak.cause}</p>
                  <p className="text-emerald-700 font-medium mt-0.5"><strong className="text-emerald-800">Remedy:</strong> {leak.remedy}</p>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
