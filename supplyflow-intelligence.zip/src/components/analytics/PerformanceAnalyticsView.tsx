import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ReferenceLine
} from 'recharts';
import { MetricCard } from '../common/MetricCard';

export const PerformanceAnalyticsView: React.FC = () => {
  const { kpis, historicalTrend, delayPareto, setCurrentView } = useLogistics();

  const hourlyDelayDistribution = [
    { hour: '00:00', delays: 12, shipments: 120 },
    { hour: '04:00', delays: 8, shipments: 210 },
    { hour: '08:00', delays: 38, shipments: 480 },
    { hour: '11:00', delays: 62, shipments: 620 },
    { hour: '14:00', delays: 44, shipments: 540 },
    { hour: '17:00', delays: 89, shipments: 710 }, // Evening peak congestion
    { hour: '20:00', delays: 56, shipments: 580 },
    { hour: '22:00', delays: 24, shipments: 320 }
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900">Delivery Performance & SLA Adherence</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Historical analysis of transit SLAs, on-time delivery consistency, and peak-hour delivery deviation.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="perf-ontime"
          title="Network On-Time SLA"
          value={`${kpis.onTimeRate}%`}
          trendPercent={kpis.onTimeTrend}
          tooltipText="Deliveries completed on or prior to committed customer SLA window."
          icon={<CheckCircle2 className="w-4 h-4 text-emerald-600" />}
          comparisonText="Target SLA: 95.0%"
          accentColor="emerald"
        />

        <MetricCard
          id="perf-avg-time"
          title="Average Transit Time"
          value={kpis.avgDeliveryTimeStr}
          trendPercent={-2.8}
          isInverseTrendPositive={true}
          tooltipText="Average duration from dispatch confirmation to customer delivery receipt."
          icon={<Clock className="w-4 h-4 text-blue-600" />}
          comparisonText="4h 18m benchmark"
          accentColor="blue"
        />

        <MetricCard
          id="perf-delays"
          title="Delayed Consignments"
          value={kpis.delayedDeliveries.toLocaleString()}
          trendPercent={kpis.delayedTrend}
          isInverseTrendPositive={true}
          tooltipText="Total count of shipments exceeding promised transit window."
          icon={<AlertTriangle className="w-4 h-4 text-amber-600" />}
          comparisonText="7.4% of network volume"
          accentColor="amber"
        />

        <MetricCard
          id="perf-complaints"
          title="SLA Grievance Rate"
          value="0.99%"
          trendPercent={-18.2}
          isInverseTrendPositive={true}
          tooltipText="Complaints logged per 1,000 completed shipments."
          icon={<TrendingUp className="w-4 h-4 text-cyan-600" />}
          comparisonText="248 total complaints"
          accentColor="cyan"
        />
      </div>

      {/* Main SLA Trend Chart */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">30-Day On-Time SLA Performance Trend</h2>
            <p className="text-xs text-slate-500">Daily SLA percentage compared against the 95.0% contract target</p>
          </div>
          <span className="text-xs font-mono font-bold text-slate-600">Contract Benchmark: 95%</span>
        </div>

        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={historicalTrend} margin={{ top: 10, right: 15, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis domain={[85, 100]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
              />
              <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }} />
              <ReferenceLine y={95} stroke="#10b981" strokeDasharray="4 4" label={{ value: 'Target 95%', fill: '#10b981', fontSize: 10 }} />
              <Line type="monotone" dataKey="onTimeRate" name="Actual On-Time Rate %" stroke="#2563eb" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Hourly Delay Distribution & Pareto Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hourly Delay Peaks */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="pb-3 mb-4 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Hourly Delay Incident Peaks</h2>
            <p className="text-xs text-slate-500">Evening rush hours (17:00–19:00) cause 38% of total delay spikes</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyDelayDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="delays" name="Delay Incidents" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Delay Pareto Root Causes */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="pb-3 mb-3 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">Pareto Root Cause Distribution</h2>
              <p className="text-xs text-slate-500">Financial impact associated with top delay factors</p>
            </div>

            <div className="space-y-3">
              {delayPareto.map((item, idx) => (
                <div key={item.reason} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-slate-800">{idx + 1}. {item.reason}</span>
                    <span className="font-mono text-slate-600 font-bold">{item.count} incidents ({item.percentage}%)</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>Primary Area: {item.primaryRegion}</span>
                    <span className="font-mono font-bold text-rose-600">Cost Impact: ₹{(item.costImpact / 1000).toFixed(1)}k</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
            <button
              onClick={() => setCurrentView('routes')}
              className="text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1"
            >
              Analyze Route Delays <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
