import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Sparkles,
  TrendingDown,
  Clock
} from 'lucide-react';
import { SeverityBadge } from '../common/StatusBadge';

export const AnomaliesView: React.FC = () => {
  const { anomalies, acknowledgeAnomaly, setCurrentView } = useLogistics();

  const unackCount = anomalies.filter(a => !a.acknowledged).length;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <h1 className="text-xl font-bold text-slate-900">Statistical Anomaly & Operational Outlier Detection</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Automated z-score outlier algorithms flagging irregular delivery durations, unexpected cost jumps, and corridor breakdowns.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold px-3 py-1.5 bg-amber-50 text-amber-800 rounded-lg border border-amber-200">
            {unackCount} Active Anomalies
          </span>
        </div>
      </div>

      {/* Anomalies List */}
      <div className="space-y-4">
        {anomalies.map(anomaly => (
          <div
            key={anomaly.id}
            className={`bg-white p-5 rounded-xl border transition-all ${
              !anomaly.acknowledged
                ? 'border-amber-300 ring-2 ring-amber-500/20 shadow-sm'
                : 'border-slate-200 opacity-80'
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 mb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  anomaly.severity === 'CRITICAL' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-sky-700">{anomaly.entityName}</span>
                    <span className="text-slate-300">•</span>
                    <SeverityBadge severity={anomaly.severity} />
                  </div>
                  <h2 className="text-sm font-bold text-slate-900 mt-0.5">{anomaly.metric}: {anomaly.currentValue} (vs {anomaly.baselineValue} baseline)</h2>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400 font-mono">{anomaly.detectedAt}</span>
                {!anomaly.acknowledged ? (
                  <button
                    onClick={() => acknowledgeAnomaly(anomaly.id)}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                  >
                    Acknowledge
                  </button>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                    <CheckCircle className="w-3.5 h-3.5" /> Acknowledged
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Root Cause Investigation
                </span>
                <p className="text-slate-700 leading-relaxed">{anomaly.possibleRootCause}</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Observed Anomaly Context
                </span>
                <p className="text-slate-900 font-semibold">{anomaly.description}</p>
                <p className="text-rose-600 font-bold mt-1">Deviation: {anomaly.deviationPercent > 0 ? `+${anomaly.deviationPercent}%` : `${anomaly.deviationPercent}%`}</p>
              </div>

              <div className="p-3 bg-sky-50/60 rounded-lg border border-sky-100 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-sky-800 block mb-1">
                    Recommended Corrective Action
                  </span>
                  <p className="text-slate-800 font-medium">{anomaly.recommendedInvestigation}</p>
                </div>
                <div className="mt-2 pt-2 border-t border-sky-200/60 flex justify-end">
                  <button
                    onClick={() => setCurrentView('routes')}
                    className="text-xs font-bold text-sky-700 hover:text-sky-900 flex items-center gap-1 cursor-pointer"
                  >
                    Inspect in Routes <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
