import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  CheckCircle,
  ShieldCheck,
  AlertTriangle,
  FileCheck,
  Layers,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { MetricCard } from '../common/MetricCard';

export const DataQualityView: React.FC = () => {
  const { dataQuality } = useLogistics();

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            <h1 className="text-xl font-bold text-slate-900">Data Quality & Telemetry Audit (94% Health)</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Continuous validation scores for completeness, schema integrity, duplicate records, and GPS coordinate validity.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="dq-score"
          title="Overall Data Quality Score"
          value="94.2%"
          trendPercent={+1.8}
          tooltipText="Composite metric evaluating completeness, accuracy, timeliness, and validity across all ingested rows."
          icon={<ShieldCheck className="w-4 h-4 text-emerald-600" />}
          comparisonText="Enterprise Target: ≥ 90.0%"
          accentColor="emerald"
        />

        <MetricCard
          id="dq-completeness"
          title="Field Completeness"
          value="98.7%"
          tooltipText="Percentage of records containing all required telemetry keys without nulls."
          icon={<FileCheck className="w-4 h-4 text-sky-600" />}
          comparisonText="1.3% missing secondary geocodes"
          accentColor="blue"
        />

        <MetricCard
          id="dq-timeliness"
          title="Ingestion Latency"
          value="1.2 sec"
          tooltipText="Average duration from GPS device broadcast to dashboard database indexing."
          icon={<CheckCircle className="w-4 h-4 text-cyan-600" />}
          comparisonText="99.9% real-time uptime"
          accentColor="cyan"
        />

        <MetricCard
          id="dq-duplicates"
          title="Duplicate Anomaly Rate"
          value="0.04%"
          isInverseTrendPositive={true}
          tooltipText="Percentage of identical tracking IDs intercepted during automated intake."
          icon={<AlertTriangle className="w-4 h-4 text-amber-600" />}
          comparisonText="Auto-deduplication active"
          accentColor="amber"
        />
      </div>

      {/* Quality Checks Breakdown Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100">
          <h2 className="text-base font-bold text-slate-900">Automated Pipeline Validation Suite</h2>
          <p className="text-xs text-slate-500">Continuous rule-checking on 24,800+ records</p>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
            <tr>
              <th className="px-5 py-3">Validation Check</th>
              <th className="px-5 py-3">Status</th>
              <th className="px-5 py-3">Score</th>
              <th className="px-5 py-3">Notes & Remediations</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr className="hover:bg-slate-50">
              <td className="px-5 py-3 font-semibold text-slate-900">Tracking Number Format & Uniqueness</td>
              <td className="px-5 py-3"><span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded text-[11px]">PASS</span></td>
              <td className="px-5 py-3 font-mono font-bold text-slate-900">100.0%</td>
              <td className="px-5 py-3 text-slate-600">Regex check against ^TRK-2026-[0-9]{'{6}'}$ passed.</td>
            </tr>
            <tr className="hover:bg-slate-50">
              <td className="px-5 py-3 font-semibold text-slate-900">GPS Geo-Coordinates Range Audit</td>
              <td className="px-5 py-3"><span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded text-[11px]">PASS</span></td>
              <td className="px-5 py-3 font-mono font-bold text-slate-900">96.8%</td>
              <td className="px-5 py-3 text-slate-600">Coordinates strictly contained within South India bounding box.</td>
            </tr>
            <tr className="hover:bg-slate-50">
              <td className="px-5 py-3 font-semibold text-slate-900">Delivery Status State Machine Validation</td>
              <td className="px-5 py-3"><span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded text-[11px]">PASS</span></td>
              <td className="px-5 py-3 font-mono font-bold text-slate-900">99.4%</td>
              <td className="px-5 py-3 text-slate-600">No illegal state jumps (e.g. INTAKE directly to DELIVERED).</td>
            </tr>
            <tr className="hover:bg-slate-50">
              <td className="px-5 py-3 font-semibold text-slate-900">Cost & Fuel Numerical Outlier Audit</td>
              <td className="px-5 py-3"><span className="text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded text-[11px]">ATTENTION</span></td>
              <td className="px-5 py-3 font-mono font-bold text-slate-900">91.2%</td>
              <td className="px-5 py-3 text-slate-600">14 trip entries flagged &gt; 3-sigma fuel spend due to NH-544 traffic idle.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
