import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Sparkles,
  ArrowRight,
  Database
} from 'lucide-react';

export const DataUploadView: React.FC = () => {
  const { applyUploadedDataset, dataQuality, setCurrentView } = useLogistics();
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; size: string; rows: number } | null>(null);
  const [cleaningStatus, setCleaningStatus] = useState<'IDLE' | 'PROCESSING' | 'COMPLETED'>('IDLE');

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      simulateFileUpload(e.dataTransfer.files[0].name);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      simulateFileUpload(e.target.files[0].name);
    }
  };

  const simulateFileUpload = (filename: string) => {
    setUploadedFile({
      name: filename,
      size: '4.8 MB',
      rows: 12450
    });
    setCleaningStatus('PROCESSING');
    setTimeout(() => {
      setCleaningStatus('COMPLETED');
      applyUploadedDataset([], filename);
    }, 1200);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Data Ingestion, CSV Cleaning & Pipeline Validation</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Upload raw TMS (Transport Management System) export files, GPS telematics CSVs, or ERP consignee manifests.
          </p>
        </div>
      </div>

      {/* Upload Box */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`bg-white rounded-xl border-2 border-dashed p-10 text-center transition-all ${
          dragActive
            ? 'border-sky-500 bg-sky-50/50'
            : 'border-slate-300 hover:border-sky-400 bg-white'
        }`}
      >
        <div className="max-w-md mx-auto space-y-3">
          <div className="w-12 h-12 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mx-auto border border-sky-200">
            <UploadCloud className="w-6 h-6" />
          </div>
          <h2 className="text-sm font-bold text-slate-900">
            Drag & drop logistics CSV or Excel spreadsheet
          </h2>
          <p className="text-xs text-slate-500">
            Supports .CSV, .XLSX, .JSON telemetry dumps up to 50MB. Auto-validates tracking IDs, timestamps, and GPS coordinates.
          </p>

          <div className="pt-2">
            <label className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-2 shadow-xs">
              <FileSpreadsheet className="w-4 h-4" />
              <span>Browse Computer</span>
              <input
                type="file"
                accept=".csv,.xlsx,.json"
                onChange={handleFileInput}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Upload Processing / Verification Result */}
      {uploadedFile && (
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
              <div>
                <h3 className="text-sm font-bold text-slate-900">{uploadedFile.name}</h3>
                <span className="text-xs text-slate-400">{uploadedFile.size} • {uploadedFile.rows.toLocaleString()} records</span>
              </div>
            </div>

            {cleaningStatus === 'PROCESSING' ? (
              <span className="text-xs font-bold text-sky-600 flex items-center gap-1.5 animate-pulse">
                <Sparkles className="w-3.5 h-3.5" /> Running Automated Cleansing...
              </span>
            ) : (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> 100% Ingested & Indexed
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Deduplication</span>
              <span className="text-emerald-700 font-bold font-mono">142 duplicates removed</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Null Coordinate Fixes</span>
              <span className="text-emerald-700 font-bold font-mono">89 geocodes interpolated</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">SLA Timestamps</span>
              <span className="text-emerald-700 font-bold font-mono">Normalized to IST (UTC+5:30)</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Quality Index</span>
                <span className="text-sky-700 font-bold font-mono text-sm">98.2% Valid</span>
              </div>
              <button
                onClick={() => setCurrentView('dashboard')}
                className="px-2.5 py-1 bg-sky-600 text-white rounded text-[11px] font-bold hover:bg-sky-500 transition-colors"
              >
                View Dashboard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pipeline Status Overview */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <h3 className="text-sm font-bold text-slate-900 mb-3">Pre-Configured Ingestion Connectors</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-900 block">TMS SAP S/4HANA</span>
              <span className="text-slate-500 text-[11px]">Syncing every 10 mins</span>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-900 block">GPS Telematics (Teltonika / Trimble)</span>
              <span className="text-slate-500 text-[11px]">Live WebSocket streaming</span>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <span className="font-bold text-slate-900 block">Fastag Toll Automated Deductions</span>
              <span className="text-slate-500 text-[11px]">Daily settlement reconciler</span>
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>
        </div>
      </div>
    </div>
  );
};
