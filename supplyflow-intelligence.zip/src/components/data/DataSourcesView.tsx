import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Database,
  CheckCircle2,
  RefreshCw,
  Server,
  Radio,
  FileSpreadsheet,
  Layers,
  ArrowRight
} from 'lucide-react';

export const DataSourcesView: React.FC = () => {
  const { dataSources } = useLogistics();

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Data Sources & Pipeline Integrations</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Active telemetry connections, TMS sync schedules, ERP API endpoints, and database connection statuses.
          </p>
        </div>
      </div>

      {/* Sources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {dataSources.map(source => (
          <div
            key={source.id}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-sky-300 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-sky-50 text-sky-600 border border-sky-200">
                    <Database className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">{source.name}</h2>
                    <span className="text-xs text-slate-400 font-mono">{source.type}</span>
                  </div>
                </div>

                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  {source.status}
                </span>
              </div>

              <div className="space-y-2 text-xs text-slate-600 my-3">
                <div className="flex justify-between">
                  <span className="text-slate-500">Record Throughput:</span>
                  <span className="font-mono font-bold text-slate-900">{source.recordsIngested.toLocaleString()} events</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Last Synced:</span>
                  <span className="font-mono text-slate-700">{source.lastSyncTimestamp}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sync Cadence:</span>
                  <span className="font-mono text-slate-700">{source.syncFrequency}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Data Health Score:</span>
                  <span className="font-mono font-bold text-emerald-600">{source.qualityScore}%</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Endpoint: {source.endpointUrl || 'api.supplyflow.internal/v2'}</span>
              <button className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-bold transition-colors cursor-pointer">
                Test Ping
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
