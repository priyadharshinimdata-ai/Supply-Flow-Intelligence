import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  FileText,
  Download,
  Calendar,
  Filter,
  CheckCircle2,
  Share2,
  FileSpreadsheet,
  Printer
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { kpis, filteredDeliveries } = useLogistics();
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const reportTemplates = [
    {
      id: 'sla-monthly',
      title: 'Executive SLA & Delivery Performance Digest',
      desc: 'High-level executive summary of on-time rates, carrier benchmarks, regional rankings, and grievance metrics.',
      format: 'PDF / CSV',
      frequency: 'Monthly'
    },
    {
      id: 'cost-leakage',
      title: 'Route Cost Leakage & Idling Audit Report',
      desc: 'Granular breakdown of fuel wastage, dock demurrage overtime, and corridor profitability analysis.',
      format: 'XLSX',
      frequency: 'Weekly'
    },
    {
      id: 'driver-safety',
      title: 'Workforce Safety & Telematics Scorecards',
      desc: 'Individual driver speed violations, harsh braking instances, on-time scores, and incentive payout calculations.',
      format: 'PDF / CSV',
      frequency: 'Bi-Weekly'
    },
    {
      id: 'customs-manifest',
      title: 'Consolidated Consignment Dispatch Manifest',
      desc: 'Comprehensive ledger of all 24,800+ consignments, tracking numbers, vehicle plates, and timestamps.',
      format: 'CSV (Raw Export)',
      frequency: 'Daily'
    }
  ];

  const handleExport = (templateTitle: string, format: string) => {
    setDownloadSuccess(`Exported "${templateTitle}" as ${format}`);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Reports, Exports & Operational Audit Logs</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Generate executive compliance summaries, automated SLA audits, and raw dataset exports.
          </p>
        </div>

        {downloadSuccess && (
          <div className="px-3 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-lg flex items-center gap-1.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {downloadSuccess}
          </div>
        )}
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reportTemplates.map(rep => (
          <div
            key={rep.id}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-sky-300 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                  {rep.frequency}
                </span>
                <span className="text-xs font-mono text-slate-400">{rep.format}</span>
              </div>

              <h2 className="text-sm font-bold text-slate-900 mb-1">{rep.title}</h2>
              <p className="text-xs text-slate-600 mb-4 leading-relaxed">{rep.desc}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Current Filter Scope (Aug 2026)</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleExport(rep.title, 'CSV')}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> CSV
                </button>
                <button
                  onClick={() => handleExport(rep.title, 'PDF')}
                  className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> PDF
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
