import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Users,
  ShieldCheck,
  Award,
  Clock,
  AlertCircle,
  Star,
  CheckCircle2,
  TrendingUp,
  Info,
  Car
} from 'lucide-react';
import { MetricCard } from '../common/MetricCard';

export const DriversView: React.FC = () => {
  const { filteredDrivers } = useLogistics();

  const avgOnTime = (filteredDrivers.reduce((acc, d) => acc + d.onTimeRate, 0) / (filteredDrivers.length || 1)).toFixed(1);
  const avgSafety = (filteredDrivers.reduce((acc, d) => acc + d.safetyRating, 0) / (filteredDrivers.length || 1)).toFixed(1);

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Driver Workforce & Operational Safety</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Constructive, multi-factor performance tracking incorporating corridor difficulty, on-time SLA, and safety compliance.
          </p>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="drv-active"
          title="Active Driver Roster"
          value={filteredDrivers.length}
          tooltipText="Total commercially certified drivers assigned across regional hubs."
          icon={<Users className="w-4 h-4 text-sky-600" />}
          comparisonText="100% background verified"
          accentColor="blue"
        />

        <MetricCard
          id="drv-ontime"
          title="Workforce On-Time Avg"
          value={`${avgOnTime}%`}
          trendPercent={+1.4}
          tooltipText="Average on-time delivery execution rate across all driver shifts."
          icon={<CheckCircle2 className="w-4 h-4 text-emerald-600" />}
          comparisonText="Target SLA: ≥ 92.0%"
          accentColor="emerald"
        />

        <MetricCard
          id="drv-safety"
          title="Fleet Safety Index"
          value={`${avgSafety} / 5.0`}
          trendPercent={+0.8}
          tooltipText="Composite score measuring speed adherence, harsh braking telematics, and clean trip logs."
          icon={<ShieldCheck className="w-4 h-4 text-cyan-600" />}
          comparisonText="0 speeding incidents this week"
          accentColor="cyan"
        />

        <MetricCard
          id="drv-complaints"
          title="Driver Escalations"
          value="4"
          trendPercent={-42.0}
          isInverseTrendPositive={true}
          tooltipText="Formal consignee grievances filed specifically related to delivery demeanor."
          icon={<Award className="w-4 h-4 text-amber-600" />}
          comparisonText="Industry lowest rate (0.01%)"
          accentColor="amber"
        />
      </div>

      {/* Fair Analytics Policy Banner */}
      <div className="bg-[#0F172A] text-white rounded-xl p-4 flex items-center justify-between shadow-md border border-slate-800">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
            <Info className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-sky-300">Fair Logistics Analytics Policy:</span>
            <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
              Performance indicators automatically adjust for severe weather conditions, documented warehouse queue delays, and highway holds to ensure fair evaluation of on-duty drivers.
            </p>
          </div>
        </div>
      </div>

      {/* Drivers Roster Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Driver Name</th>
                <th className="py-3 px-4">Employee Code</th>
                <th className="py-3 px-4">Primary Region</th>
                <th className="py-3 px-4">Assigned Vehicle</th>
                <th className="py-3 px-4">Total Deliveries</th>
                <th className="py-3 px-4">On-Time SLA</th>
                <th className="py-3 px-4">Avg Trip Time</th>
                <th className="py-3 px-4">Safety Score</th>
                <th className="py-3 px-4">Duty Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredDrivers.map(drv => (
                <tr key={drv.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{drv.name}</div>
                    <div className="text-[10px] text-slate-400">{drv.phone}</div>
                  </td>
                  <td className="py-3 px-4 font-mono font-semibold text-slate-600">
                    {drv.employeeCode}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {drv.region}
                  </td>
                  <td className="py-3 px-4 font-mono text-sky-700 font-bold">
                    {drv.assignedVehicleId}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    {drv.totalDeliveries.toLocaleString()}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`font-mono font-bold ${drv.onTimeRate >= 92 ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {drv.onTimeRate}%
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-700">
                    {Math.floor(drv.avgDeliveryDurationMins / 60)}h {drv.avgDeliveryDurationMins % 60}m
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1 font-mono font-bold text-amber-700">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span>{drv.safetyRating.toFixed(1)}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        drv.status === 'ON_DUTY'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : drv.status === 'ON_BREAK'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        drv.status === 'ON_DUTY' ? 'bg-emerald-500' : drv.status === 'ON_BREAK' ? 'bg-amber-500' : 'bg-slate-400'
                      }`} />
                      {drv.status === 'ON_DUTY' ? 'On Duty' : drv.status === 'ON_BREAK' ? 'On Break' : 'Off Duty'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
