import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { VehicleInfo } from '../../types';
import {
  Car,
  Truck,
  Fuel,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Zap,
  Info,
  Wrench,
  Search,
  Filter
} from 'lucide-react';
import { MetricCard } from '../common/MetricCard';

export const FleetView: React.FC = () => {
  const { filteredVehicles, kpis, updateFilter, filters } = useLogistics();
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('ALL');

  const activeCount = filteredVehicles.filter(v => v.currentStatus === 'ACTIVE').length;
  const idleCount = filteredVehicles.filter(v => v.currentStatus === 'IDLE').length;
  const maintenanceCount = filteredVehicles.filter(v => v.currentStatus === 'MAINTENANCE').length;

  const displayVehicles = selectedTypeFilter === 'ALL'
    ? filteredVehicles
    : filteredVehicles.filter(v => v.type.includes(selectedTypeFilter));

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-sky-600" />
            <h1 className="text-xl font-bold text-slate-900">Commercial Fleet &amp; Asset Intelligence</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Telemetry tracking vehicle utilization, fuel economy (km/L), telematics health scores, and scheduled maintenance.
          </p>
        </div>
      </div>

      {/* 4 Fleet Overview KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="fleet-total"
          title="Total Commercial Fleet"
          value={kpis.totalVehicles}
          tooltipText="Total registered commercial transport assets in the active logistics registry."
          icon={<Truck className="w-4 h-4 text-sky-600" />}
          comparisonText="100% telemetry enabled"
          accentColor="blue"
        />

        <MetricCard
          id="fleet-active"
          title="Active On-Route"
          value={activeCount}
          tooltipText="Commercial vehicles currently dispatched and executing haul trips."
          icon={<Activity className="w-4 h-4 text-emerald-600" />}
          comparisonText={`${Math.round((activeCount / (kpis.totalVehicles || 1)) * 100)}% active duty`}
          accentColor="emerald"
        />

        <MetricCard
          id="fleet-utilization"
          title="Fleet Utilization Rate"
          value={`${kpis.fleetUtilizationRate}%`}
          trendPercent={+3.2}
          tooltipText="Formula: (Active Operating Hours / Available Operating Hours) × 100"
          icon={<Zap className="w-4 h-4 text-cyan-600" />}
          comparisonText="Target benchmark: ≥ 85.0%"
          accentColor="cyan"
        />

        <MetricCard
          id="fleet-maintenance"
          title="In Maintenance / Idle"
          value={`${maintenanceCount} Maint • ${idleCount} Idle`}
          tooltipText="Vehicles undergoing routine dock servicing or awaiting scheduled driver shift."
          icon={<Wrench className="w-4 h-4 text-amber-600" />}
          comparisonText="Zero critical engine flags"
          accentColor="amber"
        />
      </div>

      {/* Utilization Formula & Electric Fleet Highlight */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 bg-[#0F172A] rounded-xl p-4 text-white flex items-center justify-between shadow-md border border-slate-800">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 font-mono">
              Utilization Formula Standard
            </span>
            <div className="text-sm font-mono font-bold mt-1 text-slate-100">
              Fleet Utilization % = (Active Operating Hours / Available Operating Hours) × 100
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Current network average: <strong>88.5%</strong>. Maximizing duty cycles without exceeding statutory driver rest limits.
            </p>
          </div>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-emerald-900 font-bold text-xs">
              <Zap className="w-4 h-4 text-emerald-600" />
              Green EV Fleet Share
            </div>
            <p className="text-xs text-emerald-800 mt-1">
              <strong>18 Electric Vans</strong> deployed on intra-city Bengaluru and Chennai micro-hubs, saving ₹42,000/mo in diesel expenses.
            </p>
          </div>
          <span className="text-[11px] font-semibold text-emerald-700 mt-2">Zero tailpipe emissions</span>
        </div>
      </div>

      {/* Filter Tabs by Vehicle Type */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        {['ALL', 'Heavy Hauler', 'Medium Truck', 'Light Commercial', 'Electric Van', 'Refrigerated Truck'].map(type => (
          <button
            key={type}
            onClick={() => setSelectedTypeFilter(type)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              selectedTypeFilter === type
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {type === 'ALL' ? 'All Vehicle Types' : type}
          </button>
        ))}
      </div>

      {/* Vehicle Asset Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Plate Number</th>
                <th className="py-3 px-4">Type &amp; Fuel</th>
                <th className="py-3 px-4">Assigned Driver</th>
                <th className="py-3 px-4">Fuel Economy</th>
                <th className="py-3 px-4">Total Odometer</th>
                <th className="py-3 px-4">Utilization</th>
                <th className="py-3 px-4">Telematics Health</th>
                <th className="py-3 px-4">Current Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {displayVehicles.map(veh => (
                <tr key={veh.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    {veh.plateNumber}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-800">{veh.type}</div>
                    <div className="text-[11px] text-slate-400">{veh.fuelType}</div>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800">
                    {veh.assignedDriverName}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">
                    {veh.fuelEfficiencyKmPerUnit} {veh.fuelType === 'EV' ? 'km/kWh' : 'km/L'}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-600">
                    {veh.totalDistanceKm.toLocaleString()} km
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">{veh.utilizationRate}%</span>
                      <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-sky-600 h-full rounded-full"
                          style={{ width: `${veh.utilizationRate}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 font-mono font-bold ${
                      veh.healthScore >= 90 ? 'text-emerald-700' : 'text-amber-700'
                    }`}>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {veh.healthScore}/100
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        veh.currentStatus === 'ACTIVE'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : veh.currentStatus === 'IDLE'
                          ? 'bg-slate-100 text-slate-600 border border-slate-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        veh.currentStatus === 'ACTIVE' ? 'bg-emerald-500' : veh.currentStatus === 'IDLE' ? 'bg-slate-400' : 'bg-amber-500'
                      }`} />
                      {veh.currentStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
