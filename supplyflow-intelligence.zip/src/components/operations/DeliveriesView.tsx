import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { DeliveryRecord } from '../../types';
import { DeliveryStatusBadge } from '../common/StatusBadge';
import {
  Search,
  Filter,
  Package,
  Truck,
  MapPin,
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  X,
  FileText,
  User,
  Scale,
  Calendar
} from 'lucide-react';

export const DeliveriesView: React.FC = () => {
  const {
    filteredDeliveries,
    filters,
    updateFilter,
    routes,
    vehicles,
    drivers
  } = useLogistics();

  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryRecord | null>(null);

  const statusTabs = [
    { label: 'All Shipments', value: 'ALL' },
    { label: 'Delivered', value: 'DELIVERED' },
    { label: 'Out for Delivery', value: 'OUT_FOR_DELIVERY' },
    { label: 'In Transit', value: 'IN_TRANSIT' },
    { label: 'Delayed', value: 'DELAYED' },
    { label: 'Returned', value: 'RETURNED' }
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900">Shipment Operations & Tracking</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time telemetry, consignee delivery records, transit SLAs, and exception audit logs.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search tracking #, consignee, city..."
              value={filters.searchQuery}
              onChange={e => updateFilter('searchQuery', e.target.value)}
              className="pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-blue-500 w-64 font-medium"
            />
          </div>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        {statusTabs.map(tab => {
          const isActive = filters.selectedStatus === tab.value;
          return (
            <button
              key={tab.value}
              onClick={() => updateFilter('selectedStatus', tab.value)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Shipments Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Tracking Number</th>
                <th className="py-3 px-4">Consignee & Corridor</th>
                <th className="py-3 px-4">Origin ➔ Destination</th>
                <th className="py-3 px-4">Vehicle & Driver</th>
                <th className="py-3 px-4">Package</th>
                <th className="py-3 px-4">Cost</th>
                <th className="py-3 px-4">Status & SLA</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredDeliveries.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Package className="w-10 h-10 mx-auto mb-2 text-slate-300 stroke-1" />
                    <p className="text-sm font-semibold text-slate-600">No delivery records found</p>
                    <p className="text-xs text-slate-400 mt-1">Try broadening your search or resetting active filters.</p>
                  </td>
                </tr>
              ) : (
                filteredDeliveries.map(del => {
                  const routeObj = routes.find(r => r.id === del.routeId);
                  const vehicleObj = vehicles.find(v => v.id === del.vehicleId);
                  const driverObj = drivers.find(d => d.id === del.driverId);

                  return (
                    <tr
                      key={del.id}
                      className="hover:bg-blue-50/40 transition-colors group cursor-pointer"
                      onClick={() => setSelectedDelivery(del)}
                    >
                      <td className="py-3 px-4 font-mono font-bold text-blue-700">
                        {del.trackingNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{del.customerName}</div>
                        <div className="text-[11px] text-slate-500">{del.region} • {routeObj?.code || 'Corridor'}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 font-medium text-slate-800">
                          <span>{del.originCity}</span>
                          <span className="text-slate-400">➔</span>
                          <span>{del.destinationCity}</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{del.distanceKm} km transit</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-800">{driverObj?.name || 'Assigned Driver'}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{vehicleObj?.plateNumber || del.vehicleId}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-block px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px] font-medium">
                          {del.packageType}
                        </span>
                        <div className="text-[10px] text-slate-500 mt-0.5">{del.packageWeightKg} kg</div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        ₹{del.deliveryCost}
                      </td>
                      <td className="py-3 px-4">
                        <DeliveryStatusBadge status={del.status} />
                        {del.delayMinutes > 0 && (
                          <div className="text-[10px] text-rose-600 font-semibold mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> +{del.delayMinutes}m delay
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedDelivery(del);
                          }}
                          className="px-2.5 py-1 bg-slate-100 group-hover:bg-blue-600 group-hover:text-white text-slate-700 rounded text-xs font-bold transition-colors"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Showing <strong>{filteredDeliveries.length}</strong> consignments</span>
          <span className="font-mono">Live Ingestion ID: TMS-SYNC-8921</span>
        </div>
      </div>

      {/* Shipment Detail Modal Drawer */}
      {selectedDelivery && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-4 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-base font-extrabold text-blue-700">
                    {selectedDelivery.trackingNumber}
                  </span>
                  <DeliveryStatusBadge status={selectedDelivery.status} />
                </div>
                <h3 className="text-sm font-bold text-slate-900 mt-1">
                  {selectedDelivery.customerName}
                </h3>
              </div>
              <button
                onClick={() => setSelectedDelivery(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Specs Grid */}
            <div className="grid grid-cols-3 gap-3 my-4 p-3 bg-slate-50 rounded-xl text-xs border border-slate-200">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Package Type</span>
                <span className="font-bold text-slate-800">{selectedDelivery.packageType}</span>
                <span className="block text-[11px] text-slate-500">{selectedDelivery.packageWeightKg} kg</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Transit Distance</span>
                <span className="font-bold text-slate-800">{selectedDelivery.distanceKm} km</span>
                <span className="block text-[11px] text-slate-500">{selectedDelivery.originCity} ➔ {selectedDelivery.destinationCity}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Cost</span>
                <span className="font-mono font-bold text-slate-800">₹{selectedDelivery.deliveryCost}</span>
                <span className="block text-[11px] text-slate-500">Fuel: ₹{selectedDelivery.fuelCost}</span>
              </div>
            </div>

            {/* Exception / Delay Callout if any */}
            {selectedDelivery.delayMinutes > 0 && (
              <div className="mb-4 p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs">
                <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-1">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  Transit SLA Delay: +{selectedDelivery.delayMinutes} minutes
                </div>
                <p className="text-amber-800">
                  <strong>Recorded Delay Reason:</strong> {selectedDelivery.delayReason || 'Traffic Congestion'}
                </p>
                {selectedDelivery.complaintLogged && (
                  <p className="text-rose-700 font-semibold mt-1">
                    ⚠️ Customer Feedback: "{selectedDelivery.complaintReason}"
                  </p>
                )}
              </div>
            )}

            {/* Timeline Events */}
            <div className="space-y-3 my-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Milestone Telemetry Timeline
              </h4>
              <div className="space-y-3 pl-2 border-l-2 border-blue-500 ml-2">
                <div className="relative pl-4 text-xs">
                  <div className="absolute -left-[11px] top-0.5 w-3 h-3 rounded-full bg-blue-600 ring-4 ring-white" />
                  <span className="font-bold text-slate-900">Order Received & Processed</span>
                  <p className="text-[11px] text-slate-500">{selectedDelivery.orderTimestamp}</p>
                </div>
                <div className="relative pl-4 text-xs">
                  <div className="absolute -left-[11px] top-0.5 w-3 h-3 rounded-full bg-blue-600 ring-4 ring-white" />
                  <span className="font-bold text-slate-900">Dispatched from {selectedDelivery.originCity} Hub</span>
                  <p className="text-[11px] text-slate-500">{selectedDelivery.dispatchTimestamp}</p>
                </div>
                <div className="relative pl-4 text-xs">
                  <div className="absolute -left-[11px] top-0.5 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white" />
                  <span className="font-bold text-slate-900">
                    {selectedDelivery.status === 'DELIVERED' ? 'Successfully Delivered' : 'Target Expected Delivery'}
                  </span>
                  <p className="text-[11px] text-slate-500">
                    {selectedDelivery.actualDelivery || selectedDelivery.expectedDelivery}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-200 flex justify-end gap-2">
              <button
                onClick={() => setSelectedDelivery(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors"
              >
                Close Drawer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
