import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  MapPin,
  Truck,
  Navigation,
  AlertTriangle,
  Layers,
  Sparkles,
  Info,
  Clock,
  DollarSign,
  Activity,
  CheckCircle
} from 'lucide-react';

interface MapHub {
  id: string;
  name: string;
  code: string;
  region: string;
  x: number; // percentage on svg canvas
  y: number;
  shipmentVolume: number;
  onTimeRate: number;
  status: 'OPTIMAL' | 'BUSY' | 'CONGESTED';
}

interface MapRouteLine {
  id: string;
  code: string;
  from: string;
  to: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  delayRate: number;
  status: 'CLEAR' | 'MODERATE' | 'HEAVY_DELAY';
  trucksInTransit: number;
}

export const LogisticsMapView: React.FC = () => {
  const { routes, updateFilter, setCurrentView } = useLogistics();
  const [selectedHub, setSelectedHub] = useState<MapHub | null>(null);
  const [selectedRouteOnMap, setSelectedRouteOnMap] = useState<MapRouteLine | null>(null);
  const [showTrafficLayer, setShowTrafficLayer] = useState(true);
  const [showFleetLayer, setShowFleetLayer] = useState(true);

  // South India Regional Logistics Network Coordinates
  const hubs: MapHub[] = [
    { id: 'hub-hyd', name: 'Hyderabad Central Hub', code: 'HYD-01', region: 'Andhra Pradesh & Telangana', x: 48, y: 18, shipmentVolume: 5120, onTimeRate: 94.2, status: 'OPTIMAL' },
    { id: 'hub-vja', name: 'Vijayawada Multi-Modal Terminal', code: 'VJA-02', region: 'Andhra Pradesh & Telangana', x: 68, y: 28, shipmentVolume: 2900, onTimeRate: 88.6, status: 'CONGESTED' },
    { id: 'hub-vzg', name: 'Visakhapatnam Port Gateway', code: 'VZG-03', region: 'Andhra Pradesh & Telangana', x: 84, y: 15, shipmentVolume: 3400, onTimeRate: 93.1, status: 'OPTIMAL' },
    { id: 'hub-blr', name: 'Bengaluru Tech & Cargo Hub', code: 'BLR-01', region: 'Karnataka', x: 42, y: 48, shipmentVolume: 7420, onTimeRate: 93.8, status: 'OPTIMAL' },
    { id: 'hub-hub', name: 'Hubballi Gateway', code: 'HUB-02', region: 'Karnataka', x: 26, y: 38, shipmentVolume: 1840, onTimeRate: 94.5, status: 'OPTIMAL' },
    { id: 'hub-maa', name: 'Chennai Central Freight Hub', code: 'MAA-01', region: 'Tamil Nadu', x: 72, y: 55, shipmentVolume: 8940, onTimeRate: 91.4, status: 'BUSY' },
    { id: 'hub-cbe', name: 'Coimbatore Industrial Depot', code: 'CBE-02', region: 'Tamil Nadu', x: 40, y: 74, shipmentVolume: 4200, onTimeRate: 89.2, status: 'CONGESTED' },
    { id: 'hub-mdu', name: 'Madurai Southern Hub', code: 'MDU-03', region: 'Tamil Nadu', x: 50, y: 88, shipmentVolume: 2100, onTimeRate: 93.5, status: 'OPTIMAL' },
    { id: 'hub-cok', name: 'Kochi Coastal Port Terminal', code: 'COK-01', region: 'Kerala', x: 30, y: 82, shipmentVolume: 3850, onTimeRate: 94.1, status: 'OPTIMAL' },
    { id: 'hub-ccj', name: 'Kozhikode Distribution Center', code: 'CCJ-02', region: 'Kerala', x: 28, y: 68, shipmentVolume: 1650, onTimeRate: 92.8, status: 'OPTIMAL' }
  ];

  const routeLines: MapRouteLine[] = [
    { id: 'rt-hyd-blr', code: 'AP-019', from: 'Hyderabad', to: 'Bengaluru', x1: 48, y1: 18, x2: 42, y2: 48, delayRate: 5.8, status: 'CLEAR', trucksInTransit: 14 },
    { id: 'rt-hyd-vja', code: 'AP-034', from: 'Hyderabad', to: 'Vijayawada', x1: 48, y1: 18, x2: 68, y2: 28, delayRate: 9.2, status: 'MODERATE', trucksInTransit: 9 },
    { id: 'rt-vja-vzg', code: 'AP-088', from: 'Vijayawada', to: 'Visakhapatnam', x1: 68, y1: 28, x2: 84, y2: 15, delayRate: 4.1, status: 'CLEAR', trucksInTransit: 8 },
    { id: 'rt-blr-maa', code: 'TN-012', from: 'Bengaluru', to: 'Chennai', x1: 42, y1: 48, x2: 72, y2: 55, delayRate: 6.4, status: 'CLEAR', trucksInTransit: 22 },
    { id: 'rt-maa-cbe', code: 'TN-042', from: 'Chennai', to: 'Coimbatore', x1: 72, y1: 55, x2: 40, y2: 74, delayRate: 18.4, status: 'HEAVY_DELAY', trucksInTransit: 18 },
    { id: 'rt-blr-cbe', code: 'KA-045', from: 'Bengaluru', to: 'Coimbatore', x1: 42, y1: 48, x2: 40, y2: 74, delayRate: 7.2, status: 'CLEAR', trucksInTransit: 12 },
    { id: 'rt-cbe-mdu', code: 'TN-065', from: 'Coimbatore', to: 'Madurai', x1: 40, y1: 74, x2: 50, y2: 88, delayRate: 5.1, status: 'CLEAR', trucksInTransit: 7 },
    { id: 'rt-cbe-cok', code: 'KL-014', from: 'Coimbatore', to: 'Kochi', x1: 40, y1: 74, x2: 30, y2: 82, delayRate: 11.2, status: 'MODERATE', trucksInTransit: 11 },
    { id: 'rt-blr-ccj', code: 'KA-092', from: 'Bengaluru', to: 'Kozhikode', x1: 42, y1: 48, x2: 28, y2: 68, delayRate: 8.9, status: 'MODERATE', trucksInTransit: 6 },
    { id: 'rt-hub-blr', code: 'KA-012', from: 'Hubballi', to: 'Bengaluru', x1: 26, y1: 38, x2: 42, y2: 48, delayRate: 4.8, status: 'CLEAR', trucksInTransit: 8 }
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Controls Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900">Interactive Logistics & Fleet Map</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time telemetry overlay of major transport corridors, hub throughput, and transit bottleneck hotspots.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowTrafficLayer(!showTrafficLayer)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors flex items-center gap-1.5 ${
              showTrafficLayer ? 'bg-blue-50 text-blue-800 border-blue-300' : 'bg-slate-100 text-slate-600 border-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            Traffic & Congestion
          </button>
          <button
            onClick={() => setShowFleetLayer(!showFleetLayer)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors flex items-center gap-1.5 ${
              showFleetLayer ? 'bg-emerald-50 text-emerald-800 border-emerald-300' : 'bg-slate-100 text-slate-600 border-slate-200'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            Active Fleet Layer
          </button>
        </div>
      </div>

      {/* Main Map Container */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Vector Interactive Map (3 Cols) */}
        <div className="lg:col-span-3 bg-slate-950 rounded-2xl p-6 border border-slate-800 shadow-2xl relative overflow-hidden min-h-[560px] flex flex-col justify-between">
          {/* Subtle Grid Canvas Background */}
          <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-40 pointer-events-none" />

          {/* Map Top Legend */}
          <div className="relative z-10 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Normal Flow (&lt;8% delay)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Moderate (8-14%)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span> Bottleneck (&gt;15%)
              </span>
            </div>
            <span className="font-mono text-cyan-400 text-[11px]">10 HUBS • 186 ACTIVE HAULERS</span>
          </div>

          {/* SVG Map Canvas */}
          <div className="relative w-full h-[450px] my-auto">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              {/* Route Lines */}
              {routeLines.map(line => {
                const isHeavy = line.status === 'HEAVY_DELAY';
                const strokeColor = line.status === 'HEAVY_DELAY' ? '#f43f5e' : line.status === 'MODERATE' ? '#f59e0b' : '#10b981';

                return (
                  <g key={line.id} className="cursor-pointer group" onClick={() => setSelectedRouteOnMap(line)}>
                    {/* Shadow halo */}
                    <line
                      x1={line.x1}
                      y1={line.y1}
                      x2={line.x2}
                      y2={line.y2}
                      stroke={strokeColor}
                      strokeWidth={isHeavy ? 1.8 : 1.0}
                      strokeOpacity={0.7}
                      strokeDasharray={isHeavy ? "2 1" : undefined}
                    />

                    {/* Animated Pulse dots simulating moving trucks */}
                    {showFleetLayer && (
                      <circle
                        r={isHeavy ? 1.2 : 0.8}
                        fill="#38bdf8"
                        className="animate-pulse"
                      >
                        <animate
                          attributeName="cx"
                          from={line.x1}
                          to={line.x2}
                          dur={`${isHeavy ? 9 : 5}s`}
                          repeatCount="indefinite"
                        />
                        <animate
                          attributeName="cy"
                          from={line.y1}
                          to={line.y2}
                          dur={`${isHeavy ? 9 : 5}s`}
                          repeatCount="indefinite"
                        />
                      </circle>
                    )}
                  </g>
                );
              })}

              {/* Hub Nodes */}
              {hubs.map(hub => {
                const isSelected = selectedHub?.id === hub.id;
                const nodeColor = hub.status === 'CONGESTED' ? '#f43f5e' : hub.status === 'BUSY' ? '#f59e0b' : '#38bdf8';

                return (
                  <g
                    key={hub.id}
                    className="cursor-pointer group"
                    onClick={() => {
                      setSelectedHub(hub);
                      setSelectedRouteOnMap(null);
                    }}
                  >
                    {/* Ripple on congested hubs */}
                    {hub.status === 'CONGESTED' && (
                      <circle
                        cx={hub.x}
                        cy={hub.y}
                        r="3.5"
                        fill="none"
                        stroke="#f43f5e"
                        strokeWidth="0.5"
                        className="animate-ping origin-center"
                      />
                    )}

                    {/* Outer Node circle */}
                    <circle
                      cx={hub.x}
                      cy={hub.y}
                      r={isSelected ? 2.8 : 2.0}
                      fill="#0f172a"
                      stroke={nodeColor}
                      strokeWidth={isSelected ? 1.2 : 0.8}
                    />

                    {/* Inner core */}
                    <circle
                      cx={hub.x}
                      cy={hub.y}
                      r="1.0"
                      fill={nodeColor}
                    />

                    {/* Hub Text Label */}
                    <text
                      x={hub.x}
                      y={hub.y - 3}
                      fill="#f8fafc"
                      fontSize="2.4"
                      fontWeight="bold"
                      textAnchor="middle"
                      className="select-none pointer-events-none drop-shadow-md"
                    >
                      {hub.code}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Map Footer Note */}
          <div className="relative z-10 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-3">
            <span>Click any Hub or Route corridor to inspect real-time SLA metrics.</span>
            <span className="font-mono text-slate-300">Region: South India Logistics Zone</span>
          </div>
        </div>

        {/* Right Info Panel / Inspector (1 Col) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <Navigation className="w-4 h-4 text-blue-600" />
              Node & Corridor Inspector
            </h2>

            {/* If Hub is Selected */}
            {selectedHub && (
              <div className="mt-4 space-y-3 animate-in fade-in duration-150">
                <div className="p-3 bg-slate-900 text-white rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 font-mono">{selectedHub.code}</span>
                  <h3 className="text-base font-bold leading-tight mt-0.5">{selectedHub.name}</h3>
                  <p className="text-xs text-slate-400">{selectedHub.region}</p>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-500">Daily Intake:</span>
                    <strong className="text-slate-900 font-mono">{selectedHub.shipmentVolume} shipments</strong>
                  </div>
                  <div className="flex justify-between p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-500">Hub On-Time Rate:</span>
                    <strong className={`font-mono ${selectedHub.onTimeRate >= 92 ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {selectedHub.onTimeRate}%
                    </strong>
                  </div>
                  <div className="flex justify-between p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-500">Operational Status:</span>
                    <strong className="font-mono text-slate-800">{selectedHub.status}</strong>
                  </div>
                </div>

                <button
                  onClick={() => {
                    updateFilter('selectedRegion', selectedHub.region);
                    setCurrentView('deliveries');
                  }}
                  className="w-full mt-2 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors"
                >
                  Filter Region Deliveries
                </button>
              </div>
            )}

            {/* If Route is Selected */}
            {selectedRouteOnMap && (
              <div className="mt-4 space-y-3 animate-in fade-in duration-150">
                <div className="p-3 bg-slate-900 text-white rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 font-mono">{selectedRouteOnMap.code}</span>
                  <h3 className="text-base font-bold leading-tight mt-0.5">
                    {selectedRouteOnMap.from} ➔ {selectedRouteOnMap.to}
                  </h3>
                  <p className="text-xs text-slate-400">Active Haul Corridor</p>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-500">Corridor Delay Rate:</span>
                    <strong className={`font-mono ${selectedRouteOnMap.delayRate > 10 ? 'text-rose-700' : 'text-slate-900'}`}>
                      {selectedRouteOnMap.delayRate}%
                    </strong>
                  </div>
                  <div className="flex justify-between p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-500">Haulers in Transit:</span>
                    <strong className="text-slate-900 font-mono">{selectedRouteOnMap.trucksInTransit} Vehicles</strong>
                  </div>
                  <div className="flex justify-between p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-500">Congestion Severity:</span>
                    <strong className="font-mono text-slate-800">{selectedRouteOnMap.status}</strong>
                  </div>
                </div>

                <button
                  onClick={() => setCurrentView('routes')}
                  className="w-full mt-2 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors"
                >
                  Open Corridor Analytics
                </button>
              </div>
            )}

            {!selectedHub && !selectedRouteOnMap && (
              <div className="mt-8 py-10 text-center text-slate-400">
                <Navigation className="w-10 h-10 mx-auto mb-2 text-slate-300 stroke-1" />
                <p className="text-xs font-semibold text-slate-600">Select any Hub or Corridor</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Click nodes on the left to see live throughput & congestion telemetry.
                </p>
              </div>
            )}
          </div>

          {/* Quick AI Corridor Suggestion */}
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
            <span className="font-bold block mb-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-blue-700" /> Bottleneck Alert:
            </span>
            Route TN-042 (Chennai ➔ Coimbatore) experiencing highest delay impact (18.4%).
          </div>
        </div>
      </div>
    </div>
  );
};
