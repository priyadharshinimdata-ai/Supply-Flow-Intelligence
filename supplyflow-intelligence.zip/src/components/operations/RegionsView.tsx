import React from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Globe2,
  MapPin,
  TrendingUp,
  DollarSign,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Truck,
  Users
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';

export const RegionsView: React.FC = () => {
  const { regions, updateFilter, setCurrentView } = useLogistics();

  const chartData = regions.map(r => ({
    name: r.region.split(' ')[0], // Short name
    fullName: r.region,
    onTimeRate: r.onTimeRate,
    costPerDelivery: r.costPerDelivery,
    deliveries: r.totalDeliveries
  }));

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900">Regional Performance & Territory Intelligence</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Comparative analysis of regional hubs, SLA consistency, operating expenses, and consignment density.
          </p>
        </div>
      </div>

      {/* Regional Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {regions.map(reg => (
          <div
            key={reg.region}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-blue-300 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-600" />
                  {reg.region}
                </span>
                <span className={`text-xs font-bold font-mono ${
                  reg.onTimeRate >= 93 ? 'text-emerald-700' : 'text-amber-700'
                }`}>
                  {reg.onTimeRate}% SLA
                </span>
              </div>

              <div className="space-y-2 text-xs my-3">
                <div className="flex justify-between">
                  <span className="text-slate-500">Deliveries:</span>
                  <span className="font-mono font-bold text-slate-900">{reg.totalDeliveries.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Cost / Drop:</span>
                  <span className="font-mono font-bold text-slate-900">₹{reg.costPerDelivery}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Revenue:</span>
                  <span className="font-mono font-bold text-slate-900">₹{(reg.revenue / 100000).toFixed(2)}L</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned Fleet:</span>
                  <span className="font-mono text-slate-700">{reg.activeVehicles} Vehicles</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Complaints:</span>
                  <span className="font-mono text-slate-700">{reg.customerComplaints}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                updateFilter('selectedRegion', reg.region);
                setCurrentView('dashboard');
              }}
              className="mt-3 w-full py-1.5 bg-slate-50 hover:bg-blue-600 hover:text-white text-blue-700 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1 border border-slate-200"
            >
              Filter to this Region <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>

      {/* Comparison Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* On-Time SLA Rate Comparison */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">On-Time SLA by Territory (%)</h2>
              <p className="text-xs text-slate-500">Benchmark target SLA: ≥ 92.0%</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis domain={[80, 100]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="onTimeRate" name="On-Time Rate %" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cost Per Delivery Comparison */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Cost Per Delivery by Territory (₹)</h2>
              <p className="text-xs text-slate-500">Lower cost indicates higher regional route density</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '8px', border: 'none', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="costPerDelivery" name="Cost Per Delivery (₹)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
