import React, { useState } from 'react';
import { useLogistics } from '../../context/LogisticsContext';
import { RouteInfo } from '../../types';
import {
  Route as RouteIcon,
  MapPin,
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  TrendingDown,
  Navigation,
  ArrowRight,
  Sparkles,
  X,
  Truck
} from 'lucide-react';

export const RoutesView: React.FC = () => {
  const { filteredRoutes, updateFilter, setCurrentView } = useLogistics();
  const [selectedRoute, setSelectedRoute] = useState<RouteInfo | null>(null);

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <RouteIcon className="w-5 h-5 text-blue-600" />
            <h1 className="text-xl font-bold text-slate-900">Route Intelligence & Corridor Analytics</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Distance metrics, transit SLA adherence, fuel consumption rates, and bottleneck detection per freight corridor.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('map')}
          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-2"
        >
          <MapPin className="w-4 h-4" />
          View Interactive Logistics Map
        </button>
      </div>

      {/* Corridor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRoutes.map(route => {
          const isTroubled = route.status === 'NEEDS_ATTENTION' || route.status === 'CRITICAL';

          return (
            <div
              key={route.id}
              onClick={() => setSelectedRoute(route)}
              className={`p-5 rounded-xl border transition-all duration-200 bg-white hover:shadow-md cursor-pointer flex flex-col justify-between ${
                isTroubled ? 'border-amber-300 ring-1 ring-amber-200' : 'border-slate-200 hover:border-blue-300'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="font-mono text-xs font-extrabold px-2 py-0.5 rounded bg-slate-900 text-white">
                    {route.code}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                      route.status === 'EFFICIENT'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : route.status === 'OPTIMAL'
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}
                  >
                    {route.status === 'NEEDS_ATTENTION' ? '🔴 Needs Attention' : route.status}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 mb-1 leading-snug">
                  {route.name}
                </h3>
                <p className="text-xs text-slate-500 mb-3">{route.region} • {route.distanceKm} km</p>

                <div className="grid grid-cols-3 gap-2 p-2.5 bg-slate-50 rounded-lg text-center font-mono text-xs mb-3 border border-slate-100">
                  <div>
                    <span className="block text-[10px] text-slate-400 font-sans">Delay Rate</span>
                    <span className={`font-extrabold ${route.delayRate > 10 ? 'text-rose-600' : 'text-slate-800'}`}>
                      {route.delayRate}%
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 font-sans">Cost / Drop</span>
                    <span className="font-extrabold text-slate-800">₹{route.costPerDelivery}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 font-sans">Avg Duration</span>
                    <span className="font-extrabold text-slate-800">
                      {Math.floor(route.avgActualDurationMins / 60)}h {route.avgActualDurationMins % 60}m
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span className="truncate">Top Cause: <strong>{route.primaryDelayCause}</strong></span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono">{route.totalShipments.toLocaleString()} shipments</span>
                <span className="text-blue-700 font-bold hover:underline flex items-center gap-1">
                  Corridor Breakdown <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Route Detail Modal */}
      {selectedRoute && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-start justify-between pb-3 border-b border-slate-200">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-base font-extrabold px-2.5 py-0.5 rounded bg-slate-900 text-white">
                    {selectedRoute.code}
                  </span>
                  <span className="text-xs font-bold text-slate-500">{selectedRoute.region}</span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {selectedRoute.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedRoute(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 my-4 text-xs">
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Corridor Length</span>
                  <span className="text-sm font-bold text-slate-900 font-mono">{selectedRoute.distanceKm} km</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Cost Per Delivery</span>
                  <span className="text-sm font-bold text-slate-900 font-mono">₹{selectedRoute.costPerDelivery}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Expected Time</span>
                  <span className="text-sm font-bold text-slate-900 font-mono">
                    {Math.floor(selectedRoute.expectedDurationMins / 60)}h {selectedRoute.expectedDurationMins % 60}m
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Actual Avg Time</span>
                  <span className="text-sm font-bold text-rose-600 font-mono">
                    {Math.floor(selectedRoute.avgActualDurationMins / 60)}h {selectedRoute.avgActualDurationMins % 60}m
                  </span>
                </div>
              </div>

              <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl">
                <span className="text-[10px] uppercase tracking-wider font-bold text-blue-900 block mb-1">
                  Optimization Recommendation
                </span>
                <p className="text-slate-800 leading-relaxed">
                  Traffic congestion on this route results in average +88 min deviation. Deploying daytime off-peak dispatch slots or alternative SH bypass roads will recover 14.5% in fuel burn.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
              <button
                onClick={() => setSelectedRoute(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
